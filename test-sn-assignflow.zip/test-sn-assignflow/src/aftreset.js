// @name  aftreset
// @hint  [AFT] Delete every test user, group and ticket this harness created
// @order 90

aftPanel('SN Assignflow — remove test data');
aftSay('This deletes only records the harness created — user IDs starting "aft.",', AFT_DIM);
aftSay('groups named "AFT …", and tickets whose short description starts "[AFT]".', AFT_DIM);
aftSay('');

(async function () {
    try {
        // Counted before anything is removed, so the confirmation can state the
        // real number rather than a guess.
        aftStatus('Counting');

        var plan = [];
        var tables = ['incident', 'change_request'];

        for (var t = 0; t < tables.length; t++) {
            var rows = await aftQuery(tables[t], 'short_descriptionSTARTSWITH[AFT]',
                'sys_id,number', 2000) || [];
            if (rows.length) plan.push({ table: tables[t], label: tables[t], rows: rows });
        }

        // Groups are matched by exact name against the harness's own list rather
        // than by a STARTSWITH prefix. "AFT" is short enough that a prefix query
        // could pick up a real group — AFTERCARE, say — and this command deletes
        // what it finds.
        var known  = AFT_GROUPS.map(function (g) { return g.name; });
        var found  = await aftQuery('sys_user_group', 'nameSTARTSWITHAFT', 'sys_id,name', 500) || [];
        var groups = found.filter(function (g) { return known.indexOf(g.name) !== -1; });
        var ignored = found.length - groups.length;

        if (ignored) {
            aftSay(ignored + ' group(s) start with "AFT" but are not harness fixtures — ' +
                   'leaving them alone.', AFT_WARN);
            aftSay('');
        }

        // Memberships are then found by group sys_id, not by another name query.
        if (groups.length) {
            var ids = groups.map(function (g) { return g.sys_id; }).join(',');
            var members = await aftQuery('sys_user_grmember', 'groupIN' + ids, 'sys_id', 2000) || [];
            if (members.length) {
                plan.push({ table: 'sys_user_grmember', label: 'group memberships', rows: members });
            }
        }

        if (groups.length) plan.push({ table: 'sys_user_group', label: 'groups', rows: groups });

        // The "aft." prefix includes the dot, which makes it specific enough to
        // use directly — and it also catches users left behind by an earlier
        // version of the harness.
        var users = await aftQuery('sys_user', 'user_nameSTARTSWITHaft.',
            'sys_id,user_name', 500) || [];
        if (users.length) plan.push({ table: 'sys_user', label: 'users', rows: users });

        var total = plan.reduce(function (n, p) { return n + p.rows.length; }, 0);

        if (!total) {
            aftSay('Nothing to remove — this instance is already clean.', AFT_OK);
            aftFinish('Nothing to do');
            return;
        }

        plan.forEach(function (p) {
            aftSay(String(p.rows.length).padStart(4, ' ') + '  ' + p.label, '#C6C0EC');
        });
        aftSay('');
        aftSay(total + ' record(s) will be deleted. This cannot be undone.', AFT_WARN);

        aftButton('Delete ' + total + ' records', 'primary', async function () {
            AFT_UI.foot.innerHTML = '';
            aftSay('');
            aftSay('Deleting…', AFT_HEAD);

            var done = 0, failed = 0;

            // Order matters: tickets reference groups and users, and memberships
            // reference both, so the leaves go first or the deletes are refused.
            for (var i = 0; i < plan.length; i++) {
                var p = plan[i];
                aftStatus('Removing ' + p.label);
                var okHere = 0;

                for (var r = 0; r < p.rows.length; r++) {
                    try {
                        await aftDelete(p.table, p.rows[r].sys_id);
                        okHere++;
                        done++;
                    } catch (e) {
                        failed++;
                        if (failed <= 5) {
                            aftSay('could not delete ' + p.label + ' ' +
                                   (p.rows[r].number || p.rows[r].name ||
                                    p.rows[r].user_name || p.rows[r].sys_id) +
                                   ' — ' + e.message, AFT_ERR, true);
                        }
                    }
                    aftProgress(done + failed, total);
                }
                aftSay(okHere + ' / ' + p.rows.length + '  ' + p.label,
                       okHere === p.rows.length ? AFT_OK : AFT_WARN, true);
            }

            aftSay('');
            if (failed) {
                aftSay(done + ' deleted, ' + failed + ' refused.', AFT_WARN);
                aftSay('Refusals are usually references from records outside the harness.', AFT_DIM);
                aftSay('Run this again — the second pass normally clears them.', AFT_DIM);
                aftStatus(failed + ' could not be deleted');
            } else {
                aftSay('All ' + done + ' records removed. The instance is clean.', AFT_OK);
                aftStatus('Done');
            }
            aftClose();
        });

        aftButton('Cancel', 'plain', function () { AFT_UI.back.remove(); });
        aftStatus('Waiting for confirmation');
    } catch (err) {
        aftFail(err);
    }
})();
