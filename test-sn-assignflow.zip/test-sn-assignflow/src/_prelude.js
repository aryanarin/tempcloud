// SN Assignflow test harness — shared prelude
//
// build-commands.js prepends this to every command body, so each command in the
// generated SN Commands file is self-contained. Nothing here runs on its own.
//
// Everything created carries a recognisable marker so `aftreset` can find and
// remove it, and so nothing in your PDI is ever touched by accident:
//
//   users            user_name starts with  aft.
//   groups           name starts with       AFT
//   tickets          short_description      [AFT] …
//
// All requests go to the instance in the current tab, authenticated by the
// session already open there.

var AFT_VERSION = '1.0.0';

// ── Fixture definitions ───────────────────────────────────────────────────────
// The corner cases are the point of this list. Read the `why` field before
// changing anything: several entries exist specifically to make SN Assignflow
// take an unhappy path.
var AFT_USERS = [
    { id: 'aft.alpha',    first: 'AFT', last: 'Alpha',     email: 'aft.alpha@example.test',
      active: true,  why: 'Plain agent. Resolves cleanly from its user ID.' },
    { id: 'aft.bravo',    first: 'AFT', last: 'Bravo',     email: 'aft.bravo@example.test',
      active: true,  why: 'Plain agent. Second in the rotation.' },
    { id: 'aft.charlie',  first: 'AFT', last: 'Charlie',   email: 'aft.charlie@example.test',
      active: true,  why: 'Plain agent. Third in the rotation, so 3 agents divide evenly into 12 tickets.' },
    { id: 'aft.delta',    first: 'AFT', last: 'Delta',     email: 'aft.delta@example.test',
      active: true,  why: 'Only ever referenced by user ID, never by sys_id. Forces a runtime lookup.' },
    { id: 'aft.echo',     first: 'AFT', last: 'Echo',      email: 'aft.echo@example.test',
      active: true,  why: 'Referenced by email address, to exercise the email fallback in the lookup query.' },
    { id: 'aft.dupe1',    first: 'AFT', last: 'Duplicate', email: 'aft.dupe1@example.test',
      active: true,  why: 'Shares a display name with aft.dupe2. A name-based lookup must report the ambiguity, not guess.' },
    { id: 'aft.dupe2',    first: 'AFT', last: 'Duplicate', email: 'aft.dupe2@example.test',
      active: true,  why: 'The other half of the ambiguous pair.' },
    { id: 'aft.inactive', first: 'AFT', last: 'Inactive',  email: 'aft.inactive@example.test',
      active: false, why: 'Inactive in ServiceNow. A name-based lookup is scoped to active=true, so this one must not resolve.' },
    { id: 'aft.comma',    first: 'AFT', last: 'Comma, Jr', email: 'aft.comma@example.test',
      active: true,  why: 'Display name contains a comma, to prove the CSV export/import round trip quotes correctly.' }
];

// Referenced by a group but deliberately never created.
var AFT_GHOST_ID = 'aft.ghost.does.not.exist';

var AFT_GROUPS = [
    {
        key:   'rotation',
        name:  'AFT Rotation',
        table: 'incident',
        desc:  'Happy path. Three active agents, twelve unassigned tickets — an even 4 each.',
        // Agent rows are described the way they should appear in SN Assignflow,
        // not the way ServiceNow stores them.
        agents: [
            { ref: 'aft.alpha',   by: 'user_name' },
            { ref: 'aft.bravo',   by: 'user_name' },
            { ref: 'aft.charlie', by: 'user_name' }
        ],
        tickets:      { unassigned: 12, preassigned: 3 },
        preassignTo:  'aft.alpha'
    },
    {
        key:   'corner',
        name:  'AFT Corner Cases',
        table: 'incident',
        desc:  'Every agent row here is wrong in a different way. Exactly one should end up usable.',
        agents: [
            { ref: 'aft.delta',    by: 'user_name', note: 'The only row that should work. Resolved at runtime.' },
            { ref: 'AFT Duplicate', by: 'name',     note: 'Ambiguous — two users share this display name.' },
            { ref: 'AFT Inactive',  by: 'name',     note: 'Inactive user, so a name lookup should not find them.' },
            { ref: AFT_GHOST_ID,    by: 'user_name', note: 'No such user. Should be reported and skipped.' },
            { ref: '',              by: 'empty',     note: 'Empty row. Should be rejected before any lookup.' },
            { ref: 'deadbeef',      by: 'sys_id',    note: 'Malformed sys_id — not 32 hex characters.' }
        ],
        tickets: { unassigned: 6, preassigned: 0 }
    },
    {
        key:   'change',
        name:  'AFT Change Table',
        table: 'change_request',
        desc:  'Proves the engine is not incident-only.',
        agents: [
            { ref: 'aft.echo',  by: 'email' },
            { ref: 'aft.comma', by: 'user_name' }
        ],
        tickets: { unassigned: 5, preassigned: 0 }
    },
    {
        key:   'empty',
        name:  'AFT Empty Queue',
        table: 'incident',
        desc:  'Matches nothing. The engine should say so and move on rather than erroring.',
        agents: [
            { ref: 'aft.alpha', by: 'user_name' }
        ],
        tickets: { unassigned: 0, preassigned: 0 }
    }
];

// ── API ───────────────────────────────────────────────────────────────────────
function aftToken() {
    try {
        return window.g_ck
            || (window.NOW && window.NOW.user && window.NOW.user.userToken)
            || (document.querySelector('input[name="sysparm_ck"]') || {}).value
            || '';
    } catch (e) { return ''; }
}

async function aftApi(method, path, body) {
    var headers = { 'Accept': 'application/json', 'X-UserToken': aftToken() };
    if (body) headers['Content-Type'] = 'application/json';

    var res = await fetch(path, {
        method:      method,
        headers:     headers,
        credentials: 'same-origin',
        cache:       'no-store',
        body:        body ? JSON.stringify(body) : undefined
    });

    var text = await res.text();
    if (!res.ok) {
        var detail = text;
        try { detail = (JSON.parse(text).error || {}).message || text; } catch (e) {}
        throw new Error(method + ' ' + path.split('?')[0] + ' → HTTP ' + res.status + ' · ' + String(detail).slice(0, 200));
    }
    if (!text) return null;
    try { return JSON.parse(text).result; } catch (e) { return null; }
}

function aftQuery(table, query, fields, limit) {
    return aftApi('GET', '/api/now/table/' + table +
        '?sysparm_query=' + encodeURIComponent(query) +
        '&sysparm_fields=' + (fields || 'sys_id') +
        '&sysparm_limit=' + (limit || 1000));
}

function aftCreate(table, body) {
    return aftApi('POST', '/api/now/table/' + table, body);
}

function aftDelete(table, sysId) {
    return aftApi('DELETE', '/api/now/table/' + table + '/' + sysId);
}

// ── Progress panel ────────────────────────────────────────────────────────────
// Deliberately self-contained: no stylesheet, no dependency on the instance's
// own CSS, and a high z-index so it sits above both UI16 and Now Experience.
var AFT_UI = null;

function aftPanel(title) {
    var back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:2147483640;background:rgba(30,27,75,.62);' +
        'display:flex;align-items:center;justify-content:center;padding:24px;' +
        "font-family:'Segoe UI',-apple-system,Roboto,Arial,sans-serif;";

    var box = document.createElement('div');
    box.style.cssText = 'background:#1B1740;color:#EDE9FE;border:1px solid #332D6E;border-radius:12px;' +
        'width:640px;max-width:100%;max-height:100%;display:flex;flex-direction:column;' +
        'overflow:hidden;box-shadow:0 16px 50px rgba(0,0,0,.55);';

    var head = document.createElement('div');
    head.style.cssText = 'padding:14px 18px;border-bottom:1px solid #2E2865;display:flex;' +
        'align-items:center;gap:11px;background:#211C4C;flex-shrink:0;';
    head.innerHTML =
        '<div style="width:24px;height:24px;border-radius:6px;background:#7C3AED;display:flex;' +
        'align-items:center;justify-content:center;flex-shrink:0;">' +
        '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" stroke-width="2.1" ' +
        'stroke-linecap="round" stroke-linejoin="round"><circle cx="4.5" cy="12" r="2.4" fill="#fff" stroke="none"/>' +
        '<path d="M7.4 12h3.1"/><path d="M10.5 12 17.2 5.3"/><path d="M10.5 12 17.2 18.7"/>' +
        '<path d="M13.6 5.3h3.6v3.6"/><path d="M13.6 18.7h3.6v-3.6"/></svg></div>' +
        '<div style="flex:1;min-width:0"><div style="font-size:14px;font-weight:600;color:#F5F3FF">' +
        title + '</div><div id="aft-sub" style="font-size:11px;color:#9E98CE;margin-top:2px">Starting…</div></div>';

    var bar = document.createElement('div');
    bar.style.cssText = 'height:3px;background:#2E2865;flex-shrink:0;';
    var fill = document.createElement('div');
    fill.style.cssText = 'height:100%;width:0;background:#7C3AED;transition:width .2s ease;';
    bar.appendChild(fill);

    var log = document.createElement('div');
    log.style.cssText = 'flex:1;overflow-y:auto;padding:12px 18px;background:#171339;' +
        "font-family:'Cascadia Mono',Consolas,monospace;font-size:11px;line-height:1.75;min-height:220px;";

    var foot = document.createElement('div');
    foot.style.cssText = 'padding:12px 18px;border-top:1px solid #2E2865;background:#211C4C;' +
        'display:flex;flex-wrap:wrap;gap:8px;align-items:center;flex-shrink:0;';

    box.appendChild(head);
    box.appendChild(bar);
    box.appendChild(log);
    box.appendChild(foot);
    back.appendChild(box);
    document.body.appendChild(back);

    AFT_UI = {
        back: back, box: box, log: log, foot: foot, fill: fill,
        sub: head.querySelector('#aft-sub')
    };
    return AFT_UI;
}

function aftSay(msg, colour, indent) {
    if (!AFT_UI) return;
    var line = document.createElement('div');
    line.style.cssText = 'color:' + (colour || '#C6C0EC') + ';white-space:pre-wrap;word-break:break-word;' +
        (indent ? 'padding-left:16px;' : '');
    line.textContent = msg;
    AFT_UI.log.appendChild(line);
    AFT_UI.log.scrollTop = AFT_UI.log.scrollHeight;
}

var AFT_OK   = '#6EE7A0';
var AFT_WARN = '#FCD34D';
var AFT_ERR  = '#FCA5A5';
var AFT_DIM  = '#7C74AD';
var AFT_HEAD = '#A78BFA';

function aftHeading(msg) {
    aftSay('');
    aftSay(msg, AFT_HEAD);
    aftSay('─'.repeat(Math.min(58, msg.length + 8)), '#3B3479');
}

function aftStatus(msg) { if (AFT_UI) AFT_UI.sub.textContent = msg; }
function aftProgress(done, total) {
    if (AFT_UI) AFT_UI.fill.style.width = (total ? Math.round(done / total * 100) : 0) + '%';
}

function aftButton(label, kind, onClick) {
    var b = document.createElement('button');
    var primary = kind === 'primary';
    b.textContent = label;
    b.style.cssText = 'font:600 12px/1 inherit;padding:9px 14px;border-radius:6px;cursor:pointer;' +
        'font-family:inherit;border:1px solid ' + (primary ? '#7C3AED' : '#3B3479') + ';' +
        'background:' + (primary ? '#7C3AED' : 'transparent') + ';' +
        'color:' + (primary ? '#fff' : '#C6C0EC') + ';';
    b.addEventListener('mouseenter', function () {
        b.style.background = primary ? '#8B5CF6' : '#2A2463';
    });
    b.addEventListener('mouseleave', function () {
        b.style.background = primary ? '#7C3AED' : 'transparent';
    });
    b.addEventListener('click', onClick);
    if (AFT_UI) AFT_UI.foot.appendChild(b);
    return b;
}

// A download rather than a copy button: SN Assignflow imports from a file, so
// this is what actually closes the loop.
function aftDownload(label, filename, text, mime) {
    return aftButton(label, 'primary', function () {
        var blob = new Blob([text], { type: mime || 'application/json;charset=utf-8' });
        var url  = URL.createObjectURL(blob);
        var a    = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
        aftSay('saved ' + filename, AFT_OK);
    });
}

function aftClose() {
    aftButton('Close', 'plain', function () { if (AFT_UI) AFT_UI.back.remove(); });
}

function aftFinish(msg) {
    aftStatus(msg);
    aftProgress(1, 1);
    aftClose();
}

function aftFail(err) {
    aftSay('');
    aftSay('Stopped: ' + (err && err.message ? err.message : err), AFT_ERR);
    aftSay('Nothing further was created. Run \\aftreset to clear any partial data.', AFT_DIM);
    aftStatus('Failed');
    aftClose();
}

// ── Fixture lookups ───────────────────────────────────────────────────────────
function aftUserDef(id) {
    for (var i = 0; i < AFT_USERS.length; i++) if (AFT_USERS[i].id === id) return AFT_USERS[i];
    return null;
}

function aftDisplayName(def) { return def.first + ' ' + def.last; }

// Reads back everything the harness has created, so each command can work from
// live state rather than assuming a previous command ran.
async function aftLoadExisting() {
    var users = await aftQuery('sys_user', 'user_nameSTARTSWITHaft.',
        'sys_id,user_name,name,email,active', 200);
    var groups = await aftQuery('sys_user_group', 'nameSTARTSWITHAFT',
        'sys_id,name,description', 200);

    var byId = {};
    (users || []).forEach(function (u) { byId[u.user_name.toLowerCase()] = u; });

    var byName = {};
    (groups || []).forEach(function (g) { byName[g.name] = g; });

    return { users: users || [], groups: groups || [], userById: byId, groupByName: byName };
}

// Turns an agent definition into the row shape SN Assignflow stores, given the
// live users. `withSysId` decides whether the sys_id is pre-filled — leaving it
// out is what forces the extension to resolve the user ID at run time.
function aftAgentRow(agent, userById, withSysId) {
    var row = { name: '', user_name: '', sys_id: '', active: true };

    if (agent.by === 'empty')  return row;
    if (agent.by === 'sys_id') { row.name = 'Malformed sys_id row'; row.sys_id = agent.ref; return row; }

    if (agent.by === 'name') {
        row.name = agent.ref;
        return row;
    }

    var def  = aftUserDef(agent.ref);
    var live = userById[String(agent.ref).toLowerCase()];

    if (agent.by === 'email') {
        row.name      = def ? aftDisplayName(def) : agent.ref;
        row.user_name = def ? def.email : agent.ref;
        if (withSysId && live) row.sys_id = live.sys_id;
        return row;
    }

    row.name      = def ? aftDisplayName(def) : '';
    row.user_name = agent.ref;
    if (withSysId && live) row.sys_id = live.sys_id;
    return row;
}

// The filter query is emitted WITHOUT ^assigned_toISEMPTY on purpose: the
// "Only assign unassigned tickets" rule should add it, and the pre-assigned
// tickets in AFT Rotation are there to prove it did.
function aftGroupQuery(groupSysId) {
    return 'assignment_group=' + groupSysId;
}

function aftBuildGroupsExport(existing, withSysId) {
    var out = [];
    AFT_GROUPS.forEach(function (g) {
        var live = existing.groupByName[g.name];
        if (!live) return;
        out.push({
            id:     'aft-' + g.key,
            name:   g.name,
            table:  g.table,
            query:  g.key === 'empty'
                        ? 'assignment_group=' + live.sys_id + '^short_descriptionSTARTSWITHnothing matches this'
                        : aftGroupQuery(live.sys_id),
            agents: g.agents.map(function (a) { return aftAgentRow(a, existing.userById, withSysId); }),
            active: true
        });
    });

    return JSON.stringify({
        version:    '4.0',
        kind:       'groups',
        exportedAt: new Date().toISOString(),
        note:       'Generated by the SN Assignflow test harness v' + AFT_VERSION +
                    (withSysId ? ' — sys_ids pre-filled' : ' — user IDs only, resolved at run time'),
        groups:     out,
        users:      [],
        rr:         {}
    }, null, 2);
}

function aftBuildUsersCsv(existing, withSysId) {
    function esc(v) {
        var s = String(v == null ? '' : v);
        return /[",]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }
    var rows = ['name,user_id,sys_id,email,note'];
    AFT_USERS.forEach(function (def) {
        var live = existing.userById[def.id];
        rows.push([
            esc(aftDisplayName(def)),
            esc(def.id),
            esc(withSysId && live ? live.sys_id : ''),
            esc(def.email),
            esc(def.why)
        ].join(','));
    });
    return rows.join('\n') + '\n';
}

// ── Provisioning ──────────────────────────────────────────────────────────────
// Every step is idempotent: it checks what already exists and only creates the
// difference, so running a command twice does not double your fixtures.

async function aftEnsureUsers(existing) {
    aftHeading('Users');
    var created = 0, skipped = 0, i = 0;

    for (var n = 0; n < AFT_USERS.length; n++) {
        var def = AFT_USERS[n];
        i++;
        aftProgress(i, AFT_USERS.length);

        if (existing.userById[def.id]) {
            aftSay('exists   ' + def.id, AFT_DIM, true);
            skipped++;
            continue;
        }

        aftStatus('Creating ' + def.id);
        var row = await aftCreate('sys_user', {
            user_name:  def.id,
            first_name: def.first,
            last_name:  def.last,
            email:      def.email,
            active:     def.active ? 'true' : 'false',
            title:      'SN Assignflow test fixture'
        });

        existing.userById[def.id] = {
            sys_id: row.sys_id, user_name: def.id,
            name: aftDisplayName(def), email: def.email,
            active: def.active ? 'true' : 'false'
        };
        created++;
        aftSay('created  ' + def.id + '  ' + row.sys_id +
               (def.active ? '' : '  (inactive)'), AFT_OK, true);
    }

    aftSay('');
    aftSay(created + ' created, ' + skipped + ' already present', AFT_DIM);
    return { created: created, skipped: skipped };
}

async function aftEnsureGroups(existing) {
    aftHeading('Assignment groups');
    var created = 0, skipped = 0;

    for (var n = 0; n < AFT_GROUPS.length; n++) {
        var g = AFT_GROUPS[n];
        aftProgress(n + 1, AFT_GROUPS.length);

        if (existing.groupByName[g.name]) {
            aftSay('exists   ' + g.name, AFT_DIM, true);
            skipped++;
        } else {
            aftStatus('Creating ' + g.name);
            var row = await aftCreate('sys_user_group', {
                name:        g.name,
                description: 'SN Assignflow test fixture — ' + g.desc
            });
            existing.groupByName[g.name] = { sys_id: row.sys_id, name: g.name };
            created++;
            aftSay('created  ' + g.name + '  ' + row.sys_id, AFT_OK, true);
        }

        // Membership is cosmetic for the engine — SN Assignflow assigns by
        // sys_id and never consults group membership — but a realistic PDI has
        // it, and it makes the groups readable in the ServiceNow UI.
        var groupSysId = existing.groupByName[g.name].sys_id;
        var members    = await aftQuery('sys_user_grmember', 'group=' + groupSysId, 'sys_id,user', 200);
        var have       = {};
        (members || []).forEach(function (m) { have[m.user.value || m.user] = true; });

        for (var a = 0; a < g.agents.length; a++) {
            var agent = g.agents[a];
            if (agent.by !== 'user_name' && agent.by !== 'email') continue;
            var def = aftUserDef(agent.ref);
            if (!def) continue;
            var live = existing.userById[def.id];
            if (!live || have[live.sys_id]) continue;
            await aftCreate('sys_user_grmember', { group: groupSysId, user: live.sys_id });
            aftSay('member   ' + def.id + ' → ' + g.name, AFT_DIM, true);
        }
    }

    aftSay('');
    aftSay(created + ' created, ' + skipped + ' already present', AFT_DIM);
    return { created: created, skipped: skipped };
}

async function aftEnsureTickets(existing, extraRounds) {
    aftHeading('Tickets');
    var total = 0;
    var rounds = extraRounds || 1;

    for (var n = 0; n < AFT_GROUPS.length; n++) {
        var g = AFT_GROUPS[n];
        var live = existing.groupByName[g.name];
        if (!live) { aftSay('skipped  ' + g.name + ' (group missing)', AFT_WARN, true); continue; }
        if (!g.tickets.unassigned && !g.tickets.preassigned) {
            aftSay('none     ' + g.name + ' (intentionally empty)', AFT_DIM, true);
            continue;
        }

        var wantOpen = g.tickets.unassigned * rounds;
        var wantPre  = g.tickets.preassigned;

        // Count what is already there so a repeat run tops up rather than piles on.
        var openNow = await aftQuery(g.table,
            'assignment_group=' + live.sys_id + '^assigned_toISEMPTY^short_descriptionSTARTSWITH[AFT]',
            'sys_id', 1000);
        var preNow = await aftQuery(g.table,
            'assignment_group=' + live.sys_id + '^assigned_toISNOTEMPTY^short_descriptionSTARTSWITH[AFT]',
            'sys_id', 1000);

        var makeOpen = Math.max(0, wantOpen - (openNow || []).length);
        var makePre  = Math.max(0, wantPre - (preNow || []).length);

        aftSay(g.name + ' (' + g.table + ')', AFT_HEAD, true);
        if (!makeOpen && !makePre) {
            aftSay('already at target: ' + (openNow || []).length + ' open, ' +
                   (preNow || []).length + ' pre-assigned', AFT_DIM, true);
            continue;
        }

        var caller = existing.userById['aft.alpha'];

        for (var k = 0; k < makeOpen; k++) {
            aftStatus('Creating ' + g.table + ' for ' + g.name);
            var body = {
                short_description: '[AFT] ' + g.name + ' open #' + (k + 1),
                description:       'Created by the SN Assignflow test harness. Safe to delete.',
                assignment_group:  live.sys_id
            };
            if (g.table === 'incident') {
                body.impact = '2';
                body.urgency = '2';
                if (caller) body.caller_id = caller.sys_id;
            }
            var made = await aftCreate(g.table, body);
            total++;
            aftProgress(total, total + makeOpen - k);
            aftSay('open     ' + (made.number || made.sys_id), AFT_OK, true);
        }

        // Pre-assigned tickets exist to prove the unassigned-only rule works:
        // SN Assignflow must leave these alone.
        if (makePre) {
            var target = existing.userById[g.preassignTo] || caller;
            for (var p = 0; p < makePre; p++) {
                var pbody = {
                    short_description: '[AFT] ' + g.name + ' pre-assigned #' + (p + 1) +
                                       ' — must NOT be reassigned',
                    description:       'Already owned. The unassigned-only rule should skip this.',
                    assignment_group:  live.sys_id
                };
                if (target) pbody.assigned_to = target.sys_id;
                if (g.table === 'incident') { pbody.impact = '3'; pbody.urgency = '3'; }
                var pm = await aftCreate(g.table, pbody);
                total++;
                aftSay('assigned ' + (pm.number || pm.sys_id) + ' → ' +
                       (target ? target.user_name : 'nobody'), AFT_WARN, true);
            }
        }
    }

    aftSay('');
    aftSay(total + ' ticket(s) created', AFT_DIM);
    return total;
}

// Prints the queries and offers the importable files.
function aftOfferImports(existing) {
    aftHeading('Import into SN Assignflow');

    AFT_GROUPS.forEach(function (g) {
        var live = existing.groupByName[g.name];
        if (!live) return;
        aftSay(g.name + '  [' + g.table + ']', AFT_HEAD, true);
        aftSay('query  ' + aftGroupQuery(live.sys_id), '#C6C0EC', true);
    });

    aftSay('');
    aftSay('Two group files are offered below. Start with the user-ID one — it leaves', AFT_DIM);
    aftSay('every sys_id blank, which is what forces SN Assignflow to resolve the user', AFT_DIM);
    aftSay('IDs against this instance while it runs.', AFT_DIM);

    aftDownload('Groups — user IDs only', 'aft-groups-userids.json',
        aftBuildGroupsExport(existing, false));
    aftDownload('Groups — sys_ids filled', 'aft-groups-sysids.json',
        aftBuildGroupsExport(existing, true));
    aftButton('Users CSV — no sys_ids', 'plain', function () {
        var blob = new Blob([aftBuildUsersCsv(existing, false)], { type: 'text/csv;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = 'aft-users-no-sysid.csv';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
        aftSay('saved aft-users-no-sysid.csv', AFT_OK);
    });
    aftButton('Users CSV — with sys_ids', 'plain', function () {
        var blob = new Blob([aftBuildUsersCsv(existing, true)], { type: 'text/csv;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = 'aft-users-with-sysid.csv';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
        aftSay('saved aft-users-with-sysid.csv', AFT_OK);
    });
}
