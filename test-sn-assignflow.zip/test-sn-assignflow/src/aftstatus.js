// @name  aftstatus
// @hint  [AFT] Check the round robin came out even, and what got skipped
// @order 50

aftPanel('SN Assignflow — result check');
aftSay('Reads back every [AFT] ticket and reports how the engine distributed them.', AFT_DIM);

(async function () {
    try {
        var existing = await aftLoadExisting();

        if (!Object.keys(existing.groupByName).length) {
            aftSay('');
            aftSay('No AFT groups found — run \\aftsetup first.', AFT_ERR);
            aftFinish('Nothing to report');
            return;
        }

        // sys_id → user_name, so per-agent counts can be reported by login.
        var nameOf = {};
        existing.users.forEach(function (u) { nameOf[u.sys_id] = u.user_name; });

        var problems = [];

        for (var n = 0; n < AFT_GROUPS.length; n++) {
            var g    = AFT_GROUPS[n];
            var live = existing.groupByName[g.name];
            aftProgress(n + 1, AFT_GROUPS.length);
            if (!live) continue;

            aftHeading(g.name + '  [' + g.table + ']');
            aftStatus('Reading ' + g.name);

            var rows = await aftQuery(g.table,
                'assignment_group=' + live.sys_id + '^short_descriptionSTARTSWITH[AFT]',
                'sys_id,number,short_description,assigned_to', 1000) || [];

            if (!rows.length) { aftSay('no test tickets in this group', AFT_DIM, true); continue; }

            var open = 0;
            var perAgent = {};
            var wrongly = [];

            rows.forEach(function (r) {
                var to = r.assigned_to && (r.assigned_to.value || r.assigned_to);
                if (!to) { open++; return; }
                var who = nameOf[to] || to;
                perAgent[who] = (perAgent[who] || 0) + 1;
                // A ticket created pre-assigned must still be owned by whoever it
                // started with. If the rotation touched it, the unassigned-only
                // rule is not doing its job.
                if (/pre-assigned/.test(r.short_description || '') && who !== g.preassignTo) {
                    wrongly.push(r.number + ' now on ' + who);
                }
            });

            aftSay('total ' + rows.length + ' · unassigned ' + open +
                   ' · assigned ' + (rows.length - open), '#C6C0EC', true);

            var agents = Object.keys(perAgent).sort();
            if (!agents.length) {
                aftSay('nothing assigned yet', AFT_DIM, true);
            } else {
                var counts = agents.map(function (a) { return perAgent[a]; });
                var max = Math.max.apply(null, counts);
                var min = Math.min.apply(null, counts);

                agents.forEach(function (a) {
                    var c = perAgent[a];
                    aftSay(a.padEnd(26, ' ') + String(c).padStart(3, ' ') + '  ' +
                           '█'.repeat(Math.min(30, c)), '#C6C0EC', true);
                });

                // Round robin over N agents can never leave a spread wider than
                // one, so anything more means the rotation is not fair.
                var expected = g.key === 'rotation' ? g.agents.length : agents.length;
                if (max - min > 1) {
                    aftSay('spread is ' + (max - min) + ' — round robin should never exceed 1',
                           AFT_ERR, true);
                    problems.push(g.name + ': uneven distribution (spread ' + (max - min) + ')');
                } else {
                    aftSay('spread ' + (max - min) + ' across ' + agents.length +
                           ' agent(s) — even', AFT_OK, true);
                }

                if (g.key === 'rotation' && agents.length !== expected) {
                    // aft.alpha also owns the pre-assigned tickets, so seeing the
                    // three rotation agents plus nobody else is what's expected.
                    aftSay('note: ' + agents.length + ' distinct assignees, expected ' +
                           expected, AFT_WARN, true);
                }
            }

            if (wrongly.length) {
                aftSay('pre-assigned tickets were reassigned: ' + wrongly.join(', '), AFT_ERR, true);
                problems.push(g.name + ': the unassigned-only rule did not hold');
            } else if (g.tickets.preassigned) {
                aftSay('pre-assigned tickets untouched — unassigned-only rule held', AFT_OK, true);
            }

            if (g.key === 'corner' && (rows.length - open) > 0) {
                var cornerAgents = Object.keys(perAgent);
                if (cornerAgents.length === 1 && cornerAgents[0] === 'aft.delta') {
                    aftSay('only aft.delta received work — the five bad rows were all ' +
                           'correctly rejected', AFT_OK, true);
                } else {
                    aftSay('expected only aft.delta to receive work here, got: ' +
                           cornerAgents.join(', '), AFT_ERR, true);
                    problems.push('AFT Corner Cases: a bad agent row was used');
                }
            }
        }

        aftHeading('Verdict');
        if (problems.length) {
            problems.forEach(function (p) { aftSay(p, AFT_ERR); });
            aftStatus(problems.length + ' problem(s) found');
        } else {
            aftSay('Everything checks out.', AFT_OK);
            aftStatus('All good');
        }
        aftProgress(1, 1);
        aftClose();
    } catch (err) {
        aftFail(err);
    }
})();
