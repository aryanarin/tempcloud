// @name  aftsetup
// @hint  [AFT] Provision the full SN Assignflow test environment
// @order 10

aftPanel('SN Assignflow — full test setup');
aftSay('Creating users, groups and tickets. Everything is prefixed so \\aftreset', AFT_DIM);
aftSay('can remove all of it later. Nothing else in this instance is touched.', AFT_DIM);

(async function () {
    try {
        var existing = await aftLoadExisting();

        await aftEnsureUsers(existing);
        await aftEnsureGroups(existing);
        await aftEnsureTickets(existing, 1);

        aftOfferImports(existing);

        aftHeading('What to do next');
        aftSay('1. Download "Groups — user IDs only" and import it in SN Assignflow', '#C6C0EC');
        aftSay('   under Assignment Groups → Import → replace.', '#C6C0EC');
        aftSay('2. Under Rules, switch Dry run ON, then run the widget once and read', '#C6C0EC');
        aftSay('   the log. Nothing should be written yet.', '#C6C0EC');
        aftSay('3. Switch Dry run OFF, run again, then use \\aftstatus to check the', '#C6C0EC');
        aftSay('   round robin came out even.', '#C6C0EC');
        aftSay('');
        aftSay('The full case-by-case list is in TEST_PLAN.md.', AFT_DIM);

        aftFinish('Setup complete');
    } catch (err) {
        aftFail(err);
    }
})();
