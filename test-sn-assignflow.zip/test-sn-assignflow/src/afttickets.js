// @name  afttickets
// @hint  [AFT] Top the test queues back up (run again for a bigger backlog)
// @order 40

aftPanel('SN Assignflow — top up test tickets');
aftSay('Each run raises the target by one round, so running this three times gives', AFT_DIM);
aftSay('36 open tickets in AFT Rotation — useful for testing the per-cycle caps.', AFT_DIM);

(async function () {
    try {
        var existing = await aftLoadExisting();

        if (!Object.keys(existing.groupByName).length) {
            aftSay('');
            aftSay('No AFT groups exist yet — run \\aftsetup first.', AFT_ERR);
            aftFinish('Nothing to do');
            return;
        }

        // How many rounds are already in place decides how much to add, so this
        // grows the backlog rather than resetting it.
        var rotation = existing.groupByName['AFT Rotation'];
        var rounds = 1;
        if (rotation) {
            var open = await aftQuery('incident',
                'assignment_group=' + rotation.sys_id +
                '^assigned_toISEMPTY^short_descriptionSTARTSWITH[AFT]', 'sys_id', 1000);
            rounds = Math.floor((open || []).length / 12) + 1;
        }
        aftSay('');
        aftSay('Targeting round ' + rounds + ' (' + (rounds * 12) + ' open in AFT Rotation)', AFT_HEAD);

        await aftEnsureTickets(existing, rounds);

        aftHeading('Suggested checks');
        aftSay('Rules → Maximum assignments per cycle = 5', '#C6C0EC');
        aftSay('  one cycle should assign exactly 5 and log that the cap was reached.', AFT_DIM);
        aftSay('Rules → Maximum per agent, per cycle = 1', '#C6C0EC');
        aftSay('  one cycle should assign 3 — one per agent — then stop.', AFT_DIM);

        aftFinish('Queues topped up');
    } catch (err) {
        aftFail(err);
    }
})();
