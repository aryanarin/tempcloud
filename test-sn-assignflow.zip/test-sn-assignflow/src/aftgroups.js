// @name  aftgroups
// @hint  [AFT] Create only the assignment groups and their membership
// @order 30

aftPanel('SN Assignflow — assignment groups');

(async function () {
    try {
        var existing = await aftLoadExisting();

        if (!Object.keys(existing.userById).length) {
            aftSay('No aft.* users exist yet. Creating them first, since the groups', AFT_WARN);
            aftSay('reference them.', AFT_WARN);
            await aftEnsureUsers(existing);
        }

        await aftEnsureGroups(existing);

        aftHeading('Agent rows each group should end up with');
        AFT_GROUPS.forEach(function (g) {
            var live = existing.groupByName[g.name];
            aftSay(g.name + '  [' + g.table + ']', AFT_HEAD, true);
            aftSay(g.desc, AFT_DIM, true);
            g.agents.forEach(function (a, i) {
                var row = aftAgentRow(a, existing.userById, false);
                var shown = row.user_name || row.name || row.sys_id || '(empty)';
                aftSay('  ' + (i + 1) + '. ' + shown + '   by ' + a.by, '#C6C0EC', true);
                if (a.note) aftSay('     ' + a.note, AFT_DIM, true);
            });
            if (live) aftSay('  query ' + aftGroupQuery(live.sys_id), '#9E98CE', true);
            aftSay('');
        });

        aftOfferImports(existing);
        aftFinish('Groups ready');
    } catch (err) {
        aftFail(err);
    }
})();
