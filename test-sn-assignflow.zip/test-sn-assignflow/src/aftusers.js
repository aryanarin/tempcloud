// @name  aftusers
// @hint  [AFT] Create only the test users, and show why each one exists
// @order 20

aftPanel('SN Assignflow — test users');

(async function () {
    try {
        var existing = await aftLoadExisting();
        await aftEnsureUsers(existing);

        aftHeading('Why each user is here');
        AFT_USERS.forEach(function (def) {
            var live = existing.userById[def.id];
            aftSay(def.id + (def.active ? '' : '  [INACTIVE]'), AFT_HEAD, true);
            aftSay(def.why, AFT_DIM, true);
            aftSay('sys_id ' + (live ? live.sys_id : 'not created'), '#C6C0EC', true);
            aftSay('');
        });

        aftSay('Note ' + AFT_GHOST_ID + ' is referenced by the AFT Corner Cases group', AFT_WARN);
        aftSay('but deliberately never created, so the engine has something to fail on.', AFT_WARN);

        aftOfferImports(existing);
        aftFinish('Users ready');
    } catch (err) {
        aftFail(err);
    }
})();
