// @name  aftexport
// @hint  [AFT] Re-download the SN Assignflow import files (creates nothing)
// @order 60

aftPanel('SN Assignflow — import files');
aftSay('Reads the current AFT users and groups and rebuilds the import files.', AFT_DIM);
aftSay('Nothing is created or changed.', AFT_DIM);

(async function () {
    try {
        var existing = await aftLoadExisting();

        aftHeading('Found');
        aftSay(existing.users.length + ' aft.* user(s)', '#C6C0EC');
        aftSay(existing.groups.length + ' AFT group(s)', '#C6C0EC');

        if (!existing.groups.length) {
            aftSay('');
            aftSay('Nothing to export — run \\aftsetup first.', AFT_ERR);
            aftFinish('Nothing to export');
            return;
        }

        var missing = AFT_USERS.filter(function (d) { return !existing.userById[d.id]; });
        if (missing.length) {
            aftSay('');
            aftSay(missing.length + ' expected user(s) are missing: ' +
                   missing.map(function (d) { return d.id; }).join(', '), AFT_WARN);
            aftSay('The files will still be written, but with blank sys_ids for those.', AFT_DIM);
        }

        aftOfferImports(existing);
        aftFinish('Ready to download');
    } catch (err) {
        aftFail(err);
    }
})();
