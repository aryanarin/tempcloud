#!/usr/bin/env node
'use strict';

// Regression check for the pure logic in SN Assignflow's shared.js.
//
//   node verify-shared-logic.js
//
// Nothing here touches a browser or a ServiceNow instance: it loads shared.js
// into a plain Node context and exercises the parts that can be tested without
// one — host matching, the CSV and JSON importers, agent resolution rules,
// suggestion ranking and settings normalisation. It also parses the fixture
// files in fixtures/ and asserts they land the way the test plan says.
//
// Exits non-zero on any failure, so it can gate a change to the extension.

const fs   = require('fs');
const path = require('path');
const vm   = require('vm');

const EXT = process.env.SNAF_DIR ||
            path.resolve(__dirname, '..', 'assignflow-main', 'chrome');
const SHARED = path.join(EXT, 'shared.js');

if (!fs.existsSync(SHARED)) {
    console.error('Could not find shared.js at ' + SHARED);
    console.error('Set SNAF_DIR to the extension\'s chrome/ folder and try again.');
    process.exit(1);
}
vm.runInThisContext(fs.readFileSync(SHARED, 'utf8'), { filename: 'shared.js' });

let pass = 0, fail = 0;
function eq(label, actual, expected) {
    const a = JSON.stringify(actual), e = JSON.stringify(expected);
    if (a === e) { pass++; console.log('  ok    ' + label); }
    else {
        fail++;
        console.log('  FAIL  ' + label);
        console.log('          got      ' + a);
        console.log('          expected ' + e);
    }
}
function group(name) { console.log('\n' + name); }

// ── Host matching ─────────────────────────────────────────────────────────────
group('Cloud host detection (must not be spoofable)');
eq('instance subdomain',        snafIsServiceNowCloud('dev12345.service-now.com'), true);
eq('bare apex',                 snafIsServiceNowCloud('service-now.com'), true);
eq('deep subdomain',            snafIsServiceNowCloud('a.b.service-now.com'), true);
eq('prefix lookalike rejected', snafIsServiceNowCloud('evilservice-now.com'), false);
eq('suffix lookalike rejected', snafIsServiceNowCloud('service-now.com.evil.io'), false);
eq('hyphen lookalike rejected', snafIsServiceNowCloud('not-service-now.com'), false);
eq('empty rejected',            snafIsServiceNowCloud(''), false);

group('Domain to match pattern');
eq('bare host',        snafDomainToPattern('sn.example.com'), '*://sn.example.com/*');
eq('full url',         snafDomainToPattern('https://sn.example.com/nav_to.do'), '*://sn.example.com/*');
eq('port stripped',    snafDomainToPattern('sn.example.com:8443'), '*://sn.example.com/*');
eq('credentials',      snafDomainToPattern('https://user:pw@sn.example.com/x'), '*://sn.example.com/*');
eq('query stripped',   snafDomainToPattern('sn.example.com/?a=b'), '*://sn.example.com/*');
eq('case folded',      snafDomainToPattern('SN.Example.COM'), '*://sn.example.com/*');
eq('wildcard kept',    snafDomainToPattern('*.example.com'), '*://*.example.com/*');
eq('localhost',        snafDomainToPattern('localhost'), '*://localhost/*');
eq('blank rejected',   snafDomainToPattern('   '), null);
eq('bare star',        snafDomainToPattern('*'), null);
eq('spaces rejected',  snafDomainToPattern('not a host'), null);
eq('round trip',       snafPatternToDomain(snafDomainToPattern('sn.example.com')), 'sn.example.com');

group('Host matching');
eq('exact',              snafHostMatchesPattern('sn.example.com', '*://sn.example.com/*'), true);
eq('case insensitive',   snafHostMatchesPattern('SN.Example.com', '*://sn.example.com/*'), true);
eq('different host',     snafHostMatchesPattern('other.example.com', '*://sn.example.com/*'), false);
eq('prefix attack',      snafHostMatchesPattern('evil-sn.example.com', '*://sn.example.com/*'), false);
eq('suffix attack',      snafHostMatchesPattern('sn.example.com.evil.io', '*://sn.example.com/*'), false);
eq('wildcard sub',       snafHostMatchesPattern('sn.example.com', '*://*.example.com/*'), true);
eq('wildcard apex',      snafHostMatchesPattern('example.com', '*://*.example.com/*'), true);
eq('wildcard deep',      snafHostMatchesPattern('a.b.example.com', '*://*.example.com/*'), true);
eq('wildcard lookalike', snafHostMatchesPattern('notexample.com', '*://*.example.com/*'), false);

group('Combined allow-list');
eq('cloud always allowed', snafHostAllowed('dev1.service-now.com', []), true);
eq('custom allowed',       snafHostAllowed('sn.example.com', ['*://sn.example.com/*']), true);
eq('unknown denied',       snafHostAllowed('random.io', ['*://sn.example.com/*']), false);
eq('null list denied',     snafHostAllowed('random.io', null), false);

group('Instance detection heuristic');
function fakeDoc(o) {
    o = o || {};
    return {
        cookie: o.cookie || '',
        getElementById: id => (o.ids || []).includes(id) ? {} : null,
        querySelector:  s  => (o.sel || []).some(x => s.includes(x)) ? {} : null
    };
}
const at = (host, pathname) => ({ hostname: host, pathname: pathname || '/' });
eq('cloud short-circuits',    snafLooksLikeServiceNow(fakeDoc(), at('x.service-now.com')), true);
eq('classic gsft_main',       snafLooksLikeServiceNow(fakeDoc({ ids: ['gsft_main'] }), at('sn.corp.internal')), true);
eq('sysparm_ck field',        snafLooksLikeServiceNow(fakeDoc({ sel: ['sysparm_ck'] }), at('sn.corp.internal')), true);
eq('now experience shell',    snafLooksLikeServiceNow(fakeDoc({ sel: ['sn-application-shell'] }), at('sn.corp.internal')), true);
eq('glide cookie',            snafLooksLikeServiceNow(fakeDoc({ cookie: 'glide_user_route=abc' }), at('sn.corp.internal')), true);
eq('nav_to.do path',          snafLooksLikeServiceNow(fakeDoc(), at('sn.corp.internal', '/nav_to.do')), true);
eq('/now/ path',              snafLooksLikeServiceNow(fakeDoc(), at('sn.corp.internal', '/now/nav/ui')), true);
eq('unrelated site rejected', snafLooksLikeServiceNow(fakeDoc({ cookie: 'session=1' }), at('news.example.com', '/article/1')), false);
eq('bare host rejected',      snafLooksLikeServiceNow(fakeDoc(), at('example.com', '/')), false);

// ── Query handling ────────────────────────────────────────────────────────────
group('ServiceNow URL to query and table');
eq('classic query',
   snafExtractQuery('https://x.service-now.com/incident_list.do?sysparm_query=assignment_group%3Dabc%5Eassigned_toISEMPTY'),
   'assignment_group=abc^assigned_toISEMPTY');
eq('classic table',
   snafExtractTable('https://x.service-now.com/incident_list.do?sysparm_query=active%3Dtrue'), 'incident');
eq('double-encoded table',
   snafExtractTable('https://x.service-now.com/now/nav/ui/classic/params/target/sc_task_list.do%3Fsysparm_query%3Dactive%253Dtrue'),
   'sc_task');
eq('double-encoded query',
   snafExtractQuery('https://x.service-now.com/now/nav/ui/classic/params/target/sc_task_list.do%3Fsysparm_query%3Dactive%253Dtrue%255Eassigned_toISEMPTY'),
   'active=true^assigned_toISEMPTY');
eq('no query', snafExtractQuery('https://x.service-now.com/incident_list.do'), null);

group('Unassigned-only guard');
eq('appended when absent',    snafEnsureUnassigned('assignment_group=abc'), 'assignment_group=abc^assigned_toISEMPTY');
eq('left alone when present', snafEnsureUnassigned('assignment_group=abc^assigned_toISEMPTY'), 'assignment_group=abc^assigned_toISEMPTY');
eq('respects a different constraint', snafEnsureUnassigned('assigned_to=xyz'), 'assigned_to=xyz');
eq('empty stays empty',       snafEnsureUnassigned(''), '');

// ── Agent resolution ──────────────────────────────────────────────────────────
group('Agent resolution hints');
const SYS = '1474e7651b69c010f826bb31dd4d1a2b';
eq('sys_id wins over user id', snafResolveHint({ sys_id: SYS, user_name: 'aft.alpha' }).mode, 'ready');
eq('user id triggers lookup',  snafResolveHint({ user_name: 'aft.alpha' }).mode, 'lookup');
eq('lookup is by user_name',   snafResolveHint({ user_name: 'aft.alpha' }).field, 'user_name');
eq('bare token read as login', snafResolveHint({ name: 'aft.alpha' }).field, 'user_name');
eq('spaced name read as name', snafResolveHint({ name: 'AFT Alpha' }).field, 'name');
eq('sys_id in the name slot',  snafResolveHint({ name: SYS.toUpperCase() }).mode, 'ready');
eq('sys_id folded lowercase',  snafResolveHint({ name: SYS.toUpperCase() }).sys_id, SYS);
eq('empty row invalid',        snafResolveHint({}).mode, 'invalid');
eq('short sys_id invalid',     snafResolveHint({ sys_id: 'deadbeef' }).mode, 'invalid');

group('sys_id validation');
eq('32 hex accepted',   snafIsSysId(SYS), true);
eq('31 chars rejected', snafIsSysId(SYS.slice(0, 31)), false);
eq('non-hex rejected',  snafIsSysId(SYS.slice(0, 31) + 'z'), false);
eq('empty rejected',    snafIsSysId(''), false);

group('User lookup query');
eq('user id form ORs email and name',
   snafUserQuery('user_name', 'aft.alpha'),
   'user_name=aft.alpha^ORemail=aft.alpha^ORname=aft.alpha');
eq('name form is scoped to active users',
   snafUserQuery('name', 'AFT Alpha').startsWith('active=true^name=AFT Alpha'), true);

// ── Directory ─────────────────────────────────────────────────────────────────
group('Directory merge and de-duplication');
const base = snafNormaliseUsers([{ name: 'AFT Alpha', user_name: 'aft.alpha' }]);
const m1 = snafMergeUsers(base, [{ user_name: 'aft.alpha', sys_id: SYS }]);
eq('tops up sys_id, adds nothing', [m1.added, m1.updated, m1.users.length], [0, 1, 1]);
eq('sys_id landed',                m1.users[0].sys_id, SYS);
eq('existing name kept',           m1.users[0].name, 'AFT Alpha');
eq('new person appended',          snafMergeUsers(m1.users, [{ name: 'New', user_name: 'newp' }]).added, 1);
eq('user id match is case-insensitive',
   snafMergeUsers(m1.users, [{ user_name: 'AFT.ALPHA', name: 'Changed' }]).users.length, 1);
eq('dedup by sys_id on load', snafNormaliseUsers([
    { name: 'A',   sys_id: SYS },
    { name: 'Dup', sys_id: SYS.toUpperCase() }
]).length, 1);
eq('wholly empty record dropped', snafNormaliseUsers([{ name: '', user_name: '', sys_id: '' }]).length, 0);

group('Suggestion ranking');
const dir = snafNormaliseUsers([
    { name: 'AFT Alpha',    user_name: 'aft.alpha' },
    { name: 'Bob Alpha',    user_name: 'bob.a' },
    { name: 'AFT Charlie',  user_name: 'aft.charlie' },
    { name: 'Alp Anderson', user_name: 'alp.and' }
]);
eq('exact user id first',        snafMatchUsers(dir, 'aft.alpha')[0].user_name, 'aft.alpha');
eq('user-id prefix beats name',  snafMatchUsers(dir, 'alp')[0].user_name, 'alp.and');
eq('name substring still hits',  snafMatchUsers(dir, 'alpha').map(u => u.user_name).sort(), ['aft.alpha', 'bob.a']);
eq('no match is empty',          snafMatchUsers(dir, 'zzzz').length, 0);
eq('empty term returns all',     snafMatchUsers(dir, '').length, 4);
eq('limit respected',            snafMatchUsers(dir, '', 2).length, 2);
eq('find by user id',            snafFindUser(dir, 'aft.charlie').name, 'AFT Charlie');
eq('find is case-insensitive',   snafFindUser(dir, 'AFT.CHARLIE').name, 'AFT Charlie');
eq('find by display name',       snafFindUser(dir, 'AFT Alpha').user_name, 'aft.alpha');
eq('unknown is null',            snafFindUser(dir, 'nobody'), null);

// ── CSV ───────────────────────────────────────────────────────────────────────
group('CSV round trip');
const rt = snafParseUserImport(snafUsersToCsv(snafNormaliseUsers([
    { name: 'AFT Alpha', user_name: 'aft.alpha', sys_id: SYS },
    { name: 'Doe, Jane', user_name: 'jdoe' }
])));
eq('count preserved',   rt.length, 2);
eq('user id preserved', rt[0].user_name, 'aft.alpha');
eq('sys_id preserved',  rt[0].sys_id, SYS);
eq('comma survives',    rt[1].name, 'Doe, Jane');
eq('newline flattened',
   snafParseUserImport(snafUsersToCsv([{ name: 'Two\nLines', user_name: 'nl' }]))[0].name,
   'Two Lines');

// ── Fixtures ──────────────────────────────────────────────────────────────────
group('fixtures/users-clean.csv');
const clean = snafParseUserImport(fs.readFileSync(path.join(__dirname, 'fixtures', 'users-clean.csv'), 'utf8'));
eq('four rows',        clean.length, 4);
eq('all have user ids', clean.every(u => !!u.user_name), true);
eq('none have sys_ids', clean.every(u => !u.sys_id), true);
eq('first is alpha',   clean[0].user_name, 'aft.alpha');

group('fixtures/users-messy.csv');
const messy = snafParseUserImport(fs.readFileSync(path.join(__dirname, 'fixtures', 'users-messy.csv'), 'utf8'));
const byName = t => messy.find(u => u.user_name === t) || {};
eq('blank and empty rows dropped', messy.length, 7);
eq('quoted comma in name',   messy[0].name, 'Doe, Jane');
eq('aliased headers mapped', byName('jdoe.messy').email, 'jane@example.test');
eq('name-only row kept',     messy.some(u => u.name === 'Only Name Here' && !u.user_name), true);
eq('user-id-only row kept',  byName('useridonly').name, '');
eq('uppercase sys_id folded', byName('aft.upper').sys_id, '1474e7651b69c010f826bb31dd4d1a2b');
eq('invalid sys_id discarded', byName('aft.badsys').sys_id, '');
eq('cells trimmed',          byName('aft.padded').name, 'Padded Name');
eq('escaped quotes',         byName('aft.quoted').name, 'Quote "Inside" Name');
eq('unknown column ignored', byName('jdoe.messy').note, 'quoted comma in the display name');

group('fixtures/users-headerless.csv');
const noHdr = snafParseUserImport(fs.readFileSync(path.join(__dirname, 'fixtures', 'users-headerless.csv'), 'utf8'));
eq('all four rows read positionally', noHdr.length, 4);
eq('column 1 is the name',    noHdr[0].name, 'AFT Alpha');
eq('column 2 is the user id', noHdr[0].user_name, 'aft.alpha');
eq('quoted comma handled',    noHdr[2].name, 'Comma, Person');
eq('column 3 is the sys_id',  noHdr[3].sys_id, '1474e7651b69c010f826bb31dd4d1a2b');

group('fixtures/groups-messy.json');
const messyGroups = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'groups-messy.json'), 'utf8'));
eq('parses',              Array.isArray(messyGroups.groups), true);
eq('five groups',         messyGroups.groups.length, 5);
eq('bundled user present', Array.isArray(messyGroups.users) && messyGroups.users.length, 1);
// The importer defaults these; the fixture omits them on purpose.
eq('a group omits its id',     messyGroups.groups.every(g => g.id === undefined), true);
eq('a group omits agents',     messyGroups.groups.some(g => g.agents === undefined), true);
eq('a group omits its query',  messyGroups.groups.some(g => g.query === undefined), true);
eq('a group omits its table',  messyGroups.groups.some(g => g.table === undefined), true);
eq('an inactive group',        messyGroups.groups.some(g => g.active === false), true);
// Mixed agent shapes must all classify without throwing.
const shapes = messyGroups.groups[0].agents.map(a => snafResolveHint(a).mode);
eq('mixed agent shapes classify', shapes, ['lookup', 'lookup', 'ready', 'lookup', 'lookup']);

// ── Settings ──────────────────────────────────────────────────────────────────
group('Settings defaults and clamping');
const d = snafDefaultSettings();
eq('keep-alive on by default',      d.keepAlive.enabled, true);
eq('keep-alive every 2 minutes',    d.keepAlive.minutes, 2);
eq('forced while running',          d.keepAlive.forceWhileRunning, true);
eq('dry run off',                   d.rules.dryRun, false);
eq('unassigned guard on',           d.rules.requireUnassigned, true);
eq('user-id resolution on',         d.rules.resolveUserIds, true);
eq('undefined gives defaults',      snafNormaliseSettings(undefined).keepAlive.minutes, 2);
eq('garbage gives defaults',        snafNormaliseSettings('nonsense').rules.defaultTable, 'incident');
eq('minutes clamped high',          snafNormaliseSettings({ keepAlive: { minutes: 9999 } }).keepAlive.minutes, 60);
eq('minutes clamped low',           snafNormaliseSettings({ keepAlive: { minutes: 0 } }).keepAlive.minutes, 1);
eq('negative cap clamped',          snafNormaliseSettings({ rules: { maxPerCycle: -5 } }).rules.maxPerCycle, 0);
eq('enabled false respected',       snafNormaliseSettings({ keepAlive: { enabled: false } }).keepAlive.enabled, false);
eq('partial keeps other defaults',  snafNormaliseSettings({ rules: { dryRun: true } }).rules.requireUnassigned, true);

group('Group runnability');
const good = { active: true, query: 'active=true', agents: [{ sys_id: SYS, active: true }] };
eq('runnable',                snafGroupIsRunnable(good), true);
eq('inactive group',          snafGroupIsRunnable(Object.assign({}, good, { active: false })), false);
eq('no query',                snafGroupIsRunnable(Object.assign({}, good, { query: '' })), false);
eq('no active agent',         snafGroupIsRunnable({ active: true, query: 'q', agents: [{ active: false }] }), false);
eq('agent count skips off',   snafCountActiveAgents({ agents: [{ active: true }, { active: false }, {}] }), 2);

group('Presentation helpers');
eq('one agent',        snafPlural(1, 'agent'), '1 agent');
eq('two agents',       snafPlural(2, 'agent'), '2 agents');
eq('irregular plural', snafPlural(2, 'person', 'people'), '2 people');
eq('irregular single', snafPlural(1, 'person', 'people'), '1 person');
eq('initials of two words', snafInitials('AFT Alpha'), 'AA');
eq('initials of dotted id', snafInitials('aft.alpha'), 'AA');
eq('initials fallback',     snafInitials(''), '?');
eq('avatar hue stable',     snafAvatarHue('aft.alpha'), snafAvatarHue('aft.alpha'));
eq('avatar hue in range',   snafAvatarHue('aft.alpha') >= 215 && snafAvatarHue('aft.alpha') <= 325, true);

// ── Summary ───────────────────────────────────────────────────────────────────
console.log('\n' + '─'.repeat(62));
console.log(pass + ' passed, ' + fail + ' failed.');
process.exit(fail ? 1 : 0);
