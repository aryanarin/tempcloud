#!/usr/bin/env node
'use strict';

// Assembles src/*.js into an SN Commands import file.
//
//   node build-commands.js
//
// Each command in the output is standalone: src/_prelude.js is prepended to
// every body, because SN Commands executes one script with no shared scope.
// That means the fixture definitions live in exactly one place here, even though
// they end up duplicated in the generated file.
//
// Runs on a bare Node install. Validates as it goes and exits non-zero on any
// problem, so a broken command can't reach the instance.

const fs   = require('fs');
const path = require('path');
const vm   = require('vm');

const ROOT    = __dirname;
const SRC     = path.join(ROOT, 'src');
const OUT     = path.join(ROOT, 'sn-commands-assignflow-tests.json');
const PRELUDE = path.join(SRC, '_prelude.js');

let failures = 0;
function fail(msg) { failures++; console.log('  FAIL  ' + msg); }
function pass(msg) { console.log('  ok    ' + msg); }

// ── Read the prelude ─────────────────────────────────────────────────────────
if (!fs.existsSync(PRELUDE)) {
    console.error('src/_prelude.js is missing.');
    process.exit(1);
}
const prelude = fs.readFileSync(PRELUDE, 'utf8');

// Identifiers the prelude provides. Used to catch a body calling something that
// does not exist — the failure mode is otherwise a silent ReferenceError inside
// the instance, which is miserable to debug from a ServiceNow page.
const preludeDefs = new Set();
{
    let m;
    const fnRe = /^(?:async\s+)?function\s+(aft[A-Za-z0-9_]*)/gm;
    while ((m = fnRe.exec(prelude))) preludeDefs.add(m[1]);
    const varRe = /^var\s+(AFT_[A-Za-z0-9_]+)/gm;
    while ((m = varRe.exec(prelude))) preludeDefs.add(m[1]);
    const globalRe = /^var\s+(AFT_[A-Z]+|aft[A-Za-z0-9_]*)\s*=/gm;
    while ((m = globalRe.exec(prelude))) preludeDefs.add(m[1]);
}

console.log('Prelude');
pass(preludeDefs.size + ' shared identifiers: ' +
     Array.from(preludeDefs).sort().slice(0, 6).join(', ') + ', …');

try {
    new vm.Script('(function(){' + prelude + '})();', { filename: '_prelude.js' });
    pass('_prelude.js parses');
} catch (e) {
    fail('_prelude.js — ' + e.message);
}

// ── Collect the command bodies ───────────────────────────────────────────────
const bodyFiles = fs.readdirSync(SRC)
    .filter(f => f.endsWith('.js') && f !== '_prelude.js')
    .sort();

if (!bodyFiles.length) {
    console.error('No command bodies found in src/.');
    process.exit(1);
}

const base = Date.now();
const commands = [];

console.log('\nCommands');

bodyFiles.forEach((file, index) => {
    const raw = fs.readFileSync(path.join(SRC, file), 'utf8');

    // Header directives: // @name, // @hint, // @order
    const meta = {};
    raw.split(/\r?\n/).forEach(line => {
        const m = line.match(/^\s*\/\/\s*@(\w+)\s+(.*)$/);
        if (m) meta[m[1].toLowerCase()] = m[2].trim();
    });

    const name = meta.name || path.basename(file, '.js');
    const hint = meta.hint || '';

    if (!meta.name) fail(file + ' has no // @name directive');
    if (!meta.hint) fail(file + ' has no // @hint directive');
    if (!/^[a-z][a-z0-9]*$/.test(name)) {
        fail(file + ': "' + name + '" is not a safe command name (lowercase letters and digits)');
    }

    const body = raw
        .split(/\r?\n/)
        .filter(line => !/^\s*\/\/\s*@(name|hint|order)\b/.test(line))
        .join('\n')
        .trim();

    // Every aft* identifier a body uses must come from the prelude or be
    // declared locally.
    //
    // Helpers are aft + CapitalisedName and constants are AFT_*. Requiring the
    // capital keeps command names out of the match — bodies mention "\aftsetup"
    // and "\aftreset" in their instructions, and those are prose, not calls.
    const used = new Set();
    let m;
    const useRe = /\b(aft[A-Z][A-Za-z0-9_]*|AFT_[A-Za-z0-9_]+)\b/g;
    while ((m = useRe.exec(body))) used.add(m[1]);

    used.forEach(id => {
        if (preludeDefs.has(id)) return;
        const localFn  = new RegExp('function\\s+' + id + '\\b').test(body);
        const localVar = new RegExp('(?:const|let|var)\\s+' + id + '\\b').test(body);
        if (localFn || localVar) return;
        fail(file + ' uses ' + id + ', which the prelude does not define');
    });

    const script = '(function () {\n' + prelude + '\n\n// ── Command body ' +
                   '─'.repeat(56) + '\n' + body + '\n})();';

    try {
        new vm.Script(script, { filename: file });
    } catch (e) {
        fail(file + ' — ' + e.message);
        return;
    }

    // Matches the id shape SN Commands produces itself: epoch millis followed by
    // a decimal fraction.
    const id = String(base) + Math.random().toString().slice(1);

    const command = {
        createdAt: base,
        hint:      hint,
        id:        id,
        name:      name,
        script:    script,
        updatedAt: base
    };
    if (meta.order) command.order = parseInt(meta.order, 10);

    commands.push(command);
    pass(name.padEnd(12, ' ') + (script.length / 1024).toFixed(1) + ' KB   ' + hint);
});

// ── Sanity checks on the collection ──────────────────────────────────────────
console.log('\nCollection');

const names = commands.map(c => c.name);
const dupes = names.filter((n, i) => names.indexOf(n) !== i);
if (dupes.length) fail('duplicate command names: ' + Array.from(new Set(dupes)).join(', '));
else pass(names.length + ' unique names: ' + names.join(', '));

const ids = commands.map(c => c.id);
if (new Set(ids).size !== ids.length) fail('generated ids are not unique');
else pass('all ids unique');

// A destructive command must not be the lowest-ordered one in the palette.
const reset = commands.find(c => c.name === 'aftreset');
if (reset && (reset.order || 0) < 50) {
    fail('aftreset should sort late in the palette — give it a high @order');
} else if (reset) {
    pass('aftreset sorts last (@order ' + reset.order + ')');
}

// ── Write ────────────────────────────────────────────────────────────────────
if (failures) {
    console.log('\n' + '─'.repeat(60));
    console.log(failures + ' problem(s) — nothing written.');
    process.exit(1);
}

const payload = { version: 1, commands: commands };
const json = JSON.stringify(payload, null, 2);

// Round-trip it, so a malformed file can never be handed to the extension.
try {
    const back = JSON.parse(json);
    if (!Array.isArray(back.commands) || back.commands.length !== commands.length) {
        throw new Error('command count changed on round trip');
    }
} catch (e) {
    console.log('\nGenerated JSON did not round-trip: ' + e.message);
    process.exit(1);
}

fs.writeFileSync(OUT, json + '\n', 'utf8');

console.log('\n' + '─'.repeat(60));
console.log('Wrote ' + path.basename(OUT) + '  ' + (json.length / 1024).toFixed(1) + ' KB  ' +
            commands.length + ' commands');
console.log('Import it in SN Commands → Settings → Import.');
