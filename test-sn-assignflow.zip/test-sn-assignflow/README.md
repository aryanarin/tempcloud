# SN Assignflow test harness

Fixtures and checks for [SN Assignflow](../assignflow-main), built to run against
a ServiceNow personal developer instance.

Two independent pieces:

- **`sn-commands-assignflow-tests.json`** — an importable set of
  [SN Commands](../sncommands-main) commands that provision a test environment in
  your PDI: users, assignment groups, memberships and tickets, chosen so the
  extension is forced down every interesting path. It also generates the
  SN Assignflow import files for you.
- **`verify-shared-logic.js`** — 142 assertions against the extension's own
  parsing and matching logic. Plain Node, no browser, no instance.

## Quick start

```powershell
# 1. Check the extension's logic still holds (no browser needed)
node verify-shared-logic.js

# 2. Build the command file, if you changed anything under src/
node build-commands.js
```

Then in the browser:

1. **SN Commands** → Settings → Import → `sn-commands-assignflow-tests.json`.
2. Open your PDI and run `\aftsetup`.
3. Save the four files it offers.
4. In SN Assignflow, import `aft-groups-userids.json` under
   Assignment Groups → Import.
5. Work through [TEST_PLAN.md](TEST_PLAN.md).
6. Run `\aftreset` when you're finished.

## The commands

| Command | What it does |
|---|---|
| `\aftsetup` | Everything: 9 users, 4 groups, memberships, 26 tickets. Then offers the import files. Start here. |
| `\aftusers` | Users only, with an explanation of why each one exists. |
| `\aftgroups` | Groups and membership only. Prints the agent rows each group should end up with. |
| `\afttickets` | Tops the queues up by another round. Run it twice more to get 36 open tickets for testing the per-cycle caps. |
| `\aftstatus` | **The verification command.** Reads back every `[AFT]` ticket, reports the per-agent distribution as a bar chart, and checks the round robin is even, that pre-assigned tickets were left alone, and that only the one valid agent row in the corner-case group received work. |
| `\aftexport` | Re-downloads the import files without creating anything. |
| `\aftreset` | Deletes everything the harness created, in dependency order, after confirming. |

All of them are idempotent. Running `\aftsetup` twice tops fixtures up rather
than duplicating them.

### What it creates, and how it stays contained

| Records | Marker |
|---|---|
| Users | `user_name` starts with `aft.` |
| Groups | `name` starts with `AFT` |
| Tickets | `short_description` starts with `[AFT]` |

Nothing without one of those markers is ever read, written or deleted. Everything
runs against the instance in the current tab, on the session already open there.

The fixtures are chosen for their corner cases: two users deliberately share a
display name, one is inactive, one has a comma in their name, one group
references a user that does not exist, and one group's agent list contains an
empty row and a malformed `sys_id`. See the table at the top of
[TEST_PLAN.md](TEST_PLAN.md).

### Files it generates for you

`\aftsetup`, `\aftgroups`, `\aftusers` and `\aftexport` each offer four downloads:

| File | Use |
|---|---|
| `aft-groups-userids.json` | Groups with agents identified **only by user ID**, every `sys_id` blank. This is what forces SN Assignflow to resolve user IDs at run time — the case worth testing first. |
| `aft-groups-sysids.json` | The same groups with `sys_id`s pre-filled, for the fast path. |
| `aft-users-no-sysid.csv` | The user list without `sys_id`s, for testing **Resolve sys_ids**. |
| `aft-users-with-sysid.csv` | The same list resolved, for testing merge-on-reimport. |

The group queries are emitted **without** `^assigned_toISEMPTY` on purpose. The
*Only assign unassigned tickets* rule should add it, and the pre-assigned tickets
in AFT Rotation are there to prove it did.

## Editing the commands

`src/` is the source of truth. Don't edit the scripts in the SN Commands UI —
regenerate instead:

```powershell
node build-commands.js
```

`src/_prelude.js` holds the fixture definitions and the shared helpers, and is
prepended to every command body, because SN Commands runs each script with no
shared scope. That's why the generated file is ~200 KB for seven commands: the
prelude is repeated in each. It also means the fixture definitions exist in
exactly one place *here*, which is what matters when you change them.

A command body is an ordinary script plus three header directives:

```js
// @name  aftexample
// @hint  [AFT] What it does, shown in the palette
// @order 70
```

The builder validates as it goes and refuses to write on any problem: it parses
every assembled script, checks each `aft*` helper a body calls actually exists in
the prelude, rejects unsafe command names, checks for duplicate names and ids, and
confirms `aftreset` sorts late in the palette so it isn't the first thing you hit.

## `verify-shared-logic.js`

Loads `shared.js` straight out of the extension and exercises everything testable
without a browser:

- Cloud-host detection, including lookalike hosts like `evilservice-now.com` and
  `service-now.com.evil.io` that must **not** be accepted.
- Custom-domain pattern building and matching, including prefix and suffix
  spoofing attempts.
- The ServiceNow-instance detection heuristic.
- `sysparm_query` and table extraction, including multiply-encoded `/now/nav/`
  URLs.
- The unassigned-only guard.
- Agent resolution rules — when a value is treated as a `sys_id`, a user ID or a
  display name.
- CSV and JSON import, the CSV round trip, and directory merge and de-duplication.
- Suggestion ranking.
- Settings normalisation and clamping.
- Every file in `fixtures/`, asserted against the outcomes the test plan states.

It points at `../assignflow-main/chrome` by default. Override with
`SNAF_DIR=/path/to/chrome`.

## Fixtures

Hand-written import files for the paths the generated ones don't reach.

| File | Exercises |
|---|---|
| `users-clean.csv` | The ordinary case. |
| `users-messy.csv` | Aliased headers (`Full Name`, `USERNAME`, `Sys ID`, `E-Mail`), an unrecognised column, a quoted comma, escaped quotes, padded cells, a blank line, an all-empty row, a name-only row, a user-ID-only row, an uppercase `sys_id`, and a malformed `sys_id`. |
| `users-headerless.csv` | Positional parsing when no header is recognised. |
| `groups-messy.json` | Groups missing `id`, `agents`, `query` and `table`; an inactive group; a non-incident table; five different agent-row shapes; and a bundled user list. |

## Layout

```
test-sn-assignflow/
├── README.md
├── TEST_PLAN.md                       # the actual test cases
├── build-commands.js                  # src/ -> the importable JSON
├── verify-shared-logic.js             # 142 assertions, no browser needed
├── sn-commands-assignflow-tests.json  # generated; import this
├── src/
│   ├── _prelude.js                    # fixture definitions + shared helpers
│   ├── aftsetup.js
│   ├── aftusers.js
│   ├── aftgroups.js
│   ├── afttickets.js
│   ├── aftstatus.js
│   ├── aftexport.js
│   └── aftreset.js
└── fixtures/
    ├── users-clean.csv
    ├── users-messy.csv
    ├── users-headerless.csv
    └── groups-messy.json
```

## A caution

These scripts create and delete records with your own admin rights. They are
scoped by the `aft.` / `AFT` / `[AFT]` markers and will not touch anything else,
but point them at a **developer instance**, not production. `\aftreset` always
tells you what it found and waits for confirmation before deleting.
