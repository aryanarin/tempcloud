# SN Assignflow — test plan

Written against a ServiceNow personal developer instance (PDI). Every fixture is
created by the `\aft*` commands in
[`sn-commands-assignflow-tests.json`](sn-commands-assignflow-tests.json) and
removed again by `\aftreset`.

Nothing here touches a record the harness did not create. Users are `aft.*`,
groups are `AFT …`, tickets have `[AFT]` at the start of their short description.

---

## 0. Preparation

| # | Step |
|---|---|
| 0.1 | In **SN Commands** → Settings → Import, load `sn-commands-assignflow-tests.json`. Seven commands appear, all prefixed `aft`. |
| 0.2 | Open your PDI. Anywhere will do; the commands only need a session. |
| 0.3 | Type `\aftsetup` and run it. It creates 9 users, 4 groups, memberships and 26 tickets, then offers four downloads. Save all four. |
| 0.4 | Load SN Assignflow unpacked (`chrome/` or `firefox/`), then open its configuration page. |
| 0.5 | Run `node verify-shared-logic.js` from this folder. 142 assertions, all should pass. This checks the parsing and matching logic without a browser. |

`\aftsetup` is idempotent — running it twice tops fixtures up rather than
duplicating them.

### What the fixtures are for

| User | Purpose |
|---|---|
| `aft.alpha`, `aft.bravo`, `aft.charlie` | The rotation. Three agents, twelve tickets — an even four each. |
| `aft.delta` | Only ever referenced by user ID. The one row in the corner-case group that should work. |
| `aft.echo` | Referenced by **email address**, to exercise the email fallback in the lookup. |
| `aft.dupe1`, `aft.dupe2` | Share the display name *AFT Duplicate*. A name lookup must report the ambiguity rather than guess. |
| `aft.inactive` | Inactive in ServiceNow. A name lookup is scoped `active=true`, so it must not resolve. |
| `aft.comma` | Display name contains a comma — proves the CSV round trip quotes correctly. |
| `aft.ghost.does.not.exist` | Never created. Referenced anyway, so there is something to fail on. |

| Group | Table | Contents |
|---|---|---|
| AFT Rotation | `incident` | 12 unassigned + 3 already assigned to `aft.alpha` |
| AFT Corner Cases | `incident` | 6 unassigned, and six agent rows of which five are broken |
| AFT Change Table | `change_request` | 5 unassigned |
| AFT Empty Queue | `incident` | Nothing. The query deliberately matches no records. |

Group queries are emitted **without** `^assigned_toISEMPTY`. The
*Only assign unassigned tickets* rule is supposed to add it, and the
pre-assigned tickets exist to prove it did.

---

## 1. Global user list (Agents)

| # | Test | Expected |
|---|---|---|
| 1.1 | Import `fixtures/users-clean.csv` | 4 people, all with user IDs, none with a `sys_id`. Counters read 4 / 0 / 4. |
| 1.2 | With a PDI tab open, press **Resolve sys_ids** | All 4 resolve. Toast reports "4 resolved · via *your-instance*". |
| 1.3 | Close every ServiceNow tab, press **Resolve sys_ids** again | Refuses with "Open a ServiceNow tab first". Nothing changes. |
| 1.4 | Import `fixtures/users-messy.csv` | 7 people added. The blank line and the all-empty row are dropped. |
| 1.5 | Inspect the messy import | `Doe, Jane` keeps its comma. `aft.upper`'s sys_id is lowercased. `aft.badsys` has an **empty** sys_id — the malformed one was discarded. `aft.padded` is trimmed. `aft.quoted` reads `Quote "Inside" Name`. The unrecognised `Department` column is ignored. |
| 1.6 | Import `fixtures/users-headerless.csv` | Read positionally as name, user ID, sys_id. |
| 1.7 | Import `users-clean.csv` a second time | Merges. Toast says *updated*, not *added*, and the count does not grow. |
| 1.8 | Import `aft-users-with-sysid.csv` (from `\aftsetup`) over the no-sys_id version | The existing rows gain their sys_ids. Still 9 people, not 18. |
| 1.9 | Select 3 people → **Export selected** | File contains exactly 3. |
| 1.10 | **Export** → CSV → re-import the file | Identical list. `aft.comma`'s name survives the round trip. |
| 1.11 | Try to resolve `aft.inactive` by user ID | **Resolves.** The batch lookup is not scoped to active users, and looking up an inactive person's sys_id is legitimate. Contrast with 4.4. |
| 1.12 | Add a blank row with **+ Add User**, type nothing, reload the page | The empty row is gone. Rows need at least a name, user ID or sys_id to persist. |

---

## 2. Assignment groups

| # | Test | Expected |
|---|---|---|
| 2.1 | Import `aft-groups-userids.json` → replace | 4 groups. Every agent row shows **resolve on run** or **in directory**, none show a sys_id. |
| 2.2 | Open AFT Corner Cases | The malformed `deadbeef` row is outlined red and reads **incomplete**. |
| 2.3 | Type a letter in an agent name field | Suggestions from the global list, ranked with user-ID matches first. Arrow keys move, Enter accepts, Esc keeps what you typed. |
| 2.4 | Type a name that is not in the directory and add it | Accepted. Suggestions are optional. |
| 2.5 | Paste a filtered ServiceNow list URL into the converter | Query and table both filled. Try a `/now/nav/` URL too — those are double-encoded and should still work. |
| 2.6 | Edit a field, then click another group | Warns about unsaved changes. |
| 2.7 | Edit a field, press `Ctrl+S` | Saves. The amber dot next to *Save Changes* clears. |
| 2.8 | Edit a field, then close the tab | Browser asks to confirm. |
| 2.9 | Import `fixtures/groups-messy.json` → merge | All 5 import. Missing `id`, `agents`, `query` and `table` are defaulted rather than erroring. The bundled user is folded into the global list. |
| 2.10 | **Export** → select 2 of 4 | File has 2 groups, and a `users` array carrying only the agents those 2 reference. |
| 2.11 | Delete a group, then re-import and run | Round robin starts from position 0 — the orphaned cursor was cleaned up with the group. |

---

## 3. Engine, happy path

Use **AFT Rotation** with *Scope* set to it, so the corner cases don't add noise.

| # | Test | Expected |
|---|---|---|
| 3.1 | Rules → **Dry run** on. Launch the widget, press Start | Log lists 12 lines reading "*would go to*". The warn strip says nothing is being written. |
| 3.2 | Run `\aftstatus` | All 12 still unassigned. Dry run wrote nothing and moved no counters. |
| 3.3 | Dry run off. Start again | 12 assigned, log shows `INC… → AFT Alpha` and so on. |
| 3.4 | Run `\aftstatus` | 4 tickets each for alpha, bravo and charlie. **Spread 0.** Verdict: everything checks out. |
| 3.5 | Check the 3 pre-assigned tickets | Still on `aft.alpha`, untouched. `\aftstatus` confirms the unassigned-only rule held. |
| 3.6 | Look at the query the engine used | Log shows it appended `assigned_toISEMPTY` — the group's own query did not include it. |
| 3.7 | `\afttickets`, then run one cycle | The rotation **continues** from where it stopped rather than restarting at alpha. |
| 3.8 | Set Scope to **AFT Empty Queue** and run | "nothing to assign". No error, engine keeps its schedule. |
| 3.9 | Start, then press Stop mid-cycle | Halts. Log says "stopped mid-group". No partial corruption. |

---

## 4. Configuring agents by user ID

The headline feature. Start from an **empty** global user list to see it properly:
Settings → Reset, then re-import `aft-groups-userids.json` only.

| # | Test | Expected |
|---|---|---|
| 4.1 | Scope AFT Rotation, run one cycle | Log shows "resolving 3 user IDs…", then the assignments. |
| 4.2 | Open **Agents** | The three users have appeared, with sys_ids filled in, without you importing anything. |
| 4.3 | Run a second cycle | **No** "resolving" line. The sys_id was cached on the agent row. |
| 4.4 | Scope AFT Corner Cases, run one cycle | Exactly five failures, each named: `AFT Duplicate` matches 2 users → *use the exact user ID or a sys_id*; `AFT Inactive` → *no ServiceNow user matches* (the name query is `active=true` scoped); the ghost ID → *no user matches*; the empty row → skipped before any lookup; `deadbeef` → skipped. Only `aft.delta` receives work. |
| 4.5 | Run `\aftstatus` | AFT Corner Cases reports "only aft.delta received work — the five bad rows were all correctly rejected". |
| 4.6 | Rules → **Resolve user IDs automatically** off. Reset the directory, run again | Rows with no sys_id are skipped with *"…has no sys_id and user-ID resolution is off"*. Nothing is looked up. |
| 4.7 | Scope AFT Change Table, run | `aft.echo` is referenced by **email address** and still resolves — the lookup ORs `user_name`, `email` and `name`. |

---

## 5. Rules

| # | Test | Expected |
|---|---|---|
| 5.1 | `\afttickets` twice, then set **Maximum assignments per cycle** = 5, run one cycle | Exactly 5 assigned. Log: "cycle cap of 5 reached". |
| 5.2 | Set **Maximum per agent, per cycle** = 1, run one cycle | Exactly 3 assigned — one each. Log: "every agent is at the per-cycle cap". |
| 5.3 | Set both to 0, run | Uncapped again. |
| 5.4 | Turn **Only assign unassigned tickets** off, then run | The 3 pre-assigned tickets **are** reassigned. This is the rule earning its keep — run `\aftreset` and `\aftsetup` afterwards to restore the fixture. |
| 5.5 | Change **Default table** and **Cycle interval**, then create a new group | The new group picks them up. Existing groups are untouched. |
| 5.6 | Change a rule while the engine is running | Takes effect on the next cycle. No restart needed. |

---

## 6. Widget behaviour

| # | Test | Expected |
|---|---|---|
| 6.1 | Toolbar popup → **Launch Widget** | Widget appears. Button becomes *Hide Widget*. |
| 6.2 | Press the **minimise** button (`—`) | Collapses to the small pill. |
| 6.3 | Click the pill | Expands again. |
| 6.4 | **Click the panel header, on the title** | **Nothing happens.** This is the bug from 3.x — the header used to toggle, so any click near the title collapsed the panel. |
| 6.5 | Drag the header | Moves. Cannot be dragged off-screen. |
| 6.6 | Navigate to another ServiceNow page | Widget reappears where you left it, in the same open or minimised state. |
| 6.7 | Press **close** (`✕`) | Widget hides. Reopen it — all configuration intact. |
| 6.8 | Set Scope to one group | Only that group runs. |
| 6.9 | Change **Every** to 30s | Countdown and the pill timer both follow. |
| 6.10 | Open the popup while the engine runs | Status reads "Engine running on *your-instance*". |

---

## 7. Session keep-alive

| # | Test | Expected |
|---|---|---|
| 7.1 | Open a PDI tab. DevTools → Network, filter `session` | A request to `/api/now/session` roughly every 2 minutes. The widget footer shows a green pulse icon. |
| 7.2 | Settings → keep-alive **off**, engine stopped | Pings stop. |
| 7.3 | Keep-alive off, but **start the engine** | Pings resume — *Always keep alive while the engine runs* overrides the toggle. |
| 7.4 | DevTools → Network → block `*/api/now/session`, wait for two pings | Next ping goes to `/now/nav/header`. Rotation on failure works. |
| 7.5 | Switch to another tab for a minute, come back | A ping fires immediately on refocus. |
| 7.6 | Set the interval to 1 minute | Takes effect at once, without a reload. |
| 7.7 | **Grant "all websites"**, then open a non-ServiceNow site | **No ping.** Nothing is requested. The widget can be launched but shows *"This page does not look like a ServiceNow instance"* and Start refuses. |

7.7 is the important one: a broad permission must not turn the pinger loose on
unrelated servers.

---

## 8. Instances and on-premise support

| # | Test | Expected |
|---|---|---|
| 8.1 | Fresh install, check the browser's permission list | Only `*.service-now.com`. No company domain anywhere. |
| 8.2 | Settings → Instances | `*.service-now.com` listed as **Built in**, not removable. No other entries. |
| 8.3 | Add `example.com` | Browser prompts. Approve it; the row shows **Granted**. |
| 8.4 | Open `example.com` and launch the widget | It appears — the dynamic content script registered without an extension reload. Because you named the domain it is trusted, so Start is allowed; it will then fail on the Table API, which is the correct outcome for a site that isn't ServiceNow. |
| 8.5 | Revoke `example.com` from the browser's own extension settings, return to the Instances panel | Row shows **Access revoked** with a **Grant again** action. |
| 8.6 | Press **Grant again** | Re-prompts and restores. |
| 8.7 | Remove `example.com` | Permission dropped, widget no longer loads there. |
| 8.8 | Toggle **Enable on all websites** | Prompts once. The named-domain list dims but keeps its entries. |
| 8.9 | Turn it back off | Named domains become active again. |
| 8.10 | Restart the browser with a custom domain configured | Still works. Registration is `persistAcrossSessions`. |

Testing a genuine on-premise instance needs access to one. 8.3–8.7 prove the
mechanism using any domain; the trust gate in 7.7 proves nothing runs where it
shouldn't.

---

## 9. Logs, backup, reset

| # | Test | Expected |
|---|---|---|
| 9.1 | Run a cycle, open **Logs** | Newest first, with instance hostname per line. |
| 9.2 | Filter by level **Assignments** | Only the successful ones. |
| 9.3 | Filter by text `INC` | Narrows correctly, count updates. |
| 9.4 | **Export** | A tab-separated `.txt`. |
| 9.5 | **Clear**, confirm | Empty, with the empty state shown. |
| 9.6 | Settings → **Keep a log history** off, run a cycle | No new entries. The empty state says logging is off. |
| 9.7 | Settings → **Export everything** | One file with groups, users, settings, round-robin positions and stats. |
| 9.8 | **Reset**, then **Import a backup** | Everything comes back, including rotation positions. |
| 9.9 | **Reset** and check the Instances panel | Custom domains survive a reset — they are permission bookkeeping, not configuration. |

---

## 10. Both browsers

Run sections 3, 4, 6 and 7 on Chrome and on Firefox.

| # | Test | Expected |
|---|---|---|
| 10.1 | About → **Storage in use** | A figure on Chrome; on Firefox it reads *(approximate)*, since `getBytesInUse` is not implemented there. |
| 10.2 | `node ..\assignflow-main\tools\check-wiring.js` | All checks pass, including *no company name appears in any shipped file*. |
| 10.3 | Firefox: `about:debugging` → Inspect the background | No `ReferenceError` for `SNAF_*`. The event page loads `shared.js` from `background.scripts`; Chrome's worker uses `importScripts`. |

---

## 11. Cleanup

| # | Test | Expected |
|---|---|---|
| 11.1 | `\aftreset` | Lists what it found, waits for confirmation, then deletes tickets → memberships → groups → users in that order. |
| 11.2 | `\aftreset` again | "Nothing to remove — this instance is already clean." |
| 11.3 | Search the PDI for `aft.` and `[AFT]` | No results. |

If a delete is refused it is normally a reference from a record outside the
harness. Running `\aftreset` a second time usually clears it.
