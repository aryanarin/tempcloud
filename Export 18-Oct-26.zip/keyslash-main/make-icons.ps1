# Generates the KeySlash extension icons from code, into both browser builds.
#
# The mark is a lowercase "k" followed by a backslash: the key you press, then
# the character you type. Teal tile with a white "k" and an amber slash, so it
# reads as a distinct silhouette next to the blue SN Commands icon rather than a
# recolour of it.
#
# The glyph is drawn as vector strokes rather than text on purpose — no font
# dependency, and the stem weights stay crisp all the way down to 16px.
#
#   powershell -ExecutionPolicy Bypass -File .\make-icons.ps1

Add-Type -AssemblyName System.Drawing

$targets = @(
  (Join-Path $PSScriptRoot 'chrome\icons'),
  (Join-Path $PSScriptRoot 'firefox\icons')
)
foreach ($t in $targets) { New-Item -ItemType Directory -Force -Path $t | Out-Null }

function New-RoundedPath([single]$x, [single]$y, [single]$w, [single]$h, [single]$r) {
  $p = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = $r * 2
  $p.AddArc($x,           $y,           $d, $d, 180, 90)
  $p.AddArc($x + $w - $d, $y,           $d, $d, 270, 90)
  $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d,   0, 90)
  $p.AddArc($x,           $y + $h - $d, $d, $d,  90, 90)
  $p.CloseFigure()
  return $p
}

# Teal tile, a touch brighter than the in-app accent so the icon holds its own
# against both light and dark browser chrome.
$tealLight = [System.Drawing.Color]::FromArgb(255, 22, 163, 148)   # #16a394
$tealDark  = [System.Drawing.Color]::FromArgb(255, 11, 111, 100)   # #0b6f64
$amber     = [System.Drawing.Color]::FromArgb(255, 251, 191, 36)   # #fbbf24

foreach ($size in 16, 48, 128) {
  $s   = [single]$size
  $bmp = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $g   = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.Clear([System.Drawing.Color]::Transparent)

  # ── Rounded tile ───────────────────────────────────────────────────────────
  $pad  = [single]($s * 0.045)
  $side = [single]($s - 2 * $pad)
  $rad  = [single]($s * 0.215)
  $tile = New-RoundedPath $pad $pad $side $side $rad

  $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
            (New-Object System.Drawing.PointF(0, 0)),
            (New-Object System.Drawing.PointF($s, $s)), $tealLight, $tealDark)
  $g.FillPath($brush, $tile)

  # ── Lowercase "k", in white ────────────────────────────────────────────────
  # Three strokes: full-height stem, arm coming down from the upper right, leg
  # kicking back out to the baseline.
  $kPen = New-Object System.Drawing.Pen([System.Drawing.Color]::White, [single]($s * 0.115))
  $kPen.StartCap  = [System.Drawing.Drawing2D.LineCap]::Round
  $kPen.EndCap    = [System.Drawing.Drawing2D.LineCap]::Round
  $kPen.LineJoin  = [System.Drawing.Drawing2D.LineJoin]::Round

  $kx   = [single]($s * 0.250)   # stem
  $top  = [single]($s * 0.235)
  $base = [single]($s * 0.765)
  $junc = [single]($s * 0.556)   # where arm and leg meet the stem

  $g.DrawLine($kPen, $kx, $top, $kx, $base)                              # stem
  $g.DrawLine($kPen, $kx, $junc, [single]($s * 0.455), [single]($s * 0.352))  # arm
  $g.DrawLine($kPen, $kx, [single]($s * 0.548), [single]($s * 0.470), $base)  # leg

  # ── Backslash, in amber ────────────────────────────────────────────────────
  $sPen = New-Object System.Drawing.Pen($amber, [single]($s * 0.130))
  $sPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
  $sPen.EndCap   = [System.Drawing.Drawing2D.LineCap]::Round
  $g.DrawLine($sPen, [single]($s * 0.590), $top, [single]($s * 0.780), $base)

  $kPen.Dispose(); $sPen.Dispose(); $brush.Dispose(); $tile.Dispose(); $g.Dispose()

  foreach ($dir in $targets) {
    $path = Join-Path $dir ("icon{0}.png" -f $size)
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    Write-Host ("wrote {0}" -f $path)
  }
  $bmp.Dispose()
}
