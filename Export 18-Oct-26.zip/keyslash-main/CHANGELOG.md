# Changelog

All notable changes to this project are documented here.

## [1.0.0] — 2026-08-24

First release, as **KeySlash**.

### Added
- **Firefox build** under `firefox/`, sharing byte-identical JS, HTML and icons
  with the Chrome build. Only `manifest.json` differs: `background.scripts`
  instead of `service_worker`, plus `browser_specific_settings.gecko` for the
  add-on id and minimum versions. No compatibility shim is needed — Firefox
  implements the `chrome` namespace for MV3 and returns promises when no
  callback is given, which is the style used throughout.
  `tools/sync-firefox.ps1` copies the shared files across, and
  `tools/check-wiring.js` hashes both folders so a missed sync fails the build.
- Import/export coverage in `tools/test-portability.js` — 45 tests over the real
  export and import functions, covering the file round trip, merge-by-shortcut,
  the foreign field names other expanders use, and the entries that get dropped.

### Changed
- Named **KeySlash** ("press `\`, say less"), previously Backslash Text Expander.
- New icon: a lowercase `k` with an amber backslash on a teal tile, drawn as
  vector strokes by `make-icons.ps1` so it stays crisp at 16px. The old mark was
  a blue tile with a bare backslash, which was hard to tell apart from SN
  Commands in a row of toolbar icons.
- Recoloured from the SN Commands blue to teal with amber accents, and the light
  theme from cool grey to warm off-white. Colour tokens only — no layout changes.
- Export filenames are now `keyslash-snippets-*.json`, and exported files carry
  `"app": "keyslash"`. The importer never read that field, so files exported by
  earlier builds still import.

### Added
- Backslash shortcuts that expand into saved text in any text field on any
  website: `<input>`, `<textarea>`, and `contenteditable` editors, across all
  frames including `about:blank` ones.
- Three expand modes — immediately, after Space/Enter, or on Tab only. `Tab`
  always force-expands regardless of the mode, which is also how a shorter
  shortcut is committed when a longer one shares its prefix.
- Inline suggestion dropdown rendered in a closed-off shadow root so page CSS
  can't reach it, with `↑`/`↓` to move, `Tab` to insert and `Esc` to dismiss.
  `Enter` only inserts once you've actually picked a row with the arrows, so it
  doesn't swallow "send" in chat apps.
- Dynamic placeholders: `{date}`, `{time}`, `{datetime}`, `{iso}`, `{weekday}`,
  `{day}`, `{month}`, `{year}`, `{uuid}`, plus `{cursor}` for where the caret
  should land. The editor's Preview shows the resolved result.
- Snippet manager: search, resizable panes, sort by custom order / shortcut /
  creation date / usage count, duplicate, fullscreen text editor, and a
  usage counter per snippet.
- Import and export as JSON — **Export All**, or tick individual snippets and
  **Export Selected**. Import either merges by shortcut (duplicates replace the
  existing snippet) or replaces the whole library. The importer also accepts
  bare arrays and the common field names used by other expanders
  (`trigger`/`abbreviation`/`name`, `expansion`/`value`/`body`) so migrating in
  doesn't need hand-edited JSON.
- Preferences: master on/off, configurable trigger character, expand mode,
  case-sensitive shortcuts, and how soon the dropdown appears.
- Per-site exclusions, editable from the manager or with one click in the popup.
- Toolbar popup with the on/off switches, search, and a compact editor.
- Light / dark theme switcher shared across the popup, manager and the in-page
  dropdown.
- Keyboard commands: <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>E</kbd> opens the
  manager, <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>X</kbd> toggles expansion. An
  `OFF` badge on the toolbar icon makes the disabled state visible.
- Support panel (Ko-fi for international, UPI QR + copyable ID for India, GitHub
  star link) and a Community link, matching SN Commands.
- Three seed snippets on first install (`\gen`, `\sig`, `\today`) plus a
  first-run banner, so there's something to try straight away.

### Notes
- Only `storage` and `activeTab` are requested alongside host access. Finding an
  already-open manager tab uses `runtime.getContexts()` rather than a
  `tabs.query({ url })` filter, specifically to avoid needing the `tabs`
  permission — which Chrome surfaces to users as "Read your browsing history".
- Replacement goes through `document.execCommand('insertText')` where the
  browser allows it. It's deprecated, but it's the only route that keeps the
  native undo stack intact and looks like real typing to frameworks such as
  React. A native-value-setter fallback plus synthetic `input`/`change` events
  covers the cases where it's refused.
- Password fields and one-time-code inputs are never touched.
