# Store submission notes for KeySlash

Things the Chrome Web Store dashboard and Mozilla's AMO ask for that aren't part
of the extension package itself. Worth having ready before you submit.

Sections 1–5 apply to both stores. Section 6 is Firefox-only.

## 1. Privacy policy (required)

Required because the extension requests broad host access. Publish
`docs/privacy.html` via GitHub Pages and use that URL in the
**Privacy practices** tab:

```
https://aryanarin.github.io/keyslash/privacy.html
```

(Settings → Pages → Deploy from branch → `main` → `/docs`.)

Points to state, all of which match how the code actually behaves:

- No data is collected, transmitted, or sold.
- Snippets, preferences and the theme are stored with
  `chrome.storage.local`, on the user's own device and profile only.
- There are no servers, no analytics, and no network requests of any kind.
- Host access is used solely to watch the field being typed in for the user's
  own shortcuts and replace them. Field contents are never read for any other
  purpose and never leave the page.

## 2. Permission justifications (fill in during submission)

| Permission | Why it's needed |
|---|---|
| `storage` | Saves the user's snippets, preferences and theme locally. |
| `activeTab` | The popup reads the current tab's hostname so the "off on this site" switch can name the site it applies to. |
| `<all_urls>` host access | A text expander has to observe the field being typed in, and neither the user nor the extension knows in advance which sites that will be. Restricting it to a list would break the single advertised feature. |

The broad host permission is the one reviewers will question, so answer it
directly rather than generically: the extension's *single purpose* is expanding
shortcuts in any text field, so site-wide access is the feature, not a
convenience. Useful supporting facts for the justification box:

- No `scripting` permission, no `tabs` permission, no remote code — the content
  script is static and bundled.
- Password fields and `autocomplete="one-time-code"` inputs are explicitly
  skipped in `content.js`.
- Users can switch expansion off globally, or per-site, from the popup.

## 3. Suggested store listing copy

**Name:** KeySlash

**Short description (132 char max), matching `manifest.json`:**
Press \, say less. Type \gen anywhere in your browser and have it expand into any saved text, with import/export.

**Category:** Productivity

**Support / links:**
- Homepage: https://github.com/aryanarin/keyslash
- Support the project: https://ko-fi.com/ysaryan
- Community: https://sncommands.ysaryan.eu.org

## 4. Assets still to prepare separately

- Store icon: 128×128 — `chrome/icons/icon128.png` exists; check it reads
  clearly at small sizes before reusing it.
- At least one 1280×800 (or 640×400) screenshot. The two that sell it fastest:
  a snippet mid-expansion in a real text box, and the manager page with the
  suggestion dropdown open.
- Optional promo tile: 440×280.

## 5. Pre-submit checklist

```
powershell -ExecutionPolicy Bypass -File .\tools\sync-firefox.ps1
node tools/check-wiring.js      # both manifests, assets, DOM wiring, build drift
node tools/test-engine.js       # 47 behavioural tests against content.js
node tools/test-portability.js  # 45 import / export round-trip tests
```

Then load each build one more time and confirm: a fresh profile gets the three
seed snippets, `\gen` expands in a plain textarea and in Gmail compose, Export
All downloads valid JSON, and re-importing that file merges cleanly.

Zip from *inside* the build folder so `manifest.json` sits at the archive root,
not nested under `chrome/` or `firefox/`:

```
Compress-Archive -Path .\chrome\*  -DestinationPath .\keyslash-chrome.zip  -Force
Compress-Archive -Path .\firefox\* -DestinationPath .\keyslash-firefox.zip -Force
```

## 6. Firefox / AMO specifics

**Add-on id.** `browser_specific_settings.gecko.id` is `keyslash@ysaryan.eu.org`.
Don't change it after the first submission — AMO treats the id as the add-on's
identity, and a new id means a new listing with no upgrade path.

**Minimum versions.** `strict_min_version` is `140.0`, with `gecko_android` at
`142.0`, matching the SN Commands listing. `140.0` is also the floor for
`data_collection_permissions`, which is already declared as `required: ["none"]`
— AMO now expects an explicit data-collection disclosure, and "none" is accurate
here.

**Host permissions behave differently.** Firefox MV3 treats host access as
opt-in and exposes per-site control through the toolbar Extensions button, so
users can revoke `<all_urls>` for individual sites at any time. From Firefox 127
the request appears in the install prompt. Two consequences:

- Expect support questions along the lines of "it stopped working on this one
  site." The answer is the Extensions button, not a bug.
- Don't be surprised if AMO review asks about the breadth of the permission.
  The single-purpose argument from section 2 applies unchanged.

**Source code.** AMO requires a source upload when a submission contains
minified or generated code. KeySlash ships neither — every file is
hand-written and readable, and the icons are generated by `make-icons.ps1`
before packaging, not at runtime. Say so if prompted.

**No service worker.** Firefox MV3 has no background service worker in release,
which is why `firefox/manifest.json` uses `background.scripts`.
`tools/check-wiring.js` fails the build if a `service_worker` key ever appears
in the Firefox manifest.
