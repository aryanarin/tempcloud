# docs

`privacy.html` lives here so it can be served straight from GitHub Pages — that
gives you the public privacy-policy URL both the Chrome Web Store and AMO ask
for. `STORE_NOTES.md` has the submission checklist for both.

This is also the place for screenshots and promo images.

Suggested first addition: a shot of `\gen` expanding in a real text field, and
one of the manager page with a few snippets in the list, saved as
`screenshot-expand.png` and `screenshot-manager.png`, then referenced from the
main `README.md`.
