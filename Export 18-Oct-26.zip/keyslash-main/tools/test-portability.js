// Round-trip test for import / export in chrome/settings.js.
// Run it with `node tools/test-portability.js` from the repo root.
//
// settings.js is a DOM script: it does getElementById at the top level, so it
// can't just be require()d. Rather than stub the whole manager page, this pulls
// the two pure functions that do the actual work out of the real source and
// exercises them directly. If either is renamed or reshaped, the extraction
// fails loudly instead of silently testing nothing.

const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '..', 'chrome', 'settings.js'), 'utf8');

let pass = 0;
const failed = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else { failed.push(name); console.log('  FAIL ' + name + (extra ? '  ->  ' + extra : '')); }
}
function eq(name, actual, expected) {
  const a = JSON.stringify(actual), b = JSON.stringify(expected);
  check(name, a === b, 'got ' + a + ', want ' + b);
}

// ── Pull the real functions out of settings.js ──────────────────────────────
// Matches `function name(...) { ... }` up to the closing brace in column 0,
// which is how every top-level function in that file is formatted.
function extract(name) {
  const re = new RegExp('^function ' + name + '\\([\\s\\S]*?^\\}', 'm');
  const m = re.exec(SRC);
  if (!m) {
    console.log('  FAIL could not find function ' + name + ' in settings.js');
    process.exit(1);
  }
  return m[0];
}

// The two functions lean on prefix() and pad2() from their module scope; supply
// the same implementations settings.js uses.
const harness = `
  const settings = { prefix: '\\\\', caseSensitive: false };
  const prefix = () => settings.prefix || '\\\\';
  const norm = (s) => settings.caseSensitive ? String(s) : String(s).toLowerCase();
  ${extract('exportPayload')}
  ${extract('normaliseImported')}
  return { exportPayload, normaliseImported, norm };
`;
const { exportPayload, normaliseImported, norm } = new Function(harness)();

// Mirrors the merge branch of the importFile change handler in settings.js.
function merge(library, incoming) {
  let added = 0, replaced = 0;
  const out = library.slice();
  incoming.forEach((item) => {
    const idx = out.findIndex(s => norm(s.shortcut) === norm(item.shortcut));
    if (idx !== -1) {
      out[idx] = Object.assign({}, out[idx], item, { id: out[idx].id, uses: out[idx].uses || 0 });
      replaced++;
    } else {
      out.push(Object.assign({}, item, { id: 'new-' + out.length, uses: 0 }));
      added++;
    }
  });
  return { out, added, replaced };
}

// The filter the importer applies before anything is accepted.
function accept(rawList) {
  return rawList
    .filter(x => x && typeof x === 'object')
    .map(normaliseImported)
    .filter(x => x.shortcut && x.text !== '');
}

// ── Export shape ────────────────────────────────────────────────────────────
console.log('export');
const LIB = [
  { id: 'a', shortcut: 'gen', label: 'General', text: 'General Text for testing purpose', order: 10, uses: 7, createdAt: 1 },
  { id: 'b', shortcut: 'sig', label: '',        text: 'Best regards,\nAryan',             order: null, uses: 0, createdAt: 2 },
  { id: 'c', shortcut: 'iso', label: 'Date',    text: 'Date: {iso}',                      order: 30, uses: 2, createdAt: 3 }
];

const all = exportPayload(LIB);
eq('exports every snippet', all.snippets.length, 3);
eq('tags the file with the app name', all.app, 'keyslash');
eq('records the trigger character', all.prefix, '\\');
check('stamps an export time', typeof all.exportedAt === 'string' && !isNaN(Date.parse(all.exportedAt)));
eq('carries shortcut, label, text and order only',
   Object.keys(all.snippets[0]).sort(), ['label', 'order', 'shortcut', 'text']);
check('leaves internal ids out of the file', !JSON.stringify(all).includes('"id"'));
check('leaves usage counters out of the file', !JSON.stringify(all).includes('"uses"'));
eq('preserves newlines in the text', all.snippets[1].text, 'Best regards,\nAryan');
check('serialises to valid JSON', (() => {
  try { JSON.parse(JSON.stringify(all, null, 2)); return true; } catch (e) { return false; }
})());

console.log('\nselective export');
const chosen = LIB.filter(s => ['gen', 'iso'].includes(s.shortcut));
const some = exportPayload(chosen);
eq('exports only the ticked snippets', some.snippets.map(s => s.shortcut), ['gen', 'iso']);
eq('same file shape as Export All', Object.keys(some).sort(), Object.keys(all).sort());

// ── Round trip ──────────────────────────────────────────────────────────────
console.log('\nround trip through a file');
const reread = JSON.parse(JSON.stringify(all));      // as if written out and read back
const back = accept(reread.snippets);
eq('everything survives the trip', back.length, 3);
eq('shortcut survives', back[0].shortcut, 'gen');
eq('text survives byte for byte', back[1].text, 'Best regards,\nAryan');
eq('label survives', back[2].label, 'Date');
eq('order survives', back[0].order, 10);
eq('a null order stays null', back[1].order, null);
check('placeholders are stored raw, not resolved', back[2].text.includes('{iso}'));

// ── Importing into an existing library ──────────────────────────────────────
console.log('\nmerge behaviour');
{
  const r = merge(LIB, accept(exportPayload([
    { shortcut: 'gen', label: 'Replaced', text: 'NEW TEXT', order: 99 },
    { shortcut: 'new', label: '',         text: 'Fresh',    order: null }
  ]).snippets));
  eq('a matching shortcut is replaced, not duplicated', r.replaced, 1);
  eq('a new shortcut is added', r.added, 1);
  eq('library grew by exactly one', r.out.length, 4);
  eq('the replaced text won', r.out.find(s => s.shortcut === 'gen').text, 'NEW TEXT');
  eq('the original id was kept', r.out.find(s => s.shortcut === 'gen').id, 'a');
  eq('the usage count was kept', r.out.find(s => s.shortcut === 'gen').uses, 7);
}
{
  // Case-insensitive matching is the default, so \GEN must not become a second
  // entry alongside \gen.
  const r = merge(LIB, accept([{ shortcut: 'GEN', text: 'SHOUTED' }]));
  eq('\\GEN matches the existing \\gen', r.added, 0);
  eq('and replaces it', r.replaced, 1);
}

// ── Formats the importer has to tolerate ────────────────────────────────────
console.log('\nforeign and untidy files');
eq('a bare array works', accept([{ shortcut: 'x', text: 'X' }]).length, 1);
eq('trigger/expansion field names',
   accept([{ trigger: 'ab', expansion: 'Alpha Beta' }])[0],
   { shortcut: 'ab', label: '', text: 'Alpha Beta', order: null });
eq('abbreviation/value field names',
   accept([{ abbreviation: 'cd', value: 'C D' }])[0].shortcut, 'cd');
eq('name/body field names',
   accept([{ name: 'ef', body: 'E F' }])[0].shortcut, 'ef');
eq('description maps to label',
   accept([{ shortcut: 'gh', text: 'G', description: 'Gee' }])[0].label, 'Gee');
eq('a leading trigger char is stripped',
   accept([{ shortcut: '\\ij', text: 'I J' }])[0].shortcut, 'ij');
eq('repeated trigger chars are stripped',
   accept([{ shortcut: '\\\\kl', text: 'K L' }])[0].shortcut, 'kl');
eq('inner spaces are removed from the shortcut',
   accept([{ shortcut: 'm n', text: 'M N' }])[0].shortcut, 'mn');
eq('surrounding whitespace is trimmed',
   accept([{ shortcut: '  op  ', text: 'O P' }])[0].shortcut, 'op');
eq('order arrives as a number even when quoted',
   accept([{ shortcut: 'qr', text: 'Q', order: '40' }])[0].order, 40);
eq('an empty order becomes null',
   accept([{ shortcut: 'st', text: 'S', order: '' }])[0].order, null);

console.log('\nentries that must be dropped');
eq('no shortcut',      accept([{ text: 'orphan' }]).length, 0);
eq('no text',          accept([{ shortcut: 'uv' }]).length, 0);
eq('empty text',       accept([{ shortcut: 'wx', text: '' }]).length, 0);
eq('shortcut of only trigger chars', accept([{ shortcut: '\\', text: 'Y' }]).length, 0);
eq('null entry',       accept([null]).length, 0);
eq('a bare string',    accept(['nope']).length, 0);
eq('a number',         accept([42]).length, 0);
eq('good entries survive alongside bad ones',
   accept([{ shortcut: 'ok', text: 'fine' }, null, { text: 'no shortcut' }]).length, 1);

console.log('\n' + pass + ' passed, ' + failed.length + ' failed');
if (failed.length) { console.log('failing: ' + failed.join(' | ')); process.exit(1); }
