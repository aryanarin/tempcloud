// Behavioural test for the expansion engine in chrome/content.js.
// Run it with `node tools/test-engine.js` from the repo root.
//
// There are no dependencies on purpose: instead of jsdom, this hand-rolls just
// enough of the DOM to load the real content script *unmodified* and drive it by
// dispatching the same events a browser would. The stub `execCommand` behaves
// like the real one, including firing `input` synchronously, which is what the
// re-entrancy guard has to cope with.

const fs = require('fs');
const path = require('path');

const SRC = fs.readFileSync(path.join(__dirname, '..', 'chrome', 'content.js'), 'utf8');

let pass = 0, failed = [];
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else { failed.push(name); console.log('  FAIL ' + name + (extra ? '  ->  ' + extra : '')); }
}
function eq(name, actual, expected) {
  check(name, actual === expected, 'got ' + JSON.stringify(actual) + ', want ' + JSON.stringify(expected));
}

// ── Minimal DOM ─────────────────────────────────────────────────────────────
class ClassList {
  constructor() { this.set = new Set(); }
  add(c) { this.set.add(c); }
  remove(c) { this.set.delete(c); }
  contains(c) { return this.set.has(c); }
  toggle(c, on) {
    const want = on === undefined ? !this.set.has(c) : !!on;
    if (want) this.set.add(c); else this.set.delete(c);
    return want;
  }
}

class El {
  constructor(tag) {
    this.tagName = String(tag).toUpperCase();
    this.childNodes = [];
    this.classList = new ClassList();
    this._className = '';
    this.textContent = '';
    this.dataset = {};
    this.attrs = {};
    this.style = { setProperty() {}, removeProperty() {} };
    this.listeners = {};
    this.offsetWidth = 330;
    this.offsetHeight = 240;
  }
  get className() { return this._className; }
  set className(v) {
    this._className = String(v);
    this.classList = new ClassList();
    String(v).split(/\s+/).filter(Boolean).forEach(c => this.classList.add(c));
  }
  get children() { return this.childNodes.filter(n => n instanceof El); }
  set innerHTML(v) { if (v === '') this.childNodes = []; }
  get innerHTML() { return ''; }
  append(...nodes) { nodes.forEach(n => this.childNodes.push(n)); }
  appendChild(n) { this.childNodes.push(n); return n; }
  setAttribute(k, v) { this.attrs[k] = v; }
  getAttribute(k) { return this.attrs[k]; }
  addEventListener(t, fn) { (this.listeners[t] = this.listeners[t] || []).push(fn); }
  attachShadow() { this.shadowRoot = new El('shadow-root'); return this.shadowRoot; }
  scrollIntoView() {}
  querySelector(sel) {
    const want = sel.replace(/^\./, '');
    const walk = (node) => {
      for (const c of node.children) {
        if (c.classList.contains(want)) return c;
        const deep = walk(c);
        if (deep) return deep;
      }
      return null;
    };
    return walk(this);
  }
  getBoundingClientRect() { return { left: 40, top: 100, right: 340, bottom: 124, width: 300, height: 24 }; }
  getRootNode() { return globalThis.document; }
}

// A stand-in for <input> / <textarea>. The `value` accessor lives on the
// prototype so content.js's native-setter fallback can find it.
class Field extends El {
  constructor(tag, type) {
    super(tag);
    this.type = type || 'text';
    this._v = '';
    this.selectionStart = 0;
    this.selectionEnd = 0;
    this.readOnly = false;
    this.disabled = false;
    this.autocomplete = '';
    this.isContentEditable = false;
    this.dispatched = [];
  }
  get value() { return this._v; }
  set value(v) { this._v = String(v); }
  setSelectionRange(a, b) { this.selectionStart = a; this.selectionEnd = b; }
  focus() { globalThis.document.activeElement = this; }
  dispatchEvent(ev) {
    this.dispatched.push(ev.type);
    fireDoc(ev.type, { target: this });
    return true;
  }
}

const docHandlers = {};
function fireDoc(type, props) {
  const ev = Object.assign({
    type,
    defaultPrevented: false,
    isComposing: false,
    preventDefault() { this.defaultPrevented = true; },
    stopPropagation() {},
    stopImmediatePropagation() {}
  }, props);
  (docHandlers[type] || []).slice().forEach(fn => fn(ev));
  return ev;
}

let execCommandEnabled = true;

const document = {
  activeElement: null,
  referrer: '',
  documentElement: new El('html'),
  body: new El('body'),
  addEventListener(t, fn) { (docHandlers[t] = docHandlers[t] || []).push(fn); },
  removeEventListener() {},
  createElement(tag) { return new El(tag); },
  createTextNode(t) { const n = new El('#text'); n.textContent = t; return n; },
  createRange() {
    return {
      setStart() {}, setEnd() {}, setStartAfter() {}, collapse() {},
      deleteContents() {}, insertNode() {},
      getBoundingClientRect() { return { left: 40, top: 100, right: 340, bottom: 124, width: 300, height: 24 }; }
    };
  },
  createDocumentFragment() { const f = new El('#fragment'); f.lastChild = null; return f; },
  // Mimics the browser: replace the current selection in the focused field.
  execCommand(cmd, _ui, text) {
    if (!execCommandEnabled || cmd !== 'insertText') return false;
    const el = document.activeElement;
    if (!el || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA')) return false;
    const s = el.selectionStart, e = el.selectionEnd;
    el._v = el._v.slice(0, s) + text + el._v.slice(e);
    el.selectionStart = el.selectionEnd = s + text.length;
    fireDoc('input', { target: el });       // browsers fire this synchronously
    return true;
  }
};

const windowStub = {
  innerWidth: 1280,
  innerHeight: 800,
  addEventListener() {},
  removeEventListener() {},
  getSelection() { return null; },
  top: { location: { href: 'https://example.com/' } }
};

// ── chrome.* ────────────────────────────────────────────────────────────────
let store = {};
const changeListeners = [];
const sentMessages = [];

const chromeStub = {
  runtime: {
    lastError: undefined,
    sendMessage(msg) { sentMessages.push(msg); return Promise.resolve({ ok: true }); }
  },
  storage: {
    local: {
      get(keys, cb) {
        const out = {};
        (Array.isArray(keys) ? keys : [keys]).forEach(k => { out[k] = store[k]; });
        cb(out);
      },
      set(obj, cb) { Object.assign(store, obj); if (cb) cb(); }
    },
    onChanged: { addListener(fn) { changeListeners.push(fn); } }
  }
};

// ── Wire globals and load the real content script ───────────────────────────
Object.assign(globalThis, {
  document,
  window: windowStub,
  chrome: chromeStub,
  location: { hostname: 'example.com', href: 'https://example.com/page' },
  HTMLInputElement: Field,
  HTMLTextAreaElement: Field,
  Node: { TEXT_NODE: 3 },
  Event: class { constructor(type, opts) { this.type = type; Object.assign(this, opts || {}); } }
});

function loadEngine(snippets, settings) {
  store = { bteSnippets: snippets, bteSettings: settings, bteTheme: 'dark' };
  // Re-notify the already-loaded engine instead of re-evaluating the IIFE.
  changeListeners.forEach(fn => fn({ bteSnippets: {}, bteSettings: {} }, 'local'));
}

const SNIPS = [
  { id: 's1', shortcut: 'gen',  text: 'General Text for testing purpose' },
  { id: 's2', shortcut: 'sig',  text: 'Best regards,\nAryan' },
  { id: 's3', shortcut: 'iso',  text: 'Date: {iso}' },
  { id: 's4', shortcut: 'cur',  text: 'Hi {cursor}!' },
  { id: 's5', shortcut: 'loop', text: 'X \\gen' }
];
const BASE = {
  enabled: true, prefix: '\\', mode: 'instant',
  caseSensitive: false, suggestions: true, sugMin: 1, excluded: []
};

store = { bteSnippets: SNIPS, bteSettings: BASE, bteTheme: 'dark' };
new Function(SRC)();   // content.js is an IIFE; it reads the globals above

// ── Typing helpers ──────────────────────────────────────────────────────────
function field(tag = 'INPUT', type = 'text') {
  const f = new Field(tag, type);
  document.activeElement = f;
  return f;
}
function type(f, str) {
  for (const ch of str) {
    f._v = f._v.slice(0, f.selectionStart) + ch + f._v.slice(f.selectionEnd);
    f.selectionStart = f.selectionEnd = f.selectionStart + 1;
    fireDoc('input', { target: f });
  }
}
function key(f, k, mods) {
  return fireDoc('keydown', Object.assign(
    { key: k, shiftKey: false, ctrlKey: false, altKey: false, metaKey: false, target: f }, mods || {}));
}

// ── Tests ───────────────────────────────────────────────────────────────────
console.log('instant mode, <input>');
{
  let f = field(); type(f, '\\gen');
  eq('\\gen expands', f.value, 'General Text for testing purpose');
  eq('caret sits at the end', f.selectionStart, 'General Text for testing purpose'.length);

  f = field(); type(f, 'hello \\gen');
  eq('expands mid-sentence', f.value, 'hello General Text for testing purpose');

  f = field(); type(f, '\\zzz');
  eq('unknown shortcut left alone', f.value, '\\zzz');

  f = field(); type(f, 'C:\\Users\\me');
  eq('windows path left alone', f.value, 'C:\\Users\\me');

  f = field(); type(f, '\\GEN');
  eq('case-insensitive by default', f.value, 'General Text for testing purpose');
}

console.log('\nmultiline + <textarea>');
{
  const f = field('TEXTAREA'); type(f, '\\sig');
  eq('newlines preserved', f.value, 'Best regards,\nAryan');
}

console.log('\nplaceholders');
{
  const d = new Date();
  const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  let f = field(); type(f, '\\iso');
  eq('{iso} resolved', f.value, 'Date: ' + iso);

  f = field(); type(f, '\\cur');
  eq('{cursor} stripped from output', f.value, 'Hi !');
  eq('{cursor} placed the caret', f.selectionStart, 3);
}

console.log('\nre-entrancy');
{
  const f = field(); type(f, '\\loop');
  eq('snippet ending in a shortcut expands exactly once', f.value, 'X \\gen');
}

console.log('\nlonger-shortcut guard');
{
  loadEngine([{ id: 'a', shortcut: 'gen', text: 'SHORT' },
              { id: 'b', shortcut: 'general', text: 'LONG' }], BASE);
  let f = field(); type(f, '\\gen');
  eq('\\gen waits while \\general exists', f.value, '\\gen');
  type(f, 'eral');
  eq('\\general still reachable', f.value, 'LONG');

  f = field(); type(f, '\\gen');
  const ev = key(f, 'Tab');
  eq('Tab force-expands the shorter one', f.value, 'SHORT');
  check('Tab was consumed', ev.defaultPrevented === true);
}

console.log('\nspace mode');
{
  loadEngine(SNIPS, Object.assign({}, BASE, { mode: 'space' }));
  let f = field(); type(f, '\\gen');
  eq('nothing until the space', f.value, '\\gen');
  type(f, ' ');
  eq('space commits and is kept', f.value, 'General Text for testing purpose ');
  eq('caret after the space', f.selectionStart, 'General Text for testing purpose '.length);

  f = field('TEXTAREA'); type(f, '\\gen\n');
  eq('Enter commits too', f.value, 'General Text for testing purpose\n');
}

console.log('\ntab mode');
{
  loadEngine(SNIPS, Object.assign({}, BASE, { mode: 'tab' }));
  const f = field(); type(f, '\\gen ');
  eq('space does not commit in tab mode', f.value, '\\gen ');
  const f2 = field(); type(f2, '\\gen'); key(f2, 'Tab');
  eq('Tab commits', f2.value, 'General Text for testing purpose');
}

console.log('\ncase sensitivity');
{
  loadEngine(SNIPS, Object.assign({}, BASE, { caseSensitive: true }));
  let f = field(); type(f, '\\GEN');
  eq('\\GEN ignored when case-sensitive', f.value, '\\GEN');
  f = field(); type(f, '\\gen');
  eq('\\gen still works', f.value, 'General Text for testing purpose');
}

console.log('\ncustom trigger character');
{
  loadEngine(SNIPS, Object.assign({}, BASE, { prefix: ';' }));
  let f = field(); type(f, ';gen');
  eq('; triggers', f.value, 'General Text for testing purpose');
  f = field(); type(f, '\\gen');
  eq('\\ no longer triggers', f.value, '\\gen');
}

console.log('\noff switches');
{
  loadEngine(SNIPS, Object.assign({}, BASE, { enabled: false }));
  let f = field(); type(f, '\\gen');
  eq('master switch off', f.value, '\\gen');

  loadEngine(SNIPS, Object.assign({}, BASE, { excluded: ['example.com'] }));
  f = field(); type(f, '\\gen');
  eq('excluded host', f.value, '\\gen');

  loadEngine(SNIPS, Object.assign({}, BASE, { excluded: ['other.com'] }));
  f = field(); type(f, '\\gen');
  eq('non-matching exclusion still expands', f.value, 'General Text for testing purpose');

  loadEngine([], BASE);
  f = field(); type(f, '\\gen');
  eq('empty library', f.value, '\\gen');
}

console.log('\nfields that must be skipped');
{
  loadEngine(SNIPS, BASE);
  let f = field('INPUT', 'password'); type(f, '\\gen');
  eq('password input', f.value, '\\gen');

  f = field('INPUT', 'email'); type(f, '\\gen');
  eq('email input (no selection API)', f.value, '\\gen');

  f = field('INPUT', 'number'); type(f, '\\gen');
  eq('number input', f.value, '\\gen');

  f = field(); f.autocomplete = 'one-time-code'; type(f, '\\gen');
  eq('one-time-code input', f.value, '\\gen');

  f = field(); f.readOnly = true; type(f, '\\gen');
  eq('readonly input', f.value, '\\gen');

  f = field(); f.disabled = true; type(f, '\\gen');
  eq('disabled input', f.value, '\\gen');
}

console.log('\nnative-setter fallback (execCommand refused)');
{
  execCommandEnabled = false;
  const f = field();
  type(f, '\\gen');
  eq('fallback still expands', f.value, 'General Text for testing purpose');
  check('fallback announced input', f.dispatched.includes('input'));
  check('fallback announced change', f.dispatched.includes('change'));
  execCommandEnabled = true;
}

console.log('\nusage reporting + dropdown');
{
  sentMessages.length = 0;
  const f = field(); type(f, '\\gen');
  const used = sentMessages.filter(m => m.source === 'BTE_USED');
  eq('exactly one usage report', used.length, 1);
  eq('reports the right snippet id', used[0].id, 's1');

  const f2 = field(); type(f2, '\\s');           // partial -> dropdown path
  check('dropdown rendered without throwing', true);
  const ev = key(f2, 'Escape');
  check('Escape consumed by the dropdown', ev.defaultPrevented === true);
  const f3 = field(); type(f3, '\\s');
  key(f3, 'ArrowDown');
  const enter = key(f3, 'Enter');
  check('Enter inserts after arrowing', enter.defaultPrevented === true);
  check('an expansion happened from the dropdown', f3.value !== '\\s', 'value=' + JSON.stringify(f3.value));

  const f4 = field(); type(f4, '\\s');
  const plainEnter = key(f4, 'Enter');
  check('Enter NOT hijacked before arrowing', plainEnter.defaultPrevented === false);
}

console.log('\ncomposition (IME)');
{
  const f = field();
  fireDoc('compositionstart', { target: f });
  type(f, '\\gen');
  eq('no expansion mid-composition', f.value, '\\gen');
  fireDoc('compositionend', { target: f });
  key(f, 'Tab');
  eq('expands once composition ends', f.value, 'General Text for testing purpose');
}

console.log('\n' + pass + ' passed, ' + failed.length + ' failed');
if (failed.length) { console.log('failing: ' + failed.join(' | ')); process.exit(1); }
