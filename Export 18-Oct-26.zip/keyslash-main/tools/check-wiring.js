// Static consistency check for both extension packages. No dependencies —
// run it with `node tools/check-wiring.js` from the repo root.
//
// It catches the class of mistake that only shows up as a silent no-op in the
// browser: a manifest pointing at a file that isn't there, a getElementById
// that can never match, a storage key spelled differently in two scripts, or
// the four copies of DEFAULT_SETTINGS drifting apart.
//
// It also verifies chrome/ and firefox/ haven't drifted, since the two builds
// are meant to run byte-identical code with only the manifest differing.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const repo = path.join(__dirname, '..');
let problems = 0;
const fail = (m) => { problems++; console.log('  FAIL ' + m); };
const ok   = (m) => console.log('  ok   ' + m);

// Files that must be identical in both builds. manifest.json is excluded: it is
// the one file that legitimately differs between Chrome and Firefox.
const SHARED = [
  'background.js', 'content.js', 'popup.html', 'popup.js',
  'settings.html', 'settings.js',
  'icons/icon16.png', 'icons/icon48.png', 'icons/icon128.png', 'icons/upi-qr.png'
];

const STORE_KEYS = ['bteSnippets', 'bteSettings', 'bteTheme'];

function checkBuild(build) {
  const root = path.join(repo, build);
  console.log('\n════ ' + build + '/ ════');

  // ── manifest ──────────────────────────────────────────────────────────────
  console.log('\nmanifest.json');
  const mf = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
  ok('parses as JSON (v' + mf.version + ', manifest_version ' + mf.manifest_version + ')');

  const refs = [];
  Object.values(mf.icons).forEach(p => refs.push(p));
  Object.values(mf.action.default_icon).forEach(p => refs.push(p));
  refs.push(mf.action.default_popup, mf.options_ui.page);

  // Chrome uses a service worker; Firefox MV3 uses background scripts.
  if (mf.background.service_worker) {
    refs.push(mf.background.service_worker);
    ok('background: service_worker (Chrome style)');
  } else if (Array.isArray(mf.background.scripts)) {
    mf.background.scripts.forEach(p => refs.push(p));
    ok('background: scripts (Firefox MV3 style)');
  } else {
    fail('manifest declares no usable background entry point');
  }

  mf.content_scripts.forEach(cs => cs.js.forEach(p => refs.push(p)));
  [...new Set(refs)].forEach((p) => {
    fs.existsSync(path.join(root, p)) ? ok('asset exists: ' + p) : fail('missing asset: ' + p);
  });

  // Firefox needs an explicit add-on id to be updatable on AMO.
  if (build === 'firefox') {
    const gecko = (mf.browser_specific_settings || {}).gecko;
    gecko && gecko.id ? ok('gecko id: ' + gecko.id)
                      : fail('firefox manifest has no browser_specific_settings.gecko.id');
    if (gecko && gecko.strict_min_version) ok('gecko strict_min_version: ' + gecko.strict_min_version);
    if (mf.background.service_worker) {
      fail('firefox manifest uses service_worker, which Firefox MV3 does not support in release');
    }
  }
  if (build === 'chrome' && mf.browser_specific_settings) {
    fail('chrome manifest should not carry browser_specific_settings');
  }

  // The name has to match everywhere a user can see it.
  console.log('\nbranding');
  const NAME = 'KeySlash';
  eqName('manifest name', mf.name);
  eqName('action default_title', mf.action.default_title);
  function eqName(what, value) {
    value === NAME ? ok(what + ' is "' + NAME + '"')
                   : fail(what + ' is "' + value + '", expected "' + NAME + '"');
  }
  ['popup.html', 'settings.html'].forEach((f) => {
    const html = fs.readFileSync(path.join(root, f), 'utf8');
    const title = (/<title>([^<]*)<\/title>/.exec(html) || [])[1] || '';
    title.includes(NAME) ? ok(f + ' <title> mentions ' + NAME)
                         : fail(f + ' <title> is "' + title + '", expected it to mention ' + NAME);
    /Backslash Text Expander/.test(html)
      ? fail(f + ' still contains the old name "Backslash Text Expander"')
      : ok(f + ' has no leftover old name');
  });

  // ── HTML <-> JS id wiring ─────────────────────────────────────────────────
  const idsIn     = (html) => new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));
  const idsUsedBy = (js)   => [...js.matchAll(/getElementById\(\s*'([^']+)'\s*\)/g)].map(m => m[1]);

  for (const [htmlFile, jsFile] of [['settings.html', 'settings.js'], ['popup.html', 'popup.js']]) {
    console.log('\n' + jsFile + ' <-> ' + htmlFile);
    const html = fs.readFileSync(path.join(root, htmlFile), 'utf8');
    const js   = fs.readFileSync(path.join(root, jsFile), 'utf8');
    const have = idsIn(html);
    const used = idsUsedBy(js);

    const missing = used.filter(id => !have.has(id));
    missing.length ? missing.forEach(id => fail('JS looks up #' + id + ' but the HTML has no such id'))
                   : ok(used.length + ' getElementById lookups all resolve');

    const usedSet = new Set(used);
    const unused = [...have].filter(id => !usedSet.has(id) && !/^(btnReportBug)$/.test(id));
    if (unused.length) console.log('  note unreferenced ids (fine if static): ' + unused.join(', '));

    [...html.matchAll(/<script src="([^"]+)"/g)].forEach((m) => {
      fs.existsSync(path.join(root, m[1])) ? ok('script exists: ' + m[1]) : fail('missing script: ' + m[1]);
    });
    [...html.matchAll(/<img[^>]+src="([^"]+)"/g)].forEach((m) => {
      fs.existsSync(path.join(root, m[1])) ? ok('image exists: ' + m[1]) : fail('missing image: ' + m[1]);
    });
  }

  // ── storage-key agreement across all four scripts ─────────────────────────
  console.log('\nstorage keys');
  const files = ['background.js', 'content.js', 'settings.js', 'popup.js']
    .map(f => [f, fs.readFileSync(path.join(root, f), 'utf8')]);
  STORE_KEYS.forEach((key) => {
    const where = files.filter(([, src]) => src.includes(key)).map(([f]) => f);
    console.log('  ' + key + ' -> ' + where.join(', '));
  });
  const contentSrc = files.find(([f]) => f === 'content.js')[1];
  STORE_KEYS.forEach((k) => {
    contentSrc.includes(k) ? ok('content.js reads ' + k) : fail('content.js never reads ' + k);
  });

  // ── settings shape agreement ──────────────────────────────────────────────
  console.log('\nDEFAULT_SETTINGS keys');
  function defaultKeys(src) {
    const m = /DEFAULT_SETTINGS\s*=\s*\{([\s\S]*?)\n\s*\};/.exec(src);
    if (!m) return null;
    return [...m[1].matchAll(/^\s*(\w+)\s*:/gm)].map(x => x[1]).sort();
  }
  const shapes = files.map(([f, src]) => [f, defaultKeys(src)]).filter(([, k]) => k);
  const base = shapes[0];
  shapes.forEach(([f, keys]) => {
    const same = JSON.stringify(keys) === JSON.stringify(base[1]);
    same ? ok(f + ': ' + keys.join(', ')) : fail(f + ' differs from ' + base[0] + ': ' + keys.join(', '));
  });
}

['chrome', 'firefox'].forEach(checkBuild);

// ── chrome/ vs firefox/ drift ─────────────────────────────────────────────────
console.log('\n════ chrome/ vs firefox/ ════\n');
const digest = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
SHARED.forEach((rel) => {
  const a = path.join(repo, 'chrome', rel);
  const b = path.join(repo, 'firefox', rel);
  if (!fs.existsSync(a)) { fail('chrome/' + rel + ' is missing'); return; }
  if (!fs.existsSync(b)) { fail('firefox/' + rel + ' is missing — run tools/sync-firefox.ps1'); return; }
  digest(a) === digest(b)
    ? ok('identical: ' + rel)
    : fail(rel + ' differs between builds — run tools/sync-firefox.ps1');
});

console.log('\n' + (problems ? problems + ' PROBLEM(S)' : 'All checks passed.'));
process.exit(problems ? 1 : 0);
