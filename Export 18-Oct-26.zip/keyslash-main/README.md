# KeySlash

**Press `\`, say less.**

Save any block of text behind a short backslash shortcut, then type that
shortcut in any text box on any website and watch it turn into the full text.

Type `\gen` → get `General Text for testing purpose`.

Chrome and Firefox builds, from the same source. Built as a sibling to
[SN Commands](https://github.com/aryanarin/sncommands), which does the same
trick for runnable ServiceNow scripts.

---

## Features

- **Expands anywhere** — plain `<input>` and `<textarea>` fields, and
  `contenteditable` editors (Gmail, Jira, Notion, Confluence, LinkedIn, chat
  apps). Works inside iframes too.
- **Your own shortcuts** — `\gen`, `\sig`, `\addr`, whatever you like. The
  trigger character is configurable if you'd rather use `;` or `/`.
- **Three ways to fire** — expand immediately when the shortcut is complete,
  only after you press Space/Enter, or only on Tab. `Tab` always forces an
  expansion, whichever mode you choose.
- **Suggestion dropdown** — start typing `\` and a small list of matching
  shortcuts appears next to your cursor. `↑`/`↓` to move, `Tab` to insert,
  `Esc` to dismiss.
- **Dynamic placeholders** — drop `{date}`, `{time}`, `{datetime}`, `{iso}`,
  `{weekday}`, `{day}`, `{month}`, `{year}` or `{uuid}` into a snippet and it
  is filled in at expansion time. `{cursor}` marks where the caret should land
  afterwards.
- **Import / export** — export your whole library or just the snippets you
  tick, as JSON. Import merges by shortcut (a duplicate shortcut *replaces* the
  existing one) or replaces the library outright.
- **Off switches** — a master on/off toggle plus a per-site exclusion list, so
  you can keep it out of the one app where it gets in the way.
- **Light / dark theme**, resizable panels, sort by custom order / shortcut /
  date / how often you use them.
- **Manifest V3** on both browsers, no remote code, no network calls, nothing
  leaves your device.

## Installation

### Chrome / Edge / Brave (developer mode)

1. Download or clone this repository.
2. Open `chrome://extensions` (or `edge://extensions`, etc.).
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select the **`chrome/`** folder.

### Firefox (temporary install)

1. Open `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on…**
3. Select **`firefox/manifest.json`**.

Temporary add-ons are removed when Firefox closes. For a permanent unsigned
install you need Firefox Developer Edition or Nightly with
`xpinstall.signatures.required` set to `false` in `about:config`, or a signed
build from AMO.

**Firefox permissions note:** under Manifest V3, Firefox treats host access as
opt-in and lets users revoke it per site from the Extensions button in the
toolbar. If expansion stops working on a site, open that button and confirm
KeySlash is allowed to access it. Firefox 127 and later show the request in the
install prompt, so accepting the install normally covers it.

### From the stores

Not published yet — this README will be updated with links once the listings are
live.

## Usage

1. Click the toolbar icon, or press <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>E</kbd>,
   to open the snippet manager.
2. Hit **+ New Snippet**, give it a shortcut (`gen`), an optional label, and the
   text it should expand into. Save.
3. Go to any website, click into any text field, and type `\gen`.

Three sample snippets (`\gen`, `\sig`, `\today`) are created on first install so
there's something to try immediately.

### Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>E</kbd> | Open the snippet manager |
| <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>X</kbd> | Turn expansion on / off |
| <kbd>Tab</kbd> | Force-expand the shortcut before the cursor |
| <kbd>↑</kbd> <kbd>↓</kbd> <kbd>Tab</kbd> <kbd>Esc</kbd> | Drive the suggestion dropdown |

Both extension shortcuts can be re-bound at `chrome://extensions/shortcuts` in
Chrome, or from **Manage Extension Shortcuts** in the gear menu on
`about:addons` in Firefox.

### Placeholders

| Placeholder | Becomes |
| --- | --- |
| `{date}` | Today's date, in your locale format |
| `{time}` | The current time |
| `{datetime}` | Date and time together |
| `{iso}` | `2026-08-24` |
| `{weekday}` | `Monday` |
| `{day}` / `{month}` / `{year}` | `24` / `08` / `2026` |
| `{uuid}` | A fresh random UUID |
| `{cursor}` | Not inserted — marks where the caret ends up |

Use the **Preview** button in the editor to see exactly what a snippet will
insert, `{cursor}` position included.

### Overlapping shortcuts

If you have both `\gen` and `\general`, instant mode deliberately waits rather
than expanding `\gen` the moment you type it — otherwise `\general` would be
impossible to type. Press <kbd>Tab</kbd> to commit the shorter one.

### Where it deliberately does nothing

- Password fields, and inputs marked as one-time-code.
- Browser-internal pages (`chrome://`, the Web Store, other extensions' pages) —
  Chrome does not allow content scripts there.
- Any hostname on your **🚫 Sites** list.

## Project structure

```
keyslash/
├── chrome/                # Load this folder as an unpacked extension
│   ├── manifest.json      # MV3, background.service_worker
│   ├── background.js      # Defaults, commands, badge, usage counts
│   ├── content.js         # The expansion engine + suggestion dropdown
│   ├── popup.html/.js     # Toolbar popup: quick edits and the on/off switches
│   ├── settings.html/.js  # Full manager: library, import/export, preferences, sites
│   └── icons/             # Extension icons + UPI QR asset
├── firefox/               # Same files, Gecko manifest — see "Two builds" below
│   └── manifest.json      # MV3, background.scripts + browser_specific_settings
├── docs/
│   ├── privacy.html       # Also the GitHub Pages source for the policy URL
│   ├── CHROME_STORE_NOTES.md
│   └── README.md
├── tools/
│   ├── check-wiring.js      # Manifest / asset / DOM wiring, plus build drift
│   ├── test-engine.js       # Behavioural tests for the expansion engine
│   ├── test-portability.js  # Import / export round-trip tests
│   └── sync-firefox.ps1     # Copies shared files from chrome/ to firefox/
├── make-icons.ps1         # Regenerates the PNG icons into both builds
├── privacy.html
├── CHANGELOG.md
└── LICENSE
```

### Two builds, one source

`chrome/` and `firefox/` hold byte-identical JS, HTML and icons. Only
`manifest.json` differs:

| | Chrome | Firefox |
| --- | --- | --- |
| Background | `service_worker` | `scripts` (MV3 in Firefox has no service worker in release) |
| Extra keys | — | `browser_specific_settings.gecko` — add-on id, `strict_min_version` |

No `browser`/`chrome` shim is needed. Firefox implements the `chrome` namespace
for MV3 and returns promises when no callback is passed, which is the style this
codebase uses.

After editing anything in `chrome/`, sync and re-check:

```
powershell -ExecutionPolicy Bypass -File .\tools\sync-firefox.ps1
node tools/check-wiring.js
```

`check-wiring.js` hashes every shared file in both folders and fails if they've
drifted, so a forgotten sync can't reach a release.

## Development

Nothing under `tools/` needs `npm install` — they run on a bare Node install:

```
node tools/check-wiring.js      # both manifests, assets, DOM wiring, build drift
node tools/test-engine.js       # 47 tests against the expansion engine
node tools/test-portability.js  # 45 tests against import / export
```

`test-engine.js` loads `chrome/content.js` unmodified against a hand-rolled DOM
and drives it with the same events a browser dispatches, so the expansion rules
(modes, overlapping shortcuts, placeholders, skipped fields, IME composition)
stay covered without a browser in the loop. `test-portability.js` pulls the real
export and import functions out of `chrome/settings.js` and checks that a file
written by Export All can be read straight back, that foreign field names from
other expanders are mapped, and that junk entries are dropped.

`make-icons.ps1` regenerates the three PNG icons from code, so there's no binary
source asset to keep in sync:

```
powershell -ExecutionPolicy Bypass -File .\make-icons.ps1
```

## Permissions, and why

| Permission | Why |
| --- | --- |
| `storage` | Saving your snippets, preferences and theme locally. |
| `activeTab` | The popup reads the current tab's hostname for the "off on this site" switch. |
| Host access to all sites | A text expander has to be able to see the field you're typing in, and you don't know in advance which sites that will be. Access is only ever used to watch for your own shortcuts and replace them. |

Nothing is collected or transmitted — see [privacy.html](privacy.html).

## Contributing

Issues and pull requests are welcome. For expansion bugs, the useful details
are: the site and the specific editor (plain textarea, Gmail compose, Slack,
etc.), your browser and version, which expand mode you're on, and what you
typed vs. what you got.

## Support this project

Built and maintained in spare time. If it saves you time:

- ☕ **International:** [ko-fi.com/ysaryan](https://ko-fi.com/ysaryan)
- 🇮🇳 **India (UPI):** `ysaryanraj@okaxis` — QR code is in the Support panel
  inside the extension's manager page.
- ⭐ Starring this repo also helps a lot — it costs nothing and helps others
  discover the project.

## Community

Join the community / follow updates at
[sncommands.ysaryan.eu.org](https://sncommands.ysaryan.eu.org).

## License

GNU General Public License v3.0 — see [LICENSE](LICENSE).
