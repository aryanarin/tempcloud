'use strict';

// ── KeySlash — toolbar popup ─────────────────────────────────────────────────
// A trimmed-down version of the manager: quick edits, the on/off switches, and
// a shortcut to the full page for import/export and preferences.

const STORE_SNIPPETS = 'bteSnippets';
const STORE_SETTINGS = 'bteSettings';
const STORE_THEME    = 'bteTheme';

const DEFAULT_SETTINGS = {
  enabled:       true,
  prefix:        '\\',
  mode:          'instant',
  caseSensitive: false,
  suggestions:   true,
  sugMin:        1,
  excluded:      []
};

let snippets   = [];
let settings   = Object.assign({}, DEFAULT_SETTINGS);
let activeId   = null;
let currentHost = '';

const btnTheme        = document.getElementById('btnTheme');
const btnSettings     = document.getElementById('btnSettings');
const btnNew          = document.getElementById('btnNew');

const strip           = document.getElementById('strip');
const swEnabled       = document.getElementById('swEnabled');
const swEnabledLabel  = document.getElementById('swEnabledLabel');
const siteRow         = document.getElementById('siteRow');
const swSite          = document.getElementById('swSite');
const siteHost        = document.getElementById('siteHost');
const stripNote       = document.getElementById('stripNote');

const searchInput     = document.getElementById('searchInput');
const snipList        = document.getElementById('snipList');
const rightPanel      = document.getElementById('rightPanel');
const snipCountEl     = document.getElementById('snipCount');
const statusHint      = document.getElementById('statusHint');
const toast           = document.getElementById('toast');

const prefix = () => settings.prefix || '\\';

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2200);
}

function plural(n, word) { return n + ' ' + word + (n === 1 ? '' : 's'); }
function newId() {
  return 'bte-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
}
function norm(s) {
  return settings.caseSensitive ? String(s) : String(s).toLowerCase();
}
function oneLine(text) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  return s.length > 60 ? s.slice(0, 60) + '\u2026' : s;
}

// ── Theme ─────────────────────────────────────────────────────────────────────
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  btnTheme.textContent = theme === 'dark' ? '☀️' : '🌙';
  btnTheme.title = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
}
btnTheme.addEventListener('click', () => {
  const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  chrome.storage.local.set({ [STORE_THEME]: next });
  applyTheme(next);
});

// ── Storage ───────────────────────────────────────────────────────────────────
function saveSnippets(cb) {
  chrome.storage.local.set({ [STORE_SNIPPETS]: snippets }, () => cb && cb());
}
function saveSettings(cb) {
  chrome.storage.local.set({ [STORE_SETTINGS]: settings }, () => cb && cb());
}

// ── Manager / support shortcuts ───────────────────────────────────────────────
// Routed through the service worker so an already-open manager tab is reused
// rather than a second copy being stacked on top of it.
function openManager(query) {
  const fallback = () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('settings.html') + (query || '') });
  };
  try {
    chrome.runtime.sendMessage({ source: 'BTE_OPEN_SETTINGS', query: query || '' }, () => {
      if (chrome.runtime.lastError) fallback();
      window.close();
    });
  } catch (err) {
    fallback();
    window.close();
  }
}
btnSettings.addEventListener('click', () => openManager());

// ── On/off switches ───────────────────────────────────────────────────────────
function isExcluded(host) {
  if (!host) return false;
  return (settings.excluded || []).some((d) => {
    const clean = String(d || '').toLowerCase();
    return host === clean || host.endsWith('.' + clean);
  });
}

function paintStrip() {
  const on = settings.enabled !== false;
  strip.classList.toggle('off', !on);
  swEnabled.checked = on;
  swEnabledLabel.textContent = on ? 'Expansion on' : 'Expansion off';

  if (currentHost) {
    siteHost.textContent = currentHost;
    swSite.disabled = !on;
    swSite.checked  = isExcluded(currentHost);
    siteRow.style.opacity = on ? '1' : '0.55';
    stripNote.textContent = !on
      ? 'Nothing expands anywhere while this is off'
      : (swSite.checked ? 'Reload the tab to apply' : '');
  } else {
    siteRow.style.display = 'none';
    stripNote.textContent = 'Expansion does not run on browser-internal pages';
  }
}

swEnabled.addEventListener('change', () => {
  settings.enabled = swEnabled.checked;
  saveSettings(() => {
    paintStrip();
    updateStatus();
    showToast(settings.enabled ? '✅ Expansion on' : '⏸ Expansion off');
  });
});

swSite.addEventListener('change', () => {
  if (!currentHost) return;
  settings.excluded = settings.excluded || [];
  if (swSite.checked) {
    if (!settings.excluded.includes(currentHost)) settings.excluded.push(currentHost);
  } else {
    settings.excluded = settings.excluded.filter(h => h !== currentHost);
  }
  saveSettings(() => {
    paintStrip();
    showToast(swSite.checked ? '🚫 Off on ' + currentHost : '✅ On for ' + currentHost);
  });
});

// ── Status bar ────────────────────────────────────────────────────────────────
function updateStatus() {
  snipCountEl.textContent = plural(snippets.length, 'snippet');
  statusHint.textContent  = 'Type ' + prefix() + 'shortcut in any text field \u00b7 ⚙️ for import / export';
}

// ── List ──────────────────────────────────────────────────────────────────────
function sortedSnippets(list) {
  return list.slice().sort((a, b) => {
    const aHas = a.order != null && a.order !== '';
    const bHas = b.order != null && b.order !== '';
    if (aHas && bHas) return a.order - b.order;
    if (aHas) return -1;
    if (bHas) return 1;
    return String(a.shortcut || '').localeCompare(String(b.shortcut || ''), undefined, { sensitivity: 'base' });
  });
}

function renderList() {
  const filter = searchInput.value.trim().toLowerCase();
  const filtered = sortedSnippets(snippets.filter((s) => {
    if (!filter) return true;
    return String(s.shortcut || '').toLowerCase().includes(filter) ||
           String(s.label    || '').toLowerCase().includes(filter) ||
           String(s.text     || '').toLowerCase().includes(filter);
  }));

  updateStatus();
  snipList.innerHTML = '';

  if (!filtered.length) {
    const el = document.createElement('div');
    el.className = 'empty-list';
    if (!snippets.length) el.innerHTML = 'No snippets yet.<br>Click <strong>+ New</strong>';
    else el.append('No results for \u201c', searchInput.value.trim(), '\u201d');
    snipList.appendChild(el);
    return;
  }

  filtered.forEach((snip) => {
    const item = document.createElement('div');
    item.className = 'snip-item' + (snip.id === activeId ? ' active' : '');

    const nameEl = document.createElement('div');
    nameEl.className = 'snip-item-name';
    nameEl.textContent = prefix() + snip.shortcut;

    const hintEl = document.createElement('div');
    hintEl.className = 'snip-item-hint';
    hintEl.textContent = snip.label ? snip.label : (oneLine(snip.text) || '\u2014');

    item.append(nameEl, hintEl);
    item.addEventListener('click', () => selectSnippet(snip.id));
    snipList.appendChild(item);
  });
}

function showEmptyState() {
  activeId = null;
  rightPanel.className = 'right-panel empty-state';
  rightPanel.innerHTML =
    '<div class="empty-icon">⚡</div>' +
    '<div class="empty-text">Select a snippet to edit<br>or click <strong>+ New</strong></div>';
}

function selectSnippet(id) {
  activeId = id;
  const snip = snippets.find(s => s.id === id);
  if (snip) buildEditor(snip); else showEmptyState();
  renderList();
}

// ── Mini editor ───────────────────────────────────────────────────────────────
function buildEditor(snip) {
  rightPanel.className = 'right-panel';
  rightPanel.innerHTML = '';

  const fieldRow = document.createElement('div');
  fieldRow.className = 'field-row';

  const scGroup = document.createElement('div');
  scGroup.className = 'field-group';
  scGroup.style.maxWidth = '180px';
  const scLbl = document.createElement('div');
  scLbl.className = 'field-label';
  scLbl.textContent = 'Shortcut';
  const addon = document.createElement('div');
  addon.className = 'addon';
  const addonPre = document.createElement('span');
  addonPre.className = 'addon-pre';
  addonPre.textContent = prefix();
  const scInput = document.createElement('input');
  scInput.className = 'field-input mono';
  scInput.value = snip ? String(snip.shortcut || '') : '';
  scInput.placeholder = 'gen';
  scInput.spellcheck = false;
  addon.append(addonPre, scInput);
  scGroup.append(scLbl, addon);

  const labelGroup = document.createElement('div');
  labelGroup.className = 'field-group';
  const labelLbl = document.createElement('div');
  labelLbl.className = 'field-label';
  labelLbl.textContent = 'Label';
  const labelInput = document.createElement('input');
  labelInput.className = 'field-input';
  labelInput.value = snip ? String(snip.label || '') : '';
  labelInput.placeholder = 'Short description';
  labelGroup.append(labelLbl, labelInput);

  fieldRow.append(scGroup, labelGroup);

  const textSection = document.createElement('div');
  textSection.className = 'text-section';
  const textLbl = document.createElement('div');
  textLbl.className = 'field-label';
  textLbl.textContent = 'Expanded text';
  const textArea = document.createElement('textarea');
  textArea.className = 'text-area';
  textArea.value = snip ? String(snip.text || '') : '';
  textArea.placeholder = 'General Text for testing purpose';
  textSection.append(textLbl, textArea);

  const actionBar = document.createElement('div');
  actionBar.className = 'action-bar';
  const actionLeft = document.createElement('div');
  actionLeft.className = 'action-left';
  const actionRight = document.createElement('div');
  actionRight.className = 'action-right';

  const copyBtn = document.createElement('button');
  copyBtn.className = 'btn btn-secondary';
  copyBtn.type = 'button';
  copyBtn.textContent = '📋 Copy';
  copyBtn.title = 'Copy the expanded text';
  actionLeft.appendChild(copyBtn);

  if (snip) {
    const delBtn = document.createElement('button');
    delBtn.className = 'btn btn-danger';
    delBtn.type = 'button';
    delBtn.textContent = '🗑 Delete';
    delBtn.addEventListener('click', () => {
      if (!confirm('Delete "' + prefix() + snip.shortcut + '"?')) return;
      snippets = snippets.filter(s => s.id !== snip.id);
      saveSnippets(() => { showToast('🗑 Deleted'); showEmptyState(); renderList(); });
    });
    actionLeft.appendChild(delBtn);
  }

  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn btn-primary';
  saveBtn.type = 'button';
  saveBtn.textContent = snip ? '💾 Save' : '💾 Create';
  actionRight.appendChild(saveBtn);

  actionBar.append(actionLeft, actionRight);
  rightPanel.append(fieldRow, textSection, actionBar);

  if (!snip) setTimeout(() => scInput.focus(), 40);

  copyBtn.addEventListener('click', () => {
    if (!textArea.value.trim()) { showToast('⚠️ Nothing to copy!'); return; }
    navigator.clipboard.writeText(textArea.value)
      .then(()  => showToast('📋 Copied!'))
      .catch(() => showToast('❌ Could not copy'));
  });

  saveBtn.addEventListener('click', () => {
    let shortcut = scInput.value.trim();
    const p = prefix();
    while (shortcut.startsWith(p)) shortcut = shortcut.slice(p.length);
    shortcut = shortcut.trim();

    addon.classList.remove('error');
    textArea.classList.remove('error');

    if (!shortcut) { addon.classList.add('error'); scInput.focus(); showToast('⚠️ Needs a shortcut'); return; }
    if (/\s/.test(shortcut)) { addon.classList.add('error'); scInput.focus(); showToast('⚠️ No spaces in shortcuts'); return; }
    if (!textArea.value.trim()) { textArea.classList.add('error'); textArea.focus(); showToast('⚠️ Needs some text'); return; }

    const clash = snippets.find(s => s.id !== activeId && norm(s.shortcut) === norm(shortcut));
    if (clash) { addon.classList.add('error'); scInput.focus(); showToast('⚠️ ' + p + shortcut + ' is taken'); return; }

    if (activeId) {
      const idx = snippets.findIndex(s => s.id === activeId);
      if (idx !== -1) {
        snippets[idx] = Object.assign({}, snippets[idx], {
          shortcut, label: labelInput.value.trim(), text: textArea.value, updatedAt: Date.now()
        });
      }
    } else {
      const created = {
        id: newId(), shortcut, label: labelInput.value.trim(), text: textArea.value,
        order: null, createdAt: Date.now(), uses: 0
      };
      snippets.push(created);
      activeId = created.id;
    }

    saveSnippets(() => {
      showToast('✅ Saved — try ' + p + shortcut);
      renderList();
    });
  });
}

btnNew.addEventListener('click', () => { activeId = null; buildEditor(null); renderList(); });
searchInput.addEventListener('input', renderList);

// ── Init ──────────────────────────────────────────────────────────────────────
(function init() {
  chrome.storage.local.get([STORE_SNIPPETS, STORE_SETTINGS, STORE_THEME], (res) => {
    snippets = Array.isArray(res[STORE_SNIPPETS]) ? res[STORE_SNIPPETS] : [];
    settings = Object.assign({}, DEFAULT_SETTINGS, res[STORE_SETTINGS] || {});
    if (!settings.prefix) settings.prefix = DEFAULT_SETTINGS.prefix;
    applyTheme(res[STORE_THEME] === 'light' ? 'light' : 'dark');

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs && tabs[0] && tabs[0].url;
      if (url && /^https?:/i.test(url)) {
        try { currentHost = new URL(url).hostname.toLowerCase().replace(/^www\./, ''); }
        catch (e) { currentHost = ''; }
      }
      paintStrip();
    });

    renderList();
  });
})();
