'use strict';

// ── Background service worker ─────────────────────────────────────────────────
// Deliberately thin. All the real work happens in content.js (expansion) and
// settings.js / popup.js (management). This worker only:
//
//   1. Seeds sensible defaults on first install.
//   2. Handles the two keyboard commands (open manager / toggle on-off).
//   3. Keeps the toolbar badge in sync so you can always see whether
//      expansion is currently switched on.
//   4. Bumps the per-snippet usage counter when content.js reports an expansion
//      (done here so several frames/tabs can't clobber each other's writes).

// The `bte` prefix predates the rename to KeySlash and is kept deliberately.
// These are storage keys, not labels: changing them would orphan every snippet
// a user has already saved. Same reasoning for the `bte-` id prefix, the
// `BTE_*` message names and the `data-bte-ui` attribute in content.js. Nothing
// here is ever shown to a user.
const STORE_SNIPPETS = 'bteSnippets';
const STORE_SETTINGS = 'bteSettings';

// Keep this in sync with the copies in content.js, settings.js and popup.js.
const DEFAULT_SETTINGS = {
  enabled:       true,
  prefix:        '\\',      // the trigger character, e.g. \gen
  mode:          'instant', // 'instant' | 'space' | 'tab'
  caseSensitive: false,
  suggestions:   true,      // show the inline shortcut dropdown while typing
  sugMin:        1,         // characters after the prefix before that dropdown shows
  excluded:      []         // hostnames where expansion is switched off
};

const DEFAULT_SNIPPETS = [
  {
    id:        'seed-gen',
    shortcut:  'gen',
    label:     'General test text',
    text:      'General Text for testing purpose',
    order:     10,
    createdAt: Date.now(),
    uses:      0
  },
  {
    id:        'seed-sig',
    shortcut:  'sig',
    label:     'Email sign-off',
    text:      'Best regards,\nAryan',
    order:     20,
    createdAt: Date.now(),
    uses:      0
  },
  {
    id:        'seed-today',
    shortcut:  'today',
    label:     "Today's date (dynamic)",
    text:      '{date}',
    order:     30,
    createdAt: Date.now(),
    uses:      0
  }
];

// ── Badge ─────────────────────────────────────────────────────────────────────
async function refreshBadge() {
  const { [STORE_SETTINGS]: settings } = await chrome.storage.local.get(STORE_SETTINGS);
  const enabled = !settings || settings.enabled !== false;
  try {
    await chrome.action.setBadgeText({ text: enabled ? '' : 'OFF' });
    await chrome.action.setBadgeBackgroundColor({ color: '#94a3b8' });
    await chrome.action.setTitle({
      title: enabled
        ? 'KeySlash'
        : 'KeySlash — expansion is OFF'
    });
  } catch (err) { /* action API unavailable during early startup */ }
}

// ── Settings page ─────────────────────────────────────────────────────────────
const settingsUrl = () => chrome.runtime.getURL('settings.html');

// Reuses an already-open manager tab instead of stacking up duplicates.
//
// getContexts() is used rather than tabs.query({ url }) on purpose: filtering
// tabs by URL requires the broad "tabs" permission ("Read your browsing
// history" at install time), which this extension has no other use for.
// getContexts only ever reports our own pages, so it needs no permission.
async function findManagerTab(base) {
  if (typeof chrome.runtime.getContexts !== 'function') return null;
  try {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['TAB'] });
    return contexts.find(c =>
      c && typeof c.tabId === 'number' && c.tabId >= 0 &&
      typeof c.documentUrl === 'string' && c.documentUrl.startsWith(base)
    ) || null;
  } catch (err) {
    return null;
  }
}

async function openSettings(query) {
  const base = settingsUrl();
  const url  = query ? base + query : base;

  const open = await findManagerTab(base);
  if (open) {
    try {
      await chrome.tabs.update(open.tabId, { active: true, url });
      if (typeof open.windowId === 'number' && open.windowId >= 0) {
        try { await chrome.windows.update(open.windowId, { focused: true }); } catch (err) {}
      }
      return;
    } catch (err) {
      // Tab went away between the lookup and the update — fall through.
    }
  }
  await chrome.tabs.create({ url });
}

// ── Install / startup ─────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async (details) => {
  const stored = await chrome.storage.local.get([STORE_SNIPPETS, STORE_SETTINGS]);

  const patch = {};
  if (!Array.isArray(stored[STORE_SNIPPETS])) patch[STORE_SNIPPETS] = DEFAULT_SNIPPETS;
  patch[STORE_SETTINGS] = { ...DEFAULT_SETTINGS, ...(stored[STORE_SETTINGS] || {}) };
  await chrome.storage.local.set(patch);

  await refreshBadge();

  if (details.reason === 'install') openSettings('?welcome=1');
});

chrome.runtime.onStartup.addListener(refreshBadge);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[STORE_SETTINGS]) refreshBadge();
});

// ── Keyboard commands ─────────────────────────────────────────────────────────
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'open-manager') {
    openSettings();
    return;
  }
  if (command === 'toggle-expander') {
    const { [STORE_SETTINGS]: settings } = await chrome.storage.local.get(STORE_SETTINGS);
    const next = { ...DEFAULT_SETTINGS, ...(settings || {}) };
    next.enabled = !(next.enabled !== false);
    await chrome.storage.local.set({ [STORE_SETTINGS]: next });
    await refreshBadge();
  }
});

// ── Messages ──────────────────────────────────────────────────────────────────
// Usage counting is serialised here: content scripts in many frames may report
// expansions at nearly the same moment, and a read-modify-write done in each
// frame would lose updates.
let usageQueue = [];
let usageTimer = null;

function flushUsage() {
  usageTimer = null;
  const batch = usageQueue;
  usageQueue = [];
  if (!batch.length) return;

  chrome.storage.local.get(STORE_SNIPPETS, (res) => {
    const snippets = Array.isArray(res[STORE_SNIPPETS]) ? res[STORE_SNIPPETS] : [];
    let touched = false;
    batch.forEach(({ id, at }) => {
      const s = snippets.find(x => x.id === id);
      if (!s) return;
      s.uses       = (s.uses || 0) + 1;
      s.lastUsedAt = at;
      touched = true;
    });
    if (touched) chrome.storage.local.set({ [STORE_SNIPPETS]: snippets });
  });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.source) return false;

  if (msg.source === 'BTE_USED' && msg.id) {
    usageQueue.push({ id: msg.id, at: Date.now() });
    if (!usageTimer) usageTimer = setTimeout(flushUsage, 800);
    sendResponse({ ok: true });
    return false;
  }

  if (msg.source === 'BTE_OPEN_SETTINGS') {
    openSettings(msg.query || '')
      .then(() => sendResponse({ ok: true }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  return false;
});
