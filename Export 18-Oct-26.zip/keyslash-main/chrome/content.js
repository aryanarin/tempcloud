'use strict';

// ── KeySlash — content script ────────────────────────────────────────────────
// Watches whatever field you're typing in and swaps `\shortcut` for its saved
// text. Runs in every frame of every page (including about:blank frames, which
// is how a lot of classic rich-text editors are built).
//
// Two field families are supported, and they need completely different
// treatment:
//
//   • <input> / <textarea>  → character offsets into `.value`
//   • contenteditable       → offsets into a DOM text node, via Range
//
// In both cases the replacement is performed with `document.execCommand`
// ('insertText') where possible. It is technically deprecated, but it is still
// the only way to edit a field that (a) participates in the browser's native
// undo stack and (b) looks like real typing to frameworks such as React, which
// otherwise ignore direct `.value` assignment. A native-setter fallback covers
// the cases where execCommand refuses.

(function () {

  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return;

  const STORE_SNIPPETS = 'bteSnippets';
  const STORE_SETTINGS = 'bteSettings';
  const STORE_THEME    = 'bteTheme';

  const DEFAULT_SETTINGS = {
    enabled:       true,
    prefix:        '\\',
    mode:          'instant',   // 'instant' | 'space' | 'tab'
    caseSensitive: false,
    suggestions:   true,
    sugMin:        1,           // characters after the prefix before the dropdown shows
    excluded:      []
  };

  // How far back from the caret we bother looking for a trigger.
  const MAX_SCAN     = 120;
  const MAX_SUGGEST  = 8;
  // <input> types that actually support the text-selection API. email, number,
  // date & friends throw InvalidStateError on setSelectionRange, and password
  // is deliberately never touched.
  const SELECTABLE   = new Set(['text', 'search', 'url', 'tel', '']);

  let snippets     = [];
  let settings     = Object.assign({}, DEFAULT_SETTINGS);
  let theme        = 'dark';
  let excludedHere = false;

  // Re-entrancy guard: our own execCommand fires a synchronous `input` event,
  // and without this a snippet whose text happens to end in another shortcut
  // would expand forever.
  let busy      = false;
  let composing = false;

  // ── Storage ────────────────────────────────────────────────────────────────
  function readAll() {
    chrome.storage.local.get([STORE_SNIPPETS, STORE_SETTINGS, STORE_THEME], (res) => {
      if (chrome.runtime.lastError) return;
      snippets = Array.isArray(res[STORE_SNIPPETS]) ? res[STORE_SNIPPETS] : [];
      settings = Object.assign({}, DEFAULT_SETTINGS, res[STORE_SETTINGS] || {});
      if (!settings.prefix) settings.prefix = DEFAULT_SETTINGS.prefix;
      theme        = res[STORE_THEME] === 'light' ? 'light' : 'dark';
      excludedHere = isExcludedHost();
      closeSuggest();
      applySuggestTheme();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[STORE_SNIPPETS] || changes[STORE_SETTINGS] || changes[STORE_THEME]) readAll();
  });

  // The first readAll() is deliberately deferred to the bottom of this file:
  // its callback touches the dropdown state declared further down, and a
  // storage backend that answers synchronously would otherwise hit the
  // temporal dead zone on those `let` bindings.

  // ── Where are we? ──────────────────────────────────────────────────────────
  function currentHost() {
    let h = location.hostname;
    if (!h) { try { h = new URL(document.referrer).hostname; } catch (e) {} }
    if (!h) { try { h = new URL(window.top.location.href).hostname; } catch (e) {} }
    return h || '';
  }

  function isExcludedHost() {
    const host = currentHost().toLowerCase();
    if (!host) return false;
    return (settings.excluded || []).some((raw) => {
      const d = String(raw || '').trim().toLowerCase().replace(/^\*\./, '');
      if (!d) return false;
      return host === d || host.endsWith('.' + d);
    });
  }

  function active() {
    return settings.enabled !== false && !excludedHere && snippets.length > 0;
  }

  // ── Field detection ────────────────────────────────────────────────────────
  // activeElement stops at a shadow host, so walk down through open roots.
  function deepActiveElement() {
    let el = document.activeElement;
    let guard = 0;
    while (el && el.shadowRoot && el.shadowRoot.activeElement && guard++ < 20) {
      el = el.shadowRoot.activeElement;
    }
    return el;
  }

  function isPlainTextField(el) {
    if (!el || !el.tagName) return false;
    if (el.tagName === 'TEXTAREA') return !el.readOnly && !el.disabled;
    if (el.tagName !== 'INPUT') return false;
    const type = String(el.type || 'text').toLowerCase();
    if (!SELECTABLE.has(type)) return false;
    if (el.readOnly || el.disabled) return false;
    // Never expand into anything that looks like a credential or OTP box.
    const auto = String(el.autocomplete || '').toLowerCase();
    if (auto.indexOf('password') !== -1 || auto === 'one-time-code') return false;
    return true;
  }

  function selectionFor(el) {
    const root = el && el.getRootNode ? el.getRootNode() : document;
    if (root && typeof root.getSelection === 'function') {
      const s = root.getSelection();
      if (s) return s;
    }
    return window.getSelection();
  }

  // Snapshot of "the field the user is typing in, and the text before the caret".
  function getContext() {
    const el = deepActiveElement();
    if (!el) return null;

    if (isPlainTextField(el)) {
      if (typeof el.selectionStart !== 'number') return null;
      if (el.selectionStart !== el.selectionEnd) return null;   // ignore selections
      return {
        kind:   'input',
        el:     el,
        caret:  el.selectionStart,
        before: String(el.value).slice(0, el.selectionStart)
      };
    }

    if (el.isContentEditable) {
      const sel = selectionFor(el);
      if (!sel || !sel.rangeCount || !sel.isCollapsed) return null;
      const node = sel.anchorNode;
      if (!node || node.nodeType !== 3 /* TEXT_NODE */) return null;
      return {
        kind:   'editable',
        el:     el,
        sel:    sel,
        node:   node,
        caret:  sel.anchorOffset,
        before: String(node.textContent).slice(0, sel.anchorOffset)
      };
    }

    return null;
  }

  // ── Trigger parsing ────────────────────────────────────────────────────────
  // Finds the last `prefix` before the caret and returns whatever was typed
  // after it, as long as that's a single unbroken word.
  function findToken(before) {
    const prefix = settings.prefix || '\\';
    const scan   = before.slice(-MAX_SCAN);
    const idx    = scan.lastIndexOf(prefix);
    if (idx === -1) return null;
    const token = scan.slice(idx + prefix.length);
    if (/\s/.test(token)) return null;
    return {
      token: token,
      start: before.length - (scan.length - idx)   // absolute index of the prefix
    };
  }

  function norm(s) {
    return settings.caseSensitive ? String(s) : String(s).toLowerCase();
  }

  function exactMatch(token) {
    if (!token) return null;
    const t = norm(token);
    return snippets.find(s => s && s.shortcut && norm(s.shortcut) === t) || null;
  }

  // `\gen` shouldn't fire instantly if `\general` also exists — otherwise the
  // longer shortcut becomes impossible to type. Tab still force-expands.
  function hasLongerShortcut(token) {
    const t = norm(token);
    return snippets.some((s) => {
      if (!s || !s.shortcut) return false;
      const sc = norm(s.shortcut);
      return sc.length > t.length && sc.indexOf(t) === 0;
    });
  }

  function bySortOrder(a, b) {
    const aHas = a.order != null && a.order !== '';
    const bHas = b.order != null && b.order !== '';
    if (aHas && bHas) return a.order - b.order;
    if (aHas) return -1;
    if (bHas) return 1;
    return String(a.shortcut).localeCompare(String(b.shortcut), undefined, { sensitivity: 'base' });
  }

  function matchList(token) {
    const t = norm(token);
    const lower = String(token).toLowerCase();
    return snippets
      .filter((s) => {
        if (!s || !s.shortcut) return false;
        if (!t) return true;
        return norm(s.shortcut).indexOf(t) === 0 ||
               String(s.label || '').toLowerCase().indexOf(lower) !== -1;
      })
      .sort(bySortOrder)
      .slice(0, MAX_SUGGEST);
  }

  // ── Dynamic placeholders ───────────────────────────────────────────────────
  function pad2(n) { return String(n).padStart(2, '0'); }

  function makeUuid() {
    try {
      if (crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    } catch (e) {}
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    });
  }

  // Returns the final text plus where the caret should land ({cursor}, or -1).
  function renderSnippet(raw) {
    const now = new Date();
    const map = {
      date:     now.toLocaleDateString(),
      time:     now.toLocaleTimeString(),
      datetime: now.toLocaleString(),
      iso:      now.getFullYear() + '-' + pad2(now.getMonth() + 1) + '-' + pad2(now.getDate()),
      day:      pad2(now.getDate()),
      month:    pad2(now.getMonth() + 1),
      year:     String(now.getFullYear()),
      weekday:  now.toLocaleDateString(undefined, { weekday: 'long' }),
      uuid:     makeUuid()
    };

    let out = String(raw == null ? '' : raw)
      .replace(/\{(date|time|datetime|iso|day|month|year|weekday|uuid)\}/gi,
               (_m, key) => map[key.toLowerCase()]);

    let cursor = -1;
    const hit = /\{cursor\}/i.exec(out);
    if (hit) {
      cursor = hit.index;
      out    = out.slice(0, hit.index) + out.slice(hit.index + hit[0].length);
      out    = out.replace(/\{cursor\}/gi, '');   // ignore any extras
    }

    return { text: out, cursor: cursor };
  }

  // ── Replacement: <input> / <textarea> ──────────────────────────────────────
  // `tail` is the number of characters left standing after `end` that the user
  // just typed (the space that committed a space-mode expansion). The caret has
  // to land after them, or the next keystroke would be inserted before the
  // space instead of after it.
  function replaceInInput(el, start, end, text, cursor, tail) {
    const before = String(el.value);
    try { el.setSelectionRange(start, end); } catch (e) { return false; }

    let ok = false;
    try { ok = document.execCommand('insertText', false, text); } catch (e) { ok = false; }

    if (!ok || el.value === before) {
      // React & friends track the value on their own copy of the node, so poke
      // the native setter and then announce it, rather than assigning directly.
      const proto = el.tagName === 'TEXTAREA'
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, 'value');
      const next = before.slice(0, start) + text + before.slice(end);
      if (desc && desc.set) desc.set.call(el, next); else el.value = next;
      el.dispatchEvent(new Event('input',  { bubbles: true, composed: true }));
      el.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
    }

    const caret = start + (cursor >= 0 ? cursor : text.length + (tail || 0));
    try { el.setSelectionRange(caret, caret); } catch (e) {}
    return true;
  }

  // ── Replacement: contenteditable ───────────────────────────────────────────
  function replaceInEditable(ctx, start, end, text, cursor, tail) {
    const sel   = ctx.sel;
    const range = document.createRange();
    try {
      range.setStart(ctx.node, start);
      range.setEnd(ctx.node, end);
    } catch (e) { return false; }

    sel.removeAllRanges();
    sel.addRange(range);

    let ok = false;
    try { ok = document.execCommand('insertText', false, text); } catch (e) { ok = false; }

    if (!ok) {
      // Manual fallback — build the fragment ourselves, turning newlines into
      // <br> since a raw "\n" is collapsed by HTML whitespace rules.
      range.deleteContents();
      const frag  = document.createDocumentFragment();
      const lines = text.split('\n');
      lines.forEach((line, i) => {
        if (i) frag.appendChild(document.createElement('br'));
        if (line) frag.appendChild(document.createTextNode(line));
      });
      const last = frag.lastChild;
      range.insertNode(frag);
      if (last) {
        const after = document.createRange();
        after.setStartAfter(last);
        after.collapse(true);
        sel.removeAllRanges();
        sel.addRange(after);
      }
      ctx.el.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    }

    // The caret now sits at the end of the insertion, which is one step too far
    // left when a committing space was kept, and too far right when the snippet
    // asked for {cursor}. Both are walked with sel.modify, and only for
    // single-line text where "N characters" is unambiguous.
    if (typeof sel.modify === 'function' && text.indexOf('\n') === -1) {
      const steps = cursor >= 0 ? cursor - text.length : (tail || 0);
      const dir   = steps < 0 ? 'backward' : 'forward';
      for (let i = 0; i < Math.abs(steps); i++) {
        try { sel.modify('move', dir, 'character'); } catch (e) { break; }
      }
    }
    return true;
  }

  // ── Expand ─────────────────────────────────────────────────────────────────
  // `trailing` is how many already-typed characters at the caret to keep
  // (1 for the space that triggered a space-mode expansion).
  function runExpand(ctx, tok, snippet, trailing) {
    const rendered = renderSnippet(snippet.text);
    const start = tok.start;
    const end   = ctx.caret - (trailing || 0);
    if (end < start) return false;

    busy = true;
    let done = false;
    try {
      done = ctx.kind === 'input'
        ? replaceInInput(ctx.el, start, end, rendered.text, rendered.cursor, trailing || 0)
        : replaceInEditable(ctx, start, end, rendered.text, rendered.cursor, trailing || 0);
    } catch (e) {
      done = false;
    } finally {
      busy = false;
    }

    if (done) {
      closeSuggest();
      try {
        const p = chrome.runtime.sendMessage({ source: 'BTE_USED', id: snippet.id });
        if (p && typeof p.catch === 'function') p.catch(() => {});
      } catch (e) {}
    }
    return done;
  }

  // ── Suggestion dropdown ────────────────────────────────────────────────────
  const SUGGEST_CSS = `
    .box {
      position: fixed; display: none; box-sizing: border-box;
      width: 330px; max-width: calc(100vw - 16px);
      background: var(--bg); color: var(--text);
      border: 1px solid var(--accent); border-radius: 10px;
      box-shadow: 0 16px 48px rgba(0,0,0,0.45);
      overflow: hidden; text-align: left;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 13px; line-height: 1.4;
    }
    .box[data-theme="dark"] {
      --bg:#0c1412; --bg2:#131d1b; --bg3:#0c2b25; --border:#1e2b28;
      --border2:#2b3a36; --text:#e3ebe8; --muted:#93a39e; --dim:#7b8b87;
      --mono:#5eead4; --accent:#0c8074; --amber:#fbbf24;
    }
    .box[data-theme="light"] {
      --bg:#fffefb; --bg2:#f4f2ea; --bg3:#d7efe9; --border:#e7e3d7;
      --border2:#d4cfc1; --text:#17251f; --muted:#4d605a; --dim:#657570;
      --mono:#0b7d73; --accent:#0c8074; --amber:#b45309;
    }
    .head {
      display: flex; align-items: center; gap: 7px;
      padding: 7px 11px; background: var(--bg2);
      border-bottom: 1px solid var(--border);
    }
    .logo {
      width: 18px; height: 18px; flex: none; border-radius: 4px;
      background: linear-gradient(135deg, #16a394, #0b6f64);
      color: #fff; font-weight: 900; font-size: 10px; letter-spacing: -0.5px;
      display: flex; align-items: center; justify-content: center;
    }
    .logo-slash { color: #fbbf24; }
    .head-q { font-family: monospace; font-size: 12px; color: var(--mono); flex: 1;
              overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .head-n { font-size: 10px; color: var(--dim); flex: none; }
    .list { max-height: 232px; overflow-y: auto; }
    .row {
      display: flex; align-items: center; gap: 9px;
      padding: 8px 11px; cursor: pointer;
      border-bottom: 1px solid var(--border);
      border-left: 3px solid transparent;
    }
    .row:last-child { border-bottom: none; }
    .row.on { background: var(--bg3); border-left-color: var(--accent); }
    .sc {
      font-family: monospace; font-weight: 700; font-size: 12.5px;
      color: var(--mono); flex: none; max-width: 42%;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .pv {
      color: var(--muted); font-size: 11.5px; flex: 1; min-width: 0;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .key {
      font-size: 9.5px; color: var(--dim); background: var(--border2);
      border-radius: 3px; padding: 2px 5px; flex: none;
    }
    .foot {
      padding: 5px 11px; background: var(--bg2);
      border-top: 1px solid var(--border);
      color: var(--dim); font-size: 10px;
    }
  `;

  let sugHost = null, sugBox = null, sugList = null, sugHeadQ = null, sugHeadN = null;
  let sugOpen = false, sugItems = [], sugIdx = 0, sugNavigated = false;
  // The field the open dropdown belongs to. Anything we commit has to go back
  // into that same field, never whichever one happens to be focused later.
  let sugEl = null;

  function buildSuggest() {
    if (sugHost) return;

    sugHost = document.createElement('div');
    sugHost.setAttribute('data-bte-ui', '');
    // `all: initial` first, so hostile page CSS can't hide or reflow us, then
    // re-assert the handful of properties we actually need.
    sugHost.style.cssText =
      'all: initial !important; position: fixed !important; top: 0 !important; ' +
      'left: 0 !important; width: 0 !important; height: 0 !important; ' +
      'z-index: 2147483647 !important; pointer-events: none !important;';

    const root = sugHost.attachShadow({ mode: 'open' });

    const style = document.createElement('style');
    style.textContent = SUGGEST_CSS;

    sugBox = document.createElement('div');
    sugBox.className = 'box';
    sugBox.style.pointerEvents = 'auto';

    const head = document.createElement('div');
    head.className = 'head';
    // "k" + an amber backslash, matching the toolbar icon. Built from nodes
    // rather than innerHTML so nothing here can ever parse as markup.
    const logo = document.createElement('div');
    logo.className = 'logo';
    logo.append(document.createTextNode('k'));
    const logoSlash = document.createElement('span');
    logoSlash.className   = 'logo-slash';
    logoSlash.textContent = '\\';
    logo.appendChild(logoSlash);
    sugHeadQ = document.createElement('div');
    sugHeadQ.className = 'head-q';
    sugHeadN = document.createElement('div');
    sugHeadN.className = 'head-n';
    head.append(logo, sugHeadQ, sugHeadN);

    sugList = document.createElement('div');
    sugList.className = 'list';

    const foot = document.createElement('div');
    foot.className = 'foot';
    foot.textContent = '\u2191\u2193 move \u00b7 Tab insert \u00b7 Esc dismiss';

    sugBox.append(head, sugList, foot);
    root.append(style, sugBox);
    (document.documentElement || document.body).appendChild(sugHost);
    applySuggestTheme();
  }

  function applySuggestTheme() {
    if (sugBox) sugBox.setAttribute('data-theme', theme);
  }

  function previewOf(snippet) {
    const raw = String(snippet.text || '').replace(/\s+/g, ' ').trim();
    const label = String(snippet.label || '').trim();
    const body = raw.length > 70 ? raw.slice(0, 70) + '\u2026' : raw;
    return label ? label + ' \u2014 ' + body : body;
  }

  function renderSuggest(token) {
    sugList.innerHTML = '';
    sugHeadQ.textContent = (settings.prefix || '\\') + token;
    sugHeadN.textContent = sugItems.length + (sugItems.length === 1 ? ' match' : ' matches');

    sugItems.forEach((snip, i) => {
      const row = document.createElement('div');
      row.className = 'row' + (i === sugIdx ? ' on' : '');

      const sc = document.createElement('span');
      sc.className = 'sc';
      sc.textContent = (settings.prefix || '\\') + snip.shortcut;

      const pv = document.createElement('span');
      pv.className = 'pv';
      pv.textContent = previewOf(snip);

      const key = document.createElement('span');
      key.className = 'key';
      key.textContent = i === sugIdx ? '\u21b5' : '';

      row.append(sc, pv, key);

      // mousedown + preventDefault so the field never loses focus — losing it
      // would also lose the caret position we're about to replace.
      row.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        acceptSuggest(i);
      });
      row.addEventListener('mouseenter', () => {
        sugIdx = i;
        Array.prototype.forEach.call(sugList.children, (el, n) => {
          el.classList.toggle('on', n === i);
          const k = el.querySelector('.key');
          if (k) k.textContent = n === i ? '\u21b5' : '';
        });
      });

      sugList.appendChild(row);
    });
  }

  function anchorRect(ctx) {
    if (ctx.kind === 'editable') {
      try {
        const r = ctx.sel.getRangeAt(0).getBoundingClientRect();
        if (r && (r.width || r.height || r.top || r.left)) return r;
      } catch (e) {}
    }
    return ctx.el.getBoundingClientRect();
  }

  function placeSuggest(ctx) {
    if (!sugBox) return;
    const r  = anchorRect(ctx);
    const vw = window.innerWidth  || 1024;
    const vh = window.innerHeight || 768;
    const bw = sugBox.offsetWidth  || 330;
    const bh = sugBox.offsetHeight || 240;

    let left = Math.max(8, Math.min(r.left, vw - bw - 8));
    let top  = r.bottom + 6;
    if (top + bh > vh - 8) top = Math.max(8, r.top - bh - 6);

    sugBox.style.left = Math.round(left) + 'px';
    sugBox.style.top  = Math.round(top)  + 'px';
  }

  function showSuggest(ctx, tok) {
    if (settings.suggestions === false) { closeSuggest(); return; }
    const min = Number(settings.sugMin != null ? settings.sugMin : 1);
    if (tok.token.length < min) { closeSuggest(); return; }

    const list = matchList(tok.token);
    if (!list.length) { closeSuggest(); return; }

    buildSuggest();
    sugItems = list;
    if (!sugOpen) { sugIdx = 0; sugNavigated = false; }
    else sugIdx = Math.min(sugIdx, list.length - 1);

    renderSuggest(tok.token);
    sugBox.style.display = 'block';
    sugOpen = true;
    sugEl   = ctx.el;
    placeSuggest(ctx);
  }

  function closeSuggest() {
    if (sugBox) sugBox.style.display = 'none';
    sugOpen      = false;
    sugItems     = [];
    sugIdx       = 0;
    sugNavigated = false;
    sugEl        = null;
  }

  // Drops the dropdown if the caret has wandered out of the field it was opened
  // for. Cheap insurance: focus can change without a focusout we get to see
  // (iframes, shadow DOM, scripted focus), and a stale list must never be
  // committed into whatever field the user is in now.
  function suggestStillValid() {
    if (!sugOpen) return false;
    const ctx = getContext();
    if (!ctx || ctx.el !== sugEl) { closeSuggest(); return false; }
    return true;
  }

  function moveSuggest(delta) {
    if (!sugItems.length) return;
    sugIdx = (sugIdx + delta + sugItems.length) % sugItems.length;
    sugNavigated = true;
    Array.prototype.forEach.call(sugList.children, (el, n) => {
      el.classList.toggle('on', n === sugIdx);
      const k = el.querySelector('.key');
      if (k) k.textContent = n === sugIdx ? '\u21b5' : '';
      if (n === sugIdx && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
    });
  }

  function acceptSuggest(index) {
    const snip  = sugItems[index != null ? index : sugIdx];
    const owner = sugEl;
    closeSuggest();
    if (!snip) return;
    // Re-read the live context: the caret may have moved since the dropdown
    // was rendered, and the row must still belong to the field it was drawn for.
    const ctx = getContext();
    if (!ctx || ctx.el !== owner) return;
    const tok = findToken(ctx.before);
    if (!tok) return;
    // And the row has to still be a match for what's actually typed now.
    const live = matchList(tok.token);
    if (!live.some(s => s === snip || (s && s.shortcut === snip.shortcut))) return;
    runExpand(ctx, tok, snip, 0);
  }

  // ── Input handling ─────────────────────────────────────────────────────────
  function onInput(e) {
    if (busy || composing || (e && e.isComposing)) return;
    if (!active()) { if (sugOpen) closeSuggest(); return; }

    const ctx = getContext();
    if (!ctx) { closeSuggest(); return; }

    const lastChar = ctx.before.slice(-1);

    // Space mode: the whitespace the user just typed is the commit key. Keep it.
    if (settings.mode === 'space' && lastChar && /\s/.test(lastChar)) {
      const tok = findToken(ctx.before.slice(0, -1));
      if (tok && tok.token) {
        const snip = exactMatch(tok.token);
        if (snip) { runExpand(ctx, tok, snip, 1); return; }
      }
      closeSuggest();
      return;
    }

    const tok = findToken(ctx.before);
    if (!tok || !tok.token) { closeSuggest(); return; }

    if (settings.mode === 'instant') {
      const snip = exactMatch(tok.token);
      if (snip && !hasLongerShortcut(tok.token)) { runExpand(ctx, tok, snip, 0); return; }
    }

    showSuggest(ctx, tok);
  }

  function onKeyDown(e) {
    if (busy || !active()) return;

    // Dropdown owns these keys while it's up — but only if it's still pointing
    // at the field the caret is in. A stale one is dismissed here so the key
    // falls through to the normal handling below instead of being swallowed.
    if (sugOpen && suggestStillValid()) {
      if (e.key === 'Escape')    { e.preventDefault(); e.stopPropagation(); closeSuggest(); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); e.stopPropagation(); moveSuggest(1);  return; }
      if (e.key === 'ArrowUp')   { e.preventDefault(); e.stopPropagation(); moveSuggest(-1); return; }
      if (e.key === 'Tab' && !e.shiftKey) { e.preventDefault(); e.stopPropagation(); acceptSuggest(); return; }
      // Enter is only hijacked once the user has actually picked a row with the
      // arrows — otherwise it would swallow "send" in chat apps.
      if (e.key === 'Enter' && sugNavigated) { e.preventDefault(); e.stopPropagation(); acceptSuggest(); return; }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Home' || e.key === 'End') closeSuggest();
    }

    // Tab always force-expands an exact match, in every mode. This is also what
    // makes `\gen` reachable when `\general` exists.
    if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
      const ctx = getContext();
      if (!ctx) return;
      const tok = findToken(ctx.before);
      if (!tok || !tok.token) return;
      const snip = exactMatch(tok.token);
      if (!snip) return;
      e.preventDefault();
      e.stopPropagation();
      runExpand(ctx, tok, snip, 0);
    }
  }

  document.addEventListener('input',   onInput,   true);
  document.addEventListener('keydown', onKeyDown, true);

  document.addEventListener('compositionstart', () => { composing = true;  }, true);
  document.addEventListener('compositionend',   () => { composing = false; }, true);

  document.addEventListener('focusout', () => {
    if (!sugOpen) return;
    setTimeout(() => { if (!getContext()) closeSuggest(); }, 0);
  }, true);

  document.addEventListener('mousedown', (e) => {
    // Clicks inside our own shadow DOM are retargeted to the host, so this
    // check reliably means "clicked somewhere else on the page".
    if (sugOpen && e.target !== sugHost) closeSuggest();
  }, true);

  window.addEventListener('scroll', () => {
    if (!sugOpen) return;
    const ctx = getContext();
    if (ctx) placeSuggest(ctx); else closeSuggest();
  }, true);

  window.addEventListener('resize', closeSuggest, true);
  window.addEventListener('blur',   closeSuggest);

  // Everything is defined now, so it's safe to pull state out of storage.
  readAll();

})();
