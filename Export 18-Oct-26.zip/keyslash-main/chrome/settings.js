'use strict';

// ── KeySlash — snippet manager ───────────────────────────────────────────────

const STORE_SNIPPETS = 'bteSnippets';
const STORE_SETTINGS = 'bteSettings';
const STORE_THEME    = 'bteTheme';

const DEFAULT_SETTINGS = {
  enabled:       true,
  prefix:        '\\',
  mode:          'instant',
  caseSensitive: false,
  suggestions:   true,
  sugMin:        1,
  excluded:      []
};

const TOKENS = ['{date}', '{time}', '{datetime}', '{iso}', '{weekday}',
                '{day}', '{month}', '{year}', '{uuid}', '{cursor}'];

// ── State ─────────────────────────────────────────────────────────────────────
let snippets    = [];
let settings    = Object.assign({}, DEFAULT_SETTINGS);
let activeId    = null;
let selectedIds = new Set();
let sortMode    = 'order';   // 'order' | 'name' | 'date' | 'uses'
let editorRefs  = null;      // live inputs of the currently built editor

// ── DOM refs ──────────────────────────────────────────────────────────────────
const btnTheme          = document.getElementById('btnTheme');
const btnImport         = document.getElementById('btnImport');
const btnExport         = document.getElementById('btnExport');
const btnPrefs          = document.getElementById('btnPrefs');
const btnSites          = document.getElementById('btnSites');
const btnSortOrder      = document.getElementById('btnSortOrder');
const btnSortName       = document.getElementById('btnSortName');
const btnSortDate       = document.getElementById('btnSortDate');
const btnSortUses       = document.getElementById('btnSortUses');
const btnSupport        = document.getElementById('btnSupport');
const btnClearAll       = document.getElementById('btnClearAll');
const btnNew            = document.getElementById('btnNew');

const offBanner         = document.getElementById('offBanner');
const btnTurnOn         = document.getElementById('btnTurnOn');
const welcomeBanner     = document.getElementById('welcomeBanner');
const btnWelcomeX       = document.getElementById('btnWelcomeX');

const leftPanel         = document.getElementById('leftPanel');
const resizeHandle      = document.getElementById('resizeHandle');
const searchInput       = document.getElementById('searchInput');
const bulkBar           = document.getElementById('bulkBar');
const bulkCount         = document.getElementById('bulkCount');
const btnSelectAll      = document.getElementById('btnSelectAll');
const btnExportSelected = document.getElementById('btnExportSelected');
const btnDeleteSelected = document.getElementById('btnDeleteSelected');
const snipList          = document.getElementById('snipList');
const rightPanel        = document.getElementById('rightPanel');
const snipCountEl       = document.getElementById('snipCount');
const statusHint        = document.getElementById('statusHint');

const prefsOverlay      = document.getElementById('prefsOverlay');
const btnPrefsX         = document.getElementById('btnPrefsX');
const btnPrefsDone      = document.getElementById('btnPrefsDone');
const btnResetPrefs     = document.getElementById('btnResetPrefs');
const chkEnabled        = document.getElementById('chkEnabled');
const inpPrefix         = document.getElementById('inpPrefix');
const selMode           = document.getElementById('selMode');
const selSugMin         = document.getElementById('selSugMin');
const chkSuggestions    = document.getElementById('chkSuggestions');
const chkCase           = document.getElementById('chkCase');

const sitesOverlay      = document.getElementById('sitesOverlay');
const btnSitesX         = document.getElementById('btnSitesX');
const btnSitesDone      = document.getElementById('btnSitesDone');
const newSiteInput      = document.getElementById('newSiteInput');
const btnAddSite        = document.getElementById('btnAddSite');
const siteList          = document.getElementById('siteList');

const supportOverlay    = document.getElementById('supportOverlay');
const btnSupportX       = document.getElementById('btnSupportX');
const btnSupportDone    = document.getElementById('btnSupportDone');
const btnCopyUpi        = document.getElementById('btnCopyUpi');
const upiIdText         = document.getElementById('upiIdText');

const fullscreenOverlay = document.getElementById('fullscreenOverlay');
const fullscreenTitle   = document.getElementById('fullscreenTitle');
const fsTextarea        = document.getElementById('fsTextarea');
const btnFullscreenX    = document.getElementById('btnFullscreenX');
const btnFullscreenClose= document.getElementById('btnFullscreenClose');
const btnFullscreenSave = document.getElementById('btnFullscreenSave');

const importFile        = document.getElementById('importFile');
const toast             = document.getElementById('toast');

// ── Small helpers ─────────────────────────────────────────────────────────────
const prefix = () => settings.prefix || '\\';

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2400);
}

function newId() {
  return 'bte-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
}

function plural(n, word) {
  return n + ' ' + word + (n === 1 ? '' : 's');
}

function norm(s) {
  return settings.caseSensitive ? String(s) : String(s).toLowerCase();
}

// ── Theme ─────────────────────────────────────────────────────────────────────
function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  btnTheme.textContent = theme === 'dark' ? '☀️' : '🌙';
  btnTheme.title = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
}
btnTheme.addEventListener('click', () => {
  const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  chrome.storage.local.set({ [STORE_THEME]: next });
  applyTheme(next);
});

// ── Storage ───────────────────────────────────────────────────────────────────
function saveSnippets(cb) {
  chrome.storage.local.set({ [STORE_SNIPPETS]: snippets }, () => cb && cb());
}
function saveSettings(cb) {
  chrome.storage.local.set({ [STORE_SETTINGS]: settings }, () => cb && cb());
}

// ── Token rendering (mirrors content.js so the preview is honest) ─────────────
function pad2(n) { return String(n).padStart(2, '0'); }

function makeUuid() {
  try {
    if (crypto && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch (e) {}
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

function renderSnippet(raw) {
  const now = new Date();
  const map = {
    date:     now.toLocaleDateString(),
    time:     now.toLocaleTimeString(),
    datetime: now.toLocaleString(),
    iso:      now.getFullYear() + '-' + pad2(now.getMonth() + 1) + '-' + pad2(now.getDate()),
    day:      pad2(now.getDate()),
    month:    pad2(now.getMonth() + 1),
    year:     String(now.getFullYear()),
    weekday:  now.toLocaleDateString(undefined, { weekday: 'long' }),
    uuid:     makeUuid()
  };
  let out = String(raw == null ? '' : raw)
    .replace(/\{(date|time|datetime|iso|day|month|year|weekday|uuid)\}/gi,
             (_m, key) => map[key.toLowerCase()]);
  let cursor = -1;
  const hit = /\{cursor\}/i.exec(out);
  if (hit) {
    cursor = hit.index;
    out    = out.slice(0, hit.index) + out.slice(hit.index + hit[0].length);
    out    = out.replace(/\{cursor\}/gi, '');
  }
  return { text: out, cursor: cursor };
}

// ── Status bar / banners ──────────────────────────────────────────────────────
const MODE_TEXT = {
  instant: 'expands as soon as the shortcut is complete',
  space:   'expands after you press Space or Enter',
  tab:     'expands when you press Tab'
};

function updateStatus() {
  snipCountEl.textContent = plural(snippets.length, 'snippet');
  statusHint.textContent  = 'Type ' + prefix() + 'shortcut in any text field \u00b7 ' +
                            (MODE_TEXT[settings.mode] || MODE_TEXT.instant) +
                            ' \u00b7 Alt+Shift+E opens this page';
}

function updateOffBanner() {
  offBanner.classList.toggle('visible', settings.enabled === false);
}

// ── Sorting ───────────────────────────────────────────────────────────────────
function setSortMode(mode) {
  sortMode = mode;
  [btnSortOrder, btnSortName, btnSortDate, btnSortUses].forEach(b => b.classList.remove('active-sort'));
  const map = { order: btnSortOrder, name: btnSortName, date: btnSortDate, uses: btnSortUses };
  (map[mode] || btnSortOrder).classList.add('active-sort');
  renderList();
}
btnSortOrder.addEventListener('click', () => setSortMode('order'));
btnSortName.addEventListener('click',  () => setSortMode('name'));
btnSortDate.addEventListener('click',  () => setSortMode('date'));
btnSortUses.addEventListener('click',  () => setSortMode('uses'));

function sortedSnippets(list) {
  return list.slice().sort((a, b) => {
    const an = String(a.shortcut || '');
    const bn = String(b.shortcut || '');
    if (sortMode === 'name') return an.localeCompare(bn, undefined, { sensitivity: 'base' });
    if (sortMode === 'date') return (a.createdAt || 0) - (b.createdAt || 0);
    if (sortMode === 'uses') {
      const d = (b.uses || 0) - (a.uses || 0);
      if (d) return d;
      return an.localeCompare(bn, undefined, { sensitivity: 'base' });
    }
    // 'order': numbered snippets first, ascending; then the rest alphabetically
    const aHas = a.order != null && a.order !== '';
    const bHas = b.order != null && b.order !== '';
    if (aHas && bHas) return a.order - b.order;
    if (aHas) return -1;
    if (bHas) return 1;
    return an.localeCompare(bn, undefined, { sensitivity: 'base' });
  });
}

// ── Bulk bar ──────────────────────────────────────────────────────────────────
function updateBulkBar() {
  const n = selectedIds.size;
  bulkBar.classList.toggle('visible', n > 0);
  if (!n) return;
  bulkCount.textContent = n + ' selected';
  btnSelectAll.textContent = (n === snippets.length && n > 0) ? 'Deselect All' : 'Select All';
}

// ── Snippet list ──────────────────────────────────────────────────────────────
function oneLine(text) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  return s.length > 90 ? s.slice(0, 90) + '\u2026' : s;
}

function renderList() {
  const filter   = searchInput.value.trim().toLowerCase();
  const filtered = sortedSnippets(snippets.filter((s) => {
    if (!filter) return true;
    return String(s.shortcut || '').toLowerCase().includes(filter) ||
           String(s.label    || '').toLowerCase().includes(filter) ||
           String(s.text     || '').toLowerCase().includes(filter);
  }));

  updateStatus();
  snipList.innerHTML = '';

  if (!filtered.length) {
    const el = document.createElement('div');
    el.className = 'empty-list';
    if (!snippets.length) {
      el.innerHTML = 'No snippets yet.<br>Click <strong>+ New Snippet</strong>';
    } else {
      el.append('No results for \u201c', searchInput.value.trim(), '\u201d');
    }
    snipList.appendChild(el);
    updateBulkBar();
    return;
  }

  filtered.forEach((snip) => {
    const item = document.createElement('div');
    item.className = 'snip-item' + (snip.id === activeId ? ' active' : '');
    item.dataset.id = snip.id;

    const checkWrap = document.createElement('label');
    checkWrap.className = 'snip-item-check' + (selectedIds.has(snip.id) ? ' checked' : '');
    checkWrap.title = 'Select for bulk export or delete';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = selectedIds.has(snip.id);
    cb.addEventListener('change', (e) => {
      e.stopPropagation();
      if (cb.checked) { selectedIds.add(snip.id);    checkWrap.classList.add('checked'); }
      else            { selectedIds.delete(snip.id); checkWrap.classList.remove('checked'); }
      updateBulkBar();
    });
    checkWrap.appendChild(cb);
    checkWrap.addEventListener('click', (e) => e.stopPropagation());

    const body = document.createElement('div');
    body.className = 'snip-item-body';
    const nameEl = document.createElement('div');
    nameEl.className = 'snip-item-name';
    nameEl.textContent = prefix() + snip.shortcut;
    const hintEl = document.createElement('div');
    hintEl.className = 'snip-item-hint';
    hintEl.textContent = snip.label ? snip.label : (oneLine(snip.text) || '\u2014');
    body.append(nameEl, hintEl);
    body.addEventListener('click', () => selectSnippet(snip.id));

    item.append(checkWrap, body);
    snipList.appendChild(item);
  });

  updateBulkBar();
}

// ── Editor ────────────────────────────────────────────────────────────────────
function showEmptyState() {
  activeId   = null;
  editorRefs = null;
  rightPanel.className = 'right-panel empty-state';
  rightPanel.innerHTML =
    '<div class="empty-icon">⚡</div>' +
    '<div class="empty-text">Select a snippet to edit<br>or click <strong>+ New Snippet</strong></div>';
}

function selectSnippet(id) {
  activeId = id;
  const snip = snippets.find(s => s.id === id);
  if (snip) buildEditor(snip); else showEmptyState();
  renderList();
}

function makeMiniBtn(label, title) {
  const b = document.createElement('button');
  b.className   = 'btn btn-secondary btn-icon';
  b.textContent = label;
  b.title       = title;
  b.type        = 'button';
  return b;
}

function buildEditor(snip) {
  rightPanel.className = 'right-panel';
  rightPanel.innerHTML = '';

  // ── Shortcut / label / order ───────────────────────────────────────────────
  const fieldRow = document.createElement('div');
  fieldRow.className = 'field-row';

  const scGroup = document.createElement('div');
  scGroup.className = 'field-group';
  scGroup.style.maxWidth = '230px';
  const scLbl = document.createElement('div');
  scLbl.className = 'field-label';
  scLbl.textContent = 'Shortcut';
  const addon = document.createElement('div');
  addon.className = 'addon';
  const addonPre = document.createElement('span');
  addonPre.className = 'addon-pre';
  addonPre.textContent = prefix();
  const scInput = document.createElement('input');
  scInput.className   = 'field-input mono';
  scInput.value       = snip ? String(snip.shortcut || '') : '';
  scInput.placeholder = 'gen';
  scInput.spellcheck  = false;
  addon.append(addonPre, scInput);
  const scHint = document.createElement('div');
  scHint.className = 'field-hint';
  scHint.textContent = 'No spaces. Typing ' + prefix() + 'gen inserts the text below.';
  scGroup.append(scLbl, addon, scHint);

  const labelGroup = document.createElement('div');
  labelGroup.className = 'field-group';
  const labelLbl = document.createElement('div');
  labelLbl.className = 'field-label';
  labelLbl.textContent = 'Label';
  const labelInput = document.createElement('input');
  labelInput.className   = 'field-input';
  labelInput.value       = snip ? String(snip.label || '') : '';
  labelInput.placeholder = 'Short description — shown in the dropdown';
  const labelHint = document.createElement('div');
  labelHint.className = 'field-hint';
  labelHint.textContent = 'Optional, but makes long lists much easier to search.';
  labelGroup.append(labelLbl, labelInput, labelHint);

  const orderGroup = document.createElement('div');
  orderGroup.className = 'field-group';
  orderGroup.style.maxWidth = '95px';
  const orderLbl = document.createElement('div');
  orderLbl.className = 'field-label';
  orderLbl.textContent = 'Order';
  const orderInput = document.createElement('input');
  orderInput.className   = 'field-input';
  orderInput.type        = 'number';
  orderInput.min         = '0';
  orderInput.step        = '1';
  orderInput.value       = snip && snip.order != null ? snip.order : '';
  orderInput.placeholder = '10';
  orderInput.title       = 'Lower numbers appear first in the dropdown. Leave blank to sort alphabetically.';
  orderGroup.append(orderLbl, orderInput);

  fieldRow.append(scGroup, labelGroup, orderGroup);

  // ── Expansion text ────────────────────────────────────────────────────────
  const textSection = document.createElement('div');
  textSection.className = 'text-section';

  const labelRow = document.createElement('div');
  labelRow.className = 'text-label-row';
  const textLbl = document.createElement('div');
  textLbl.className = 'field-label';
  textLbl.textContent = 'Expanded text';

  const actions = document.createElement('div');
  actions.className = 'text-actions';
  const previewBtn = makeMiniBtn('👁 Preview', 'Show what this will actually insert');
  const copyBtn    = makeMiniBtn('📋 Copy',    'Copy the text to the clipboard');
  const clearBtn   = makeMiniBtn('✕ Clear',    'Clear the text');
  const dupeBtn    = makeMiniBtn('⧉ Dupe',     'Duplicate this snippet');
  const maxBtn     = makeMiniBtn('⤢ Expand',   'Open the fullscreen editor');
  actions.append(previewBtn, copyBtn, clearBtn);
  if (snip) actions.appendChild(dupeBtn);
  actions.appendChild(maxBtn);
  labelRow.append(textLbl, actions);

  const tokenBar = document.createElement('div');
  tokenBar.className = 'token-bar';
  const tokenBarLbl = document.createElement('span');
  tokenBarLbl.className = 'token-bar-label';
  tokenBarLbl.textContent = 'Insert:';
  tokenBar.appendChild(tokenBarLbl);

  const textArea = document.createElement('textarea');
  textArea.className   = 'text-area';
  textArea.spellcheck  = true;
  textArea.value       = snip ? String(snip.text || '') : '';
  textArea.placeholder = 'General Text for testing purpose';

  TOKENS.forEach((tok) => {
    const chip = document.createElement('button');
    chip.type      = 'button';
    chip.className = 'token-chip';
    chip.textContent = tok;
    chip.title = tok === '{cursor}'
      ? 'Where the cursor lands after expanding'
      : 'Replaced with the live value when the snippet expands';
    chip.addEventListener('click', () => {
      const start = textArea.selectionStart != null ? textArea.selectionStart : textArea.value.length;
      const end   = textArea.selectionEnd   != null ? textArea.selectionEnd   : start;
      textArea.value = textArea.value.slice(0, start) + tok + textArea.value.slice(end);
      const caret = start + tok.length;
      textArea.focus();
      textArea.setSelectionRange(caret, caret);
      refreshPreview();
    });
    tokenBar.appendChild(chip);
  });

  textSection.append(labelRow, tokenBar, textArea);

  // ── Preview ───────────────────────────────────────────────────────────────
  const previewWrap = document.createElement('div');
  previewWrap.className = 'preview-wrap';
  const previewLbl = document.createElement('div');
  previewLbl.className = 'field-label';
  previewLbl.textContent = 'Preview — exactly what gets inserted';
  const previewBox = document.createElement('div');
  previewBox.className = 'preview-box';
  previewWrap.append(previewLbl, previewBox);

  function refreshPreview() {
    if (!previewWrap.classList.contains('visible')) return;
    const out = renderSnippet(textArea.value);
    previewBox.textContent = '';
    if (out.cursor >= 0) {
      previewBox.append(document.createTextNode(out.text.slice(0, out.cursor)));
      const caret = document.createElement('span');
      caret.className = 'preview-caret';
      previewBox.appendChild(caret);
      previewBox.append(document.createTextNode(out.text.slice(out.cursor)));
    } else {
      previewBox.textContent = out.text;
    }
    if (!out.text) previewBox.textContent = '(nothing — the text is empty)';
  }

  previewBtn.addEventListener('click', () => {
    const on = previewWrap.classList.toggle('visible');
    previewBtn.textContent = on ? '👁 Hide preview' : '👁 Preview';
    refreshPreview();
  });
  textArea.addEventListener('input', refreshPreview);

  // ── Action bar ────────────────────────────────────────────────────────────
  const actionBar = document.createElement('div');
  actionBar.className = 'action-bar';
  const actionLeft  = document.createElement('div');
  actionLeft.className = 'action-left';
  const actionRight = document.createElement('div');
  actionRight.className = 'action-right';

  if (snip) {
    const delBtn = document.createElement('button');
    delBtn.className = 'btn btn-danger';
    delBtn.type = 'button';
    delBtn.textContent = '🗑 Delete';
    delBtn.addEventListener('click', () => {
      if (!confirm('Delete "' + prefix() + snip.shortcut + '"?')) return;
      snippets = snippets.filter(s => s.id !== snip.id);
      selectedIds.delete(snip.id);
      saveSnippets(() => { showToast('🗑 Deleted'); showEmptyState(); renderList(); });
    });
    actionLeft.appendChild(delBtn);

    const meta = document.createElement('span');
    meta.className = 'meta-note';
    const bits = [];
    bits.push('used ' + plural(snip.uses || 0, 'time'));
    if (snip.createdAt) bits.push('created ' + new Date(snip.createdAt).toLocaleDateString());
    if (snip.updatedAt) bits.push('edited '  + new Date(snip.updatedAt).toLocaleDateString());
    meta.textContent = bits.join(' \u00b7 ');
    actionLeft.appendChild(meta);
  }

  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn btn-primary';
  saveBtn.type = 'button';
  saveBtn.textContent = snip ? '💾 Save Snippet' : '💾 Create Snippet';
  actionRight.appendChild(saveBtn);
  actionBar.append(actionLeft, actionRight);

  rightPanel.append(fieldRow, textSection, previewWrap, actionBar);

  editorRefs = { scInput, labelInput, orderInput, textArea, addon, refreshPreview };

  if (!snip) setTimeout(() => scInput.focus(), 40);

  // ── Copy / Clear / Dupe / Expand ──────────────────────────────────────────
  copyBtn.addEventListener('click', () => {
    if (!textArea.value.trim()) { showToast('⚠️ Nothing to copy!'); return; }
    navigator.clipboard.writeText(textArea.value)
      .then(()  => showToast('📋 Copied!'))
      .catch(() => showToast('❌ Could not copy — select the text manually'));
  });

  clearBtn.addEventListener('click', () => {
    if (!textArea.value) return;
    if (!confirm('Clear the expanded text?')) return;
    textArea.value = '';
    textArea.focus();
    refreshPreview();
    showToast('✕ Text cleared');
  });

  dupeBtn.addEventListener('click', () => {
    if (!snip) return;
    const base = (scInput.value.trim() || snip.shortcut).replace(/\s+/g, '');
    let name = base + '2', n = 2;
    while (snippets.some(s => norm(s.shortcut) === norm(name))) name = base + (++n);
    const copy = {
      id:        newId(),
      shortcut:  name,
      label:     labelInput.value.trim(),
      text:      textArea.value,
      order:     orderInput.value.trim() !== '' ? parseInt(orderInput.value, 10) : null,
      createdAt: Date.now(),
      uses:      0
    };
    snippets.push(copy);
    activeId = copy.id;
    saveSnippets(() => {
      showToast('⧉ Duplicated — rename it and save');
      renderList();
      buildEditor(copy);
      setTimeout(() => {
        if (editorRefs) { editorRefs.scInput.focus(); editorRefs.scInput.select(); }
      }, 60);
    });
  });

  maxBtn.addEventListener('click', () => {
    fullscreenTitle.textContent = prefix() + (scInput.value.trim() || 'shortcut');
    fsTextarea.value = textArea.value;
    fullscreenOverlay.classList.add('visible');
    setTimeout(() => fsTextarea.focus(), 40);
  });

  // ── Save ──────────────────────────────────────────────────────────────────
  saveBtn.addEventListener('click', () => {
    // Be forgiving: strip a leading trigger char if the user typed "\gen".
    let shortcut = scInput.value.trim();
    const p = prefix();
    while (shortcut.startsWith(p)) shortcut = shortcut.slice(p.length);
    shortcut = shortcut.trim();

    const label    = labelInput.value.trim();
    const text     = textArea.value;
    const orderRaw = orderInput.value.trim();
    const order    = orderRaw !== '' ? parseInt(orderRaw, 10) : null;

    addon.classList.remove('error');
    textArea.classList.remove('error');

    if (!shortcut) {
      addon.classList.add('error'); scInput.focus();
      showToast('⚠️ Give the snippet a shortcut');
      return;
    }
    if (/\s/.test(shortcut)) {
      addon.classList.add('error'); scInput.focus();
      showToast('⚠️ Shortcuts can\u2019t contain spaces');
      return;
    }
    if (!text.trim()) {
      textArea.classList.add('error'); textArea.focus();
      showToast('⚠️ Add the text it should expand into');
      return;
    }
    const clash = snippets.find(s => s.id !== activeId && norm(s.shortcut) === norm(shortcut));
    if (clash) {
      addon.classList.add('error'); scInput.focus();
      showToast('⚠️ ' + p + shortcut + ' is already taken');
      return;
    }

    if (activeId) {
      const idx = snippets.findIndex(s => s.id === activeId);
      if (idx !== -1) {
        snippets[idx] = Object.assign({}, snippets[idx],
          { shortcut, label, text, order, updatedAt: Date.now() });
      }
    } else {
      const created = {
        id: newId(), shortcut, label, text, order,
        createdAt: Date.now(), uses: 0
      };
      snippets.push(created);
      activeId = created.id;
    }

    saveSnippets(() => {
      showToast('✅ Saved — try ' + p + shortcut + ' on any page');
      renderList();
      const fresh = snippets.find(s => s.id === activeId);
      if (fresh) buildEditor(fresh);
    });
  });
}

btnNew.addEventListener('click', () => {
  activeId = null;
  buildEditor(null);
  renderList();
});

searchInput.addEventListener('input', renderList);

// ── Fullscreen editor ─────────────────────────────────────────────────────────
function closeFullscreen() { fullscreenOverlay.classList.remove('visible'); }

btnFullscreenX.addEventListener('click', closeFullscreen);
btnFullscreenClose.addEventListener('click', closeFullscreen);
btnFullscreenSave.addEventListener('click', () => {
  if (editorRefs) {
    editorRefs.textArea.value = fsTextarea.value;
    editorRefs.refreshPreview();
  }
  closeFullscreen();
  showToast('📋 Text updated — click Save to keep it');
});

// ── Export ────────────────────────────────────────────────────────────────────
function exportPayload(list) {
  return {
    app:        'keyslash',
    version:    1,
    exportedAt: new Date().toISOString(),
    prefix:     prefix(),
    snippets:   list.map(s => ({
      shortcut: s.shortcut,
      label:    s.label || '',
      text:     s.text || '',
      order:    s.order != null ? s.order : null
    }))
  };
}

function downloadJSON(payload, filename) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function stamp() {
  const d = new Date();
  return d.getFullYear() + pad2(d.getMonth() + 1) + pad2(d.getDate());
}

btnExport.addEventListener('click', () => {
  if (!snippets.length) { showToast('⚠️ No snippets to export!'); return; }
  downloadJSON(exportPayload(snippets), 'keyslash-snippets-all-' + stamp() + '.json');
  showToast('⬇ Exported ' + plural(snippets.length, 'snippet'));
});

btnExportSelected.addEventListener('click', () => {
  const chosen = snippets.filter(s => selectedIds.has(s.id));
  if (!chosen.length) { showToast('⚠️ Nothing selected!'); return; }
  downloadJSON(exportPayload(chosen), 'keyslash-snippets-selected-' + stamp() + '.json');
  showToast('⬇ Exported ' + plural(chosen.length, 'snippet'));
});

// ── Import ────────────────────────────────────────────────────────────────────
// Accepts our own export format, a bare array, and the common field names used
// by other expanders, so people can migrate without hand-editing JSON.
function normaliseImported(raw) {
  const shortcut = raw.shortcut || raw.trigger || raw.abbreviation || raw.name || raw.key || '';
  const text     = raw.text != null ? raw.text
                 : raw.expansion != null ? raw.expansion
                 : raw.value != null ? raw.value
                 : raw.body != null ? raw.body
                 : raw.snippet != null ? raw.snippet : '';
  const label    = raw.label || raw.hint || raw.description || raw.title || '';

  let sc = String(shortcut).trim();
  const p = prefix();
  while (sc.startsWith(p)) sc = sc.slice(p.length);
  sc = sc.replace(/\s+/g, '');

  return {
    shortcut: sc,
    label:    String(label).trim(),
    text:     String(text),
    order:    raw.order != null && raw.order !== '' ? parseInt(raw.order, 10) : null
  };
}

btnImport.addEventListener('click', () => importFile.click());

importFile.addEventListener('change', (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const reader = new FileReader();

  reader.onload = (ev) => {
    try {
      const data = JSON.parse(ev.target.result);
      const rawList = Array.isArray(data) ? data
                    : Array.isArray(data.snippets) ? data.snippets
                    : Array.isArray(data.commands) ? data.commands
                    : Array.isArray(data.items) ? data.items : null;
      if (!rawList) throw new Error('unrecognised file format');

      const valid = rawList
        .filter(x => x && typeof x === 'object')
        .map(normaliseImported)
        .filter(x => x.shortcut && x.text !== '');
      if (!valid.length) throw new Error('no usable snippets found');

      const merge = confirm(
        'Import ' + plural(valid.length, 'snippet') + '?\n\n' +
        'OK\u2003= Merge with what you already have (same shortcut gets replaced)\n' +
        'Cancel\u2003= Replace your whole library'
      );

      if (merge) {
        let added = 0, replaced = 0;
        valid.forEach((item) => {
          const idx = snippets.findIndex(s => norm(s.shortcut) === norm(item.shortcut));
          if (idx !== -1) {
            snippets[idx] = Object.assign({}, snippets[idx], item, {
              id:        snippets[idx].id,
              createdAt: snippets[idx].createdAt,
              uses:      snippets[idx].uses || 0,
              updatedAt: Date.now()
            });
            replaced++;
          } else {
            snippets.push(Object.assign({}, item, {
              id: newId(), createdAt: Date.now(), uses: 0
            }));
            added++;
          }
        });
        saveSnippets(() => {
          const parts = [];
          if (added)    parts.push(added + ' added');
          if (replaced) parts.push(replaced + ' replaced');
          showToast('⬆ Merged \u2014 ' + (parts.join(', ') || 'no changes'));
          renderList();
        });
      } else {
        snippets = valid.map(item => Object.assign({}, item, {
          id: newId(), createdAt: Date.now(), uses: 0
        }));
        selectedIds.clear();
        activeId = null;
        saveSnippets(() => {
          showToast('⬆ Library replaced with ' + plural(snippets.length, 'snippet'));
          showEmptyState();
          renderList();
        });
      }
    } catch (err) {
      showToast('❌ Import failed: ' + err.message);
    }
    importFile.value = '';
  };

  reader.onerror = () => { showToast('❌ Could not read that file'); importFile.value = ''; };
  reader.readAsText(file);
});

// ── Clear all / bulk actions ──────────────────────────────────────────────────
btnClearAll.addEventListener('click', () => {
  if (!snippets.length) { showToast('⚠️ Nothing to clear!'); return; }
  if (!confirm('Delete ALL ' + plural(snippets.length, 'snippet') + '?\n\nThis cannot be undone. Export first if you want a backup.')) return;
  snippets = [];
  selectedIds.clear();
  saveSnippets(() => { showToast('🗑 All cleared'); showEmptyState(); renderList(); });
});

btnSelectAll.addEventListener('click', () => {
  if (selectedIds.size === snippets.length) selectedIds.clear();
  else snippets.forEach(s => selectedIds.add(s.id));
  renderList();
});

btnDeleteSelected.addEventListener('click', () => {
  const n = selectedIds.size;
  if (!n) return;
  if (!confirm('Delete ' + plural(n, 'selected snippet') + '?\n\nThis cannot be undone.')) return;
  const hitActive = selectedIds.has(activeId);
  snippets = snippets.filter(s => !selectedIds.has(s.id));
  selectedIds.clear();
  if (hitActive) showEmptyState();
  saveSnippets(() => { showToast('🗑 Deleted ' + plural(n, 'snippet')); renderList(); });
});

// ── Preferences ───────────────────────────────────────────────────────────────
function fillPrefs() {
  chkEnabled.checked     = settings.enabled !== false;
  inpPrefix.value        = prefix();
  selMode.value          = settings.mode || 'instant';
  selSugMin.value        = String(settings.sugMin != null ? settings.sugMin : 1);
  chkSuggestions.checked = settings.suggestions !== false;
  chkCase.checked        = !!settings.caseSensitive;
}

// The trigger character is baked into the list, the editor label and the status
// bar, so re-render everything that shows it.
function afterSettingsChange(rebuildEditor) {
  updateStatus();
  updateOffBanner();
  renderList();
  if (rebuildEditor) {
    const snip = snippets.find(s => s.id === activeId);
    if (activeId && snip) buildEditor(snip);
    else if (!activeId && editorRefs) buildEditor(null);
  }
}

function commitPrefs(rebuildEditor) {
  saveSettings(() => afterSettingsChange(rebuildEditor));
}

chkEnabled.addEventListener('change', () => {
  settings.enabled = chkEnabled.checked;
  commitPrefs(false);
  showToast(settings.enabled ? '✅ Expansion on' : '⏸ Expansion off');
});

inpPrefix.addEventListener('change', () => {
  const next = inpPrefix.value.trim();
  if (!next) { inpPrefix.value = prefix(); showToast('⚠️ Pick a trigger character'); return; }
  if (/\s/.test(next)) { inpPrefix.value = prefix(); showToast('⚠️ It can\u2019t be a space'); return; }
  if (/[a-z0-9]/i.test(next)) {
    inpPrefix.value = prefix();
    showToast('⚠️ Use a symbol, not a letter or number');
    return;
  }
  settings.prefix = next;
  commitPrefs(true);
  showToast('✅ Trigger is now ' + next);
});

selMode.addEventListener('change', () => {
  settings.mode = selMode.value;
  commitPrefs(false);
  showToast('✅ ' + (MODE_TEXT[settings.mode] || '').replace(/^expands/, 'Now expands'));
});

selSugMin.addEventListener('change', () => {
  settings.sugMin = parseInt(selSugMin.value, 10) || 0;
  commitPrefs(false);
});

chkSuggestions.addEventListener('change', () => {
  settings.suggestions = chkSuggestions.checked;
  commitPrefs(false);
});

chkCase.addEventListener('change', () => {
  settings.caseSensitive = chkCase.checked;
  commitPrefs(false);
});

btnResetPrefs.addEventListener('click', () => {
  if (!confirm('Reset all preferences to their defaults?\n\nYour snippets are not touched.')) return;
  const keepExcluded = settings.excluded || [];
  settings = Object.assign({}, DEFAULT_SETTINGS, { excluded: keepExcluded });
  fillPrefs();
  commitPrefs(true);
  showToast('↺ Preferences reset');
});

btnTurnOn.addEventListener('click', () => {
  settings.enabled = true;
  fillPrefs();
  commitPrefs(false);
  showToast('✅ Expansion on');
});

// ── Disabled sites ────────────────────────────────────────────────────────────
function cleanHost(raw) {
  let h = String(raw || '').trim();
  if (!h) return '';
  h = h.replace(/^[a-z]+:\/\//i, '');  // strip protocol if a full URL was pasted
  h = h.split('/')[0];                 // strip any path
  h = h.split('?')[0];
  h = h.split(':')[0];                 // strip any port
  h = h.replace(/^\*\./, '').replace(/^www\./i, '');
  return h.toLowerCase();
}

function renderSiteList() {
  const list = settings.excluded || [];
  siteList.innerHTML = '';
  if (!list.length) {
    const el = document.createElement('div');
    el.className = 'modal-empty';
    el.textContent = 'No sites excluded — expansion works everywhere.';
    siteList.appendChild(el);
    return;
  }
  list.forEach((host) => {
    const row = document.createElement('div');
    row.className = 'site-item';
    const label = document.createElement('span');
    label.textContent = host;
    const rm = document.createElement('button');
    rm.className = 'btn btn-danger';
    rm.type = 'button';
    rm.textContent = 'Remove';
    rm.addEventListener('click', () => {
      settings.excluded = (settings.excluded || []).filter(h => h !== host);
      saveSettings(() => { renderSiteList(); showToast('✅ Re-enabled on ' + host); });
    });
    row.append(label, rm);
    siteList.appendChild(row);
  });
}

btnAddSite.addEventListener('click', () => {
  const host = cleanHost(newSiteInput.value);
  if (!host || host.indexOf('.') === -1) { showToast('⚠️ Enter a hostname like example.com'); return; }
  settings.excluded = settings.excluded || [];
  if (settings.excluded.includes(host)) { showToast('⚠️ Already on the list'); return; }
  settings.excluded.push(host);
  saveSettings(() => {
    renderSiteList();
    newSiteInput.value = '';
    showToast('🚫 Expansion off on ' + host);
  });
});
newSiteInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') btnAddSite.click(); });

// ── Modal plumbing ────────────────────────────────────────────────────────────
function openModal(overlay) { overlay.classList.add('visible'); }
function closeModal(overlay) { overlay.classList.remove('visible'); }

btnPrefs.addEventListener('click', () => { fillPrefs(); openModal(prefsOverlay); });
btnPrefsX.addEventListener('click',    () => closeModal(prefsOverlay));
btnPrefsDone.addEventListener('click', () => closeModal(prefsOverlay));

btnSites.addEventListener('click', () => { renderSiteList(); openModal(sitesOverlay); });
btnSitesX.addEventListener('click',    () => closeModal(sitesOverlay));
btnSitesDone.addEventListener('click', () => closeModal(sitesOverlay));

btnSupport.addEventListener('click',     () => openModal(supportOverlay));
btnSupportX.addEventListener('click',    () => closeModal(supportOverlay));
btnSupportDone.addEventListener('click', () => closeModal(supportOverlay));

btnCopyUpi.addEventListener('click', () => {
  navigator.clipboard.writeText(upiIdText.textContent.trim())
    .then(()  => showToast('📋 UPI ID copied'))
    .catch(() => showToast('❌ Could not copy — select and copy manually'));
});

document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (fullscreenOverlay.classList.contains('visible')) { closeFullscreen(); return; }
  [supportOverlay, sitesOverlay, prefsOverlay].some((o) => {
    if (o.classList.contains('visible')) { closeModal(o); return true; }
    return false;
  });
});

btnWelcomeX.addEventListener('click', () => welcomeBanner.classList.remove('visible'));

// ── Resizable left panel ──────────────────────────────────────────────────────
(function initResize() {
  let startX = 0, startW = 0;
  resizeHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    startX = e.clientX;
    startW = leftPanel.offsetWidth;
    resizeHandle.classList.add('dragging');
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup',   onUp);
  });
  function onMove(e) {
    const next = Math.max(170, Math.min(520, startW + (e.clientX - startX)));
    leftPanel.style.width = next + 'px';
  }
  function onUp() {
    resizeHandle.classList.remove('dragging');
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup',   onUp);
  }
})();

// ── Live sync ─────────────────────────────────────────────────────────────────
// Usage counters are written by the service worker, and the popup can edit
// snippets too. Refresh the list without touching a half-finished edit.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[STORE_THEME]) {
    applyTheme(changes[STORE_THEME].newValue === 'light' ? 'light' : 'dark');
  }
  if (changes[STORE_SNIPPETS]) {
    const next = changes[STORE_SNIPPETS].newValue;
    snippets = Array.isArray(next) ? next : [];
    renderList();
  }
  if (changes[STORE_SETTINGS]) {
    settings = Object.assign({}, DEFAULT_SETTINGS, changes[STORE_SETTINGS].newValue || {});
    fillPrefs();
    renderSiteList();
    updateStatus();
    updateOffBanner();
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────
(function init() {
  const params = new URLSearchParams(location.search);

  chrome.storage.local.get([STORE_SNIPPETS, STORE_SETTINGS, STORE_THEME], (res) => {
    snippets = Array.isArray(res[STORE_SNIPPETS]) ? res[STORE_SNIPPETS] : [];
    settings = Object.assign({}, DEFAULT_SETTINGS, res[STORE_SETTINGS] || {});
    if (!settings.prefix) settings.prefix = DEFAULT_SETTINGS.prefix;

    applyTheme(res[STORE_THEME] === 'light' ? 'light' : 'dark');
    fillPrefs();
    renderSiteList();
    updateOffBanner();
    renderList();

    if (params.get('welcome') === '1')     welcomeBanner.classList.add('visible');
    if (params.get('openSupport') === '1') openModal(supportOverlay);
  });
})();
