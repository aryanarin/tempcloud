// Cloudflare Worker - AI Proxy for Aryan's Translator
// This worker holds your API key securely and forwards requests to the AI endpoint.
// Your frontend never sees the key.

// ---- CONFIGURATION ----
// These are set as Environment Variables in the Cloudflare Dashboard (not in code),
// so your API key never ends up in the repo or the browser.
// See the README for step-by-step deployment instructions.
//
//   env.API_KEY      = your AI provider API key        (store as a Secret)
//   env.API_ENDPOINT = your provider's chat-completions URL
//                      e.g. https://api.groq.com/openai/v1/chat/completions
//   env.API_MODEL    = the model to use
//                      e.g. llama-3.3-70b-versatile
//
// Any OpenAI-compatible provider works (Groq, OpenRouter, OpenAI, Mistral, ...).

export default {
  async fetch(request, env) {
    // Handle CORS preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: corsHeaders(),
      });
    }

    // Only allow POST requests
    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), {
        status: 405,
        headers: { ...corsHeaders(), "Content-Type": "application/json" },
      });
    }

    try {
      // Parse the incoming request body
      const body = await request.json();

      // Ensure the model is set (use env default if not provided)
      if (!body.model) {
        body.model = env.API_MODEL || "llama-3.3-70b-versatile";
      }

      // Forward to the real AI endpoint with the secret API key
      const apiResponse = await fetch(env.API_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${env.API_KEY}`,
        },
        body: JSON.stringify(body),
      });

      // Pass through the response
      const responseBody = await apiResponse.text();
      return new Response(responseBody, {
        status: apiResponse.status,
        headers: {
          ...corsHeaders(),
          "Content-Type": apiResponse.headers.get("Content-Type") || "application/json",
        },
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: "Proxy error: " + err.message }), {
        status: 500,
        headers: { ...corsHeaders(), "Content-Type": "application/json" },
      });
    }
  },
};

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  };
}
