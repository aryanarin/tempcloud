### Aryan's Translator - Local Network HTTP Server
### Usage: Run this script in PowerShell. Share the URL with colleagues.
### Stop: Press Ctrl+C in the terminal to stop the server.

$FilePath = "C:\Users\aryan.raj04\Documents\vscode\translator\index.html"
$Port = 8080

# Verify file exists
if (-not (Test-Path $FilePath)) {
    Write-Host "ERROR: File not found at $FilePath" -ForegroundColor Red
    exit 1
}

# Read file content
$FileBytes = [System.IO.File]::ReadAllBytes($FilePath)

# Get local IP
$LocalIP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notmatch 'Loopback' -and $_.IPAddress -notmatch '^127\.' -and $_.IPAddress -notmatch '^169\.' } | Select-Object -First 1).IPAddress

# Create TCP listener on all interfaces (no admin/urlacl needed)
$endpoint = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, $Port)
$tcpListener = New-Object System.Net.Sockets.TcpListener $endpoint

try {
    $tcpListener.Start()
} catch {
    Write-Host "ERROR: Could not bind to port $Port. Is it already in use?" -ForegroundColor Red
    Write-Host "Error: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "=== Aryan's Translator Server ===" -ForegroundColor Green
Write-Host ""
Write-Host "  Local:   http://localhost:$Port" -ForegroundColor Cyan
Write-Host "  Network: http://${LocalIP}:$Port" -ForegroundColor Cyan
Write-Host ""
Write-Host "Share the Network URL with your colleagues!" -ForegroundColor Yellow
Write-Host "Press Ctrl+C to stop the server." -ForegroundColor Gray
Write-Host ""

# Build HTTP response
$responseHeader = "HTTP/1.1 200 OK`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($FileBytes.Length)`r`nConnection: close`r`n`r`n"
$headerBytes = [System.Text.Encoding]::ASCII.GetBytes($responseHeader)

# Serve requests
try {
    while ($true) {
        $client = $tcpListener.AcceptTcpClient()
        $stream = $client.GetStream()

        # Read request (we don't need to parse it, just consume it)
        $buffer = New-Object byte[] 4096
        $stream.ReadTimeout = 2000
        try { $null = $stream.Read($buffer, 0, $buffer.Length) } catch {}

        # Send response
        $stream.Write($headerBytes, 0, $headerBytes.Length)
        $stream.Write($FileBytes, 0, $FileBytes.Length)
        $stream.Flush()
        $stream.Close()
        $client.Close()

        $clientIP = $client.Client.RemoteEndPoint
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] $clientIP -> 200 OK" -ForegroundColor DarkGray
    }
} finally {
    $tcpListener.Stop()
    Write-Host "Server stopped." -ForegroundColor Yellow
}
