# Aryan's Rephraser & Translator

A lightweight, single-file web app for translating and rephrasing text into multiple
languages at once, built for service-desk-style communications. AI requests are proxied
through a Cloudflare Worker, so your API key is never exposed to the browser.

Works with **any OpenAI-compatible AI provider**, including free ones like
[Groq](https://console.groq.com) (see [Using a free AI provider](#using-a-free-ai-provider)).

## Features

- **Multi-language output** - pick several target languages and translate to all of them in one run.
- **Two modes** - *Translate* (faithful translation with silent grammar fixes) and *Rephrase & Translate* (polishes email tone, then translates).
- **Automatic source-language detection** on paste.
- **Resolution-note template** handling for service desk tickets (fixed structure preserved per language).
- **Text expander** - type a `\shortcut` in the source box and it auto-expands (e.g. `\gen`, `\res`).
- **Reusable email / resolution templates** built in.
- **Light / dark theme**, persisted locally.
- **Keyboard shortcuts**: `Ctrl+Enter` = Translate, `Alt+Enter` = Rephrase.
- **Automatic retry** on rate limits (429), with sequential requests to stay within free-tier limits.
- State (source text, languages, outputs, expanders, theme) is saved in `localStorage`.

## Project structure

```
translator/
├── index.html            # The entire front-end app (HTML + CSS + JS)
├── cloudflare-worker.js   # AI proxy that holds the API key (deploy to Cloudflare)
├── serve-translator.ps1   # Optional: serve index.html over your local network (Windows)
├── LICENSE                # GNU GPL v3
└── README.md
```

## How it works

```
Browser (index.html)  ->  Cloudflare Worker (cloudflare-worker.js)  ->  AI provider API
```

The browser only knows the Worker URL. The Worker adds the `Authorization` header from a
Cloudflare environment variable and forwards the request, so the API key never reaches the
client. This is what makes it safe to host `index.html` publicly.

---

## What you need to replace

This repo ships with placeholders. Before the app will work, replace these **three** values.

### 1. `index.html` - line ~517: the access password

```js
const PASSWORD = '<your-password-here>';
```

Change it to whatever you want:

```js
const PASSWORD = 'my-team-password';
```

> **Security note:** this is a convenience gate, not real security. `index.html` is sent to
> the browser, so anyone can read the password in the page source (View Source / DevTools).
> Do not use a password you use elsewhere, and do not rely on this to protect sensitive
> data. If you need real protection, delete the login block and put the app behind
> [Cloudflare Access](https://developers.cloudflare.com/cloudflare-one/policies/access/)
> or similar.

### 2. `index.html` - line ~530: your Cloudflare Worker URL

```js
const AI_CONFIG = {
  endpoint: '<your-cloudflare-worker-url-here>',
  key: '',
  model: ''
};
```

Replace `endpoint` with the URL of the Worker you deploy in step 3 below:

```js
const AI_CONFIG = {
  endpoint: 'https://my-translator-proxy.my-subdomain.workers.dev/',
  key: '',    // leave empty - the Worker adds the real key
  model: ''   // leave empty - the Worker uses its API_MODEL variable
};
```

Leave `key` and `model` as empty strings. They exist as overrides but should stay empty so
secrets live only in Cloudflare.

### 3. Cloudflare Worker - three environment variables

Set these in the Cloudflare dashboard (not in code). Details in
[Setup step 1](#1-deploy-the-cloudflare-worker) below.

| Variable | Replace with |
| -------- | ------------ |
| `API_KEY` | Your AI provider's API key |
| `API_ENDPOINT` | Your provider's chat-completions URL |
| `API_MODEL` | The model name you want to use |

### Optional: `index.html` - line ~535: the email signature

The built-in email template has an organisation name baked in:

```js
const DEFAULT_EMAIL = `Hello ,\nGreetings!\n\nRegards,\nSupport Team`;
```

Change `Support Team` to your own team or company name. The
`DEFAULT_RESOLUTION` template on the next line is generic and can also be edited to match
your own wording.

### Optional: `serve-translator.ps1` - the file path

```powershell
$FilePath = "C:\Users\aryan.raj04\Documents\vscode\translator\index.html"
$Port = 8080
```

Point `$FilePath` at wherever you cloned the repo, and change `$Port` if 8080 is taken.

---

## Setup

### 1. Deploy the Cloudflare Worker

The Worker reads three environment variables:

| Variable       | Example                                        | Purpose                         |
| -------------- | ---------------------------------------------- | ------------------------------- |
| `API_KEY`      | `gsk_...`                                       | Your AI provider API key        |
| `API_ENDPOINT` | `https://api.groq.com/openai/v1/chat/completions` | OpenAI-compatible chat endpoint |
| `API_MODEL`    | `llama-3.3-70b-versatile`                       | Model to use (optional)         |

**Dashboard route:**
1. Log in to Cloudflare, go to **Workers & Pages** > **Create application** > **Create Worker**.
2. Give it a name (e.g. `translator-proxy`) and deploy the starter.
3. Click **Edit code**, replace everything with the contents of `cloudflare-worker.js`, then **Deploy**.
4. Go to the Worker's **Settings** > **Variables and Secrets**. Add `API_KEY` as a **Secret**, and `API_ENDPOINT` / `API_MODEL` as plain variables. Deploy again.
5. Copy the Worker URL (e.g. `https://translator-proxy.your-subdomain.workers.dev`) and paste it into `AI_CONFIG.endpoint` in `index.html`.

**CLI route (Wrangler):**
```bash
npm install -g wrangler
wrangler login
wrangler deploy cloudflare-worker.js --name translator-proxy
wrangler secret put API_KEY        # paste your key when prompted
wrangler secret put API_ENDPOINT
wrangler secret put API_MODEL
```

### 2. Point the front-end at your Worker

Edit `AI_CONFIG.endpoint` in `index.html` as described in
[What you need to replace](#2-indexhtml---line-530-your-cloudflare-worker-url).

### 3. Set your password

Edit `PASSWORD` in `index.html` as described
[above](#1-indexhtml---line-517-the-access-password).

---

## Using a free AI provider

The app sends a standard OpenAI-style chat-completions request, so **any provider that
speaks the OpenAI API format works** - Groq, OpenRouter, Together, Cerebras, Mistral,
OpenAI, or a self-hosted model. You only change the two Worker variables `API_ENDPOINT`
and `API_MODEL`.

The app already handles free-tier constraints: requests run one language at a time with a
2-second gap, and it retries automatically with backoff if the provider returns HTTP 429.

### Sample setup: Groq (free tier, no credit card)

[Groq](https://groq.com) runs open models on custom hardware and offers a genuinely free
tier with an OpenAI-compatible API. Content below is summarised from
[Groq's OpenAI compatibility docs](https://console.groq.com/docs/openai).

1. Sign up at [console.groq.com](https://console.groq.com).
2. Open **API Keys** and create a new key. Copy it (starts with `gsk_`).
3. In your Cloudflare Worker's **Settings** > **Variables and Secrets**, set:

   | Variable | Value |
   | -------- | ----- |
   | `API_KEY` | `gsk_your_key_here` |
   | `API_ENDPOINT` | `https://api.groq.com/openai/v1/chat/completions` |
   | `API_MODEL` | `llama-3.3-70b-versatile` |

4. Redeploy the Worker, then reload the app. That's it.

Browse current model names in the Groq console; `llama-3.3-70b-versatile` is a good
general-purpose default for translation work.

> Note: **Groq** (the inference provider used here) is a different company from **Grok**
> (xAI's chatbot). If you specifically want xAI's Grok models, use
> `https://api.x.ai/v1/chat/completions` with a model like `grok-2-latest` and an xAI API
> key. xAI is a paid service.

### Other providers

| Provider | `API_ENDPOINT` | Example `API_MODEL` |
| -------- | -------------- | ------------------- |
| Groq | `https://api.groq.com/openai/v1/chat/completions` | `llama-3.3-70b-versatile` |
| OpenRouter | `https://openrouter.ai/api/v1/chat/completions` | `meta-llama/llama-3.3-70b-instruct` |
| OpenAI | `https://api.openai.com/v1/chat/completions` | `gpt-4o-mini` |
| Mistral | `https://api.mistral.ai/v1/chat/completions` | `mistral-large-latest` |
| xAI (Grok) | `https://api.x.ai/v1/chat/completions` | `grok-2-latest` |

Check each provider's current free-tier terms and model list, as they change often.

---

## Usage

### Run it locally
Open `index.html` in your browser. No build step, no server, no dependencies.

### Share on your local network (Windows)
```powershell
.\serve-translator.ps1
```
Serves `index.html` on port 8080 and prints a `http://<your-ip>:8080` URL that colleagues
on the same network can open. Press `Ctrl+C` to stop.

### Host it publicly
`index.html` is fully static, so GitHub Pages, Cloudflare Pages, Netlify, or any static
host will do. AI calls still route through your Worker, so the key stays server-side.

### In the app
1. Enter your password to unlock.
2. Paste or type text in the source box - the source language is auto-detected.
3. Pick one or more target languages from the chips (add your own with **+ add**, reorder with the arrows, remove with **x**).
4. Click **Translate** or **Rephrase & Translate**, or press `Ctrl+Enter` / `Alt+Enter`.
5. Copy any result with its **Copy** button.

**Text expander:** click **Text Expander** in the top bar to manage shortcuts. Type a
shortcut like `\gen` in the source box and it expands instantly. Shortcuts must start with
a backslash.

## Troubleshooting

| Symptom | Fix |
| ------- | --- |
| "Endpoint not configured" | You didn't replace `AI_CONFIG.endpoint` in `index.html`. |
| `API 401` | `API_KEY` in the Worker is wrong, expired, or wasn't saved. |
| `API 404` | `API_ENDPOINT` is wrong - it must be the full chat-completions path, not just the base URL. |
| "Rate limit exceeded after 5 retries" | Free-tier quota hit. Wait a minute, or reduce the number of selected target languages. |
| "Invalid JSON from model" | The model ignored the JSON output instruction. Try a larger/more capable model. |
| Browser console CORS error | The Worker isn't deployed or the URL is wrong. The Worker supplies the CORS headers. |

## License

Licensed under the **GNU General Public License v3.0**. See [LICENSE](LICENSE).

Sources for provider setup details: [Groq OpenAI compatibility docs](https://console.groq.com/docs/openai),
[Groq API reference](https://console.groq.com/docs/api-reference). Content was rephrased for
compliance with licensing restrictions.
