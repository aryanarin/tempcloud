// SPDX-License-Identifier: GPL-3.0-or-later
// Shared constants and storage helpers (ES module).
// Used by the background service worker, popup and options page.
// The content script cannot import modules, so it asks the background for settings.

export const DEFAULTS = {
  enabled: true,
  language: 'en-US',
  // Groq retires models regularly. These are the defaults at the time of writing;
  // the options page can load the live model list from your account.
  checkModel: 'openai/gpt-oss-20b',
  rewriteModel: 'openai/gpt-oss-120b',
  targetLanguages: ['English', 'German'],
  translateTone: 'formal',
  bubbleEverywhere: false,
  categories: {
    spelling: true,
    grammar: true,
    punctuation: true,
    clarity: true,
    style: false
  },
  debounceMs: 900,
  showBadge: true,
  disabledSites: [],
  dictionary: []
};

export const CATEGORY_INFO = {
  spelling: 'Misspelled words and typos.',
  grammar: 'Grammar mistakes: agreement, tense, articles, prepositions, wrong word choice.',
  punctuation: 'Missing, extra, or misplaced punctuation and capitalization.',
  clarity: 'Awkward, wordy, or confusing phrasing, but only when a clearly better phrasing exists.',
  style: 'Tone and style polish (repetition, overly casual phrasing), only when clearly worthwhile.'
};

export const CATEGORY_IDS = Object.keys(CATEGORY_INFO);

export const LANGUAGES = [
  ['en-US', 'English (US)'],
  ['en-GB', 'English (UK)'],
  ['en-CA', 'English (Canada)'],
  ['en-AU', 'English (Australia)'],
  ['en-IN', 'English (India)'],
  ['auto', 'Auto-detect (any language)']
];

export const REWRITE_MODES = [
  { id: 'improve', label: 'Improve writing', prompt: 'Improve the writing: fix errors, tighten wording, and make it flow better while keeping the same meaning and voice.' },
  { id: 'fix', label: 'Fix grammar & spelling', prompt: 'Fix only spelling, grammar, and punctuation errors. Do not change wording or style otherwise.' },
  { id: 'shorten', label: 'Make shorter', prompt: 'Make the text noticeably shorter and more concise without losing key information.' },
  { id: 'expand', label: 'Make longer', prompt: 'Expand the text with a little more detail and context while keeping the same meaning and tone.' },
  { id: 'paraphrase', label: 'Paraphrase', prompt: 'Paraphrase the text using different wording while keeping the exact meaning.' },
  { id: 'formal', label: 'More formal', prompt: 'Rewrite the text in a formal, professional tone.' },
  { id: 'friendly', label: 'More friendly', prompt: 'Rewrite the text in a warm, friendly, approachable tone.' },
  { id: 'confident', label: 'More confident', prompt: 'Rewrite the text to sound confident and direct, removing hedging and filler.' }
];

function normalize(s) {
  const src = s && typeof s === 'object' ? s : {};
  return {
    ...DEFAULTS,
    ...src,
    categories: { ...DEFAULTS.categories, ...(src.categories || {}) },
    disabledSites: Array.isArray(src.disabledSites) ? src.disabledSites : [],
    dictionary: Array.isArray(src.dictionary) ? src.dictionary : [],
    targetLanguages: Array.isArray(src.targetLanguages)
      ? src.targetLanguages.filter((l) => typeof l === 'string' && l.trim()).slice(0, 12)
      : [...DEFAULTS.targetLanguages]
  };
}

export async function getSettings() {
  const { settings } = await chrome.storage.sync.get('settings');
  return normalize(settings);
}

export async function saveSettings(patch) {
  const cur = await getSettings();
  const next = normalize({
    ...cur,
    ...patch,
    categories: { ...cur.categories, ...(patch.categories || {}) }
  });
  await chrome.storage.sync.set({ settings: next });
  return next;
}

// The API key lives in local storage only (never synced to other devices).
export async function getApiKey() {
  const { apiKey } = await chrome.storage.local.get('apiKey');
  return typeof apiKey === 'string' ? apiKey.trim() : '';
}

export async function setApiKey(key) {
  await chrome.storage.local.set({ apiKey: String(key || '').trim() });
}

// Optional Cloudflare Worker (or any OpenAI-compatible proxy) that holds the real key.
// When set, requests go there instead of api.groq.com and no key is needed in the extension.
export async function getProxyUrl() {
  const { proxyUrl } = await chrome.storage.local.get('proxyUrl');
  return typeof proxyUrl === 'string' ? proxyUrl.trim() : '';
}

export async function setProxyUrl(url) {
  await chrome.storage.local.set({ proxyUrl: String(url || '').trim() });
}

// Languages offered under "More languages" and as suggestions in the star menu.
// Any other language can still be typed in by hand.
export const COMMON_LANGUAGES = [
  'Arabic', 'Bengali', 'Chinese (Simplified)', 'Chinese (Traditional)', 'Czech', 'Danish', 'Dutch',
  'English', 'Finnish', 'French', 'German', 'Greek', 'Gujarati', 'Hebrew', 'Hindi', 'Hungarian',
  'Indonesian', 'Italian', 'Japanese', 'Kannada', 'Korean', 'Malay', 'Malayalam', 'Marathi',
  'Norwegian', 'Persian', 'Polish', 'Portuguese', 'Punjabi', 'Romanian', 'Russian', 'Spanish',
  'Swedish', 'Tamil', 'Telugu', 'Thai', 'Turkish', 'Ukrainian', 'Urdu', 'Vietnamese'
];

// ---- Project contact and support (same details as SN Assignflow / SN Commands) ----
// Bug reports go out as a mailto:, so nothing is ever sent to a server this project controls.
export const CONTACT_EMAIL = 'contact@davagni.eu.org';
export const KOFI_URL = 'https://ko-fi.com/ysaryan';
export const UPI_ID = 'ysaryanraj@okaxis';

export function bugReportMailto(version, userAgent) {
  const v = version || 'unknown';
  const body =
    'What happened\n\n\n' +
    'What I expected instead\n\n\n' +
    'Steps to reproduce\n' +
    '1. \n2. \n3. \n\n' +
    '--- details below help a great deal, please leave them in ---\n' +
    'Groq Writer: ' + v + '\n' +
    'Browser: ' + (userAgent || 'unknown') + '\n' +
    'Where it happened (website, text box, or rich editor): \n' +
    'Connection (Worker proxy or direct key): \n';
  return 'mailto:' + CONTACT_EMAIL +
    '?subject=' + encodeURIComponent('Groq Writer \u2014 bug report (v' + v + ')') +
    '&body=' + encodeURIComponent(body);
}

export function hostFromUrl(url) {
  try {
    const u = new URL(url);
    return /^https?:$/.test(u.protocol) ? u.hostname : '';
  } catch {
    return '';
  }
}
