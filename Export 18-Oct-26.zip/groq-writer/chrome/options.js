// SPDX-License-Identifier: GPL-3.0-or-later
import {
  DEFAULTS, CATEGORY_IDS, CATEGORY_INFO, LANGUAGES, UPI_ID, bugReportMailto,
  getSettings, saveSettings, getApiKey, setApiKey, getProxyUrl, setProxyUrl
} from './shared.js';

const $ = (id) => document.getElementById(id);

const ERRORS = {
  no_key: 'Enter an API key first.',
  invalid_key: 'Groq rejected this key.',
  network: 'Could not reach api.groq.com.',
  timeout: 'The request timed out.',
  rate_limited: 'Rate limited. Try again in a moment.'
};

let toastTimer = null;
function toast() {
  const t = $('saved');
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 1200);
}

function setStatus(id, text, kind) {
  const el = $(id);
  el.textContent = text;
  el.className = 'status' + (kind ? ' ' + kind : '');
}

const lines = (text) =>
  [...new Set(text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean))];

function normalizeSite(s) {
  return s.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/[/:?#].*$/, '');
}

async function sendBg(msg) {
  try {
    return await chrome.runtime.sendMessage(msg);
  } catch {
    return { ok: false, error: 'network' };
  }
}

async function init() {
  const [s, key, proxy] = await Promise.all([getSettings(), getApiKey(), getProxyUrl()]);

  // Bug report and support
  $('reportBug').href = bugReportMailto(chrome.runtime.getManifest().version, navigator.userAgent);
  const dialog = $('supportDialog');
  $('upiId').textContent = UPI_ID;
  $('openSupport').addEventListener('click', () => dialog.showModal());
  $('closeSupport').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });
  $('copyUpi').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(UPI_ID);
      $('copyUpi').textContent = 'Copied';
    } catch {
      $('copyUpi').textContent = 'Copy failed';
    }
    setTimeout(() => { $('copyUpi').textContent = 'Copy'; }, 1500);
  });
  if (location.hash === '#support') dialog.showModal();

  // Proxy
  $('proxyUrl').value = proxy;
  const cleanProxy = () => $('proxyUrl').value.trim();
  const validProxy = (v) => {
    try { return new URL(v).protocol === 'https:'; } catch { return false; }
  };
  $('saveProxy').addEventListener('click', async () => {
    const v = cleanProxy();
    if (v && !validProxy(v)) {
      setStatus('proxyStatus', 'Enter a full https:// URL.', 'bad');
      return;
    }
    await setProxyUrl(v);
    setStatus('proxyStatus', v ? 'Proxy saved. Requests now go through it.' : 'Proxy removed.', 'ok');
    toast();
  });
  $('testProxy').addEventListener('click', async () => {
    const v = cleanProxy();
    if (!validProxy(v)) {
      setStatus('proxyStatus', 'Enter a full https:// URL first.', 'bad');
      return;
    }
    setStatus('proxyStatus', 'Testing...', '');
    const r = await sendBg({ type: 'test', proxyUrl: v });
    if (r && r.ok) setStatus('proxyStatus', 'Proxy works.', 'ok');
    else setStatus('proxyStatus', ERRORS[r && r.error] || (r && r.message) || 'Test failed.', 'bad');
  });

  // API key
  $('apiKey').value = key;
  $('showKey').addEventListener('click', () => {
    const show = $('apiKey').type === 'password';
    $('apiKey').type = show ? 'text' : 'password';
    $('showKey').textContent = show ? 'Hide' : 'Show';
    $('showKey').setAttribute('aria-pressed', String(show));
  });
  $('saveKey').addEventListener('click', async () => {
    await setApiKey($('apiKey').value);
    setStatus('keyStatus', $('apiKey').value.trim() ? 'Key saved.' : 'Key removed.', 'ok');
    toast();
  });
  $('testKey').addEventListener('click', async () => {
    setStatus('keyStatus', 'Testing...', '');
    // proxyUrl '' forces the direct test even if a proxy is saved.
    const r = await sendBg({ type: 'test', apiKey: $('apiKey').value, proxyUrl: '' });
    if (r && r.ok) {
      fillModels(r.models);
      setStatus('keyStatus', `Connected. ${r.models.length} models available.`, 'ok');
    } else {
      setStatus('keyStatus', ERRORS[r && r.error] || (r && r.message) || 'Test failed.', 'bad');
    }
  });

  // Models
  $('checkModel').value = s.checkModel;
  $('rewriteModel').value = s.rewriteModel;
  for (const id of ['checkModel', 'rewriteModel']) {
    $(id).addEventListener('change', async () => {
      const v = $(id).value.trim();
      await saveSettings({ [id]: v || DEFAULTS[id] });
      if (!v) $(id).value = DEFAULTS[id];
      toast();
    });
  }
  $('loadModels').addEventListener('click', async () => {
    setStatus('modelStatus', 'Loading...', '');
    if (cleanProxy()) {
      setStatus('modelStatus', 'Model lists are not available through a proxy. Type the model name instead.', '');
      return;
    }
    const r = await sendBg({ type: 'test', apiKey: $('apiKey').value, proxyUrl: '' });
    if (r && r.ok) {
      fillModels(r.models);
      setStatus('modelStatus', `${r.models.length} models loaded. Click a model box to pick one.`, 'ok');
    } else {
      setStatus('modelStatus', ERRORS[r && r.error] || (r && r.message) || 'Could not load models.', 'bad');
    }
  });
  $('resetModels').addEventListener('click', async () => {
    $('checkModel').value = DEFAULTS.checkModel;
    $('rewriteModel').value = DEFAULTS.rewriteModel;
    await saveSettings({ checkModel: DEFAULTS.checkModel, rewriteModel: DEFAULTS.rewriteModel });
    toast();
  });

  // Language
  for (const [value, label] of LANGUAGES) {
    const o = document.createElement('option');
    o.value = value;
    o.textContent = label;
    $('language').append(o);
  }
  $('language').value = s.language;
  $('language').addEventListener('change', async () => {
    await saveSettings({ language: $('language').value });
    toast();
  });

  // Categories
  for (const id of CATEGORY_IDS) {
    const row = document.createElement('label');
    row.className = 'cat';

    const sw = document.createElement('span');
    sw.className = 'switch';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = !!s.categories[id];
    const track = document.createElement('span');
    track.className = 'track';
    sw.append(input, track);

    const text = document.createElement('span');
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = id[0].toUpperCase() + id.slice(1);
    const desc = document.createElement('div');
    desc.className = 'desc';
    desc.textContent = CATEGORY_INFO[id];
    text.append(name, desc);

    row.append(sw, text);
    $('categories').append(row);

    input.addEventListener('change', async () => {
      await saveSettings({ categories: { [id]: input.checked } });
      toast();
    });
  }

  // Translation
  $('targetLanguages').value = s.targetLanguages.join('\n');
  $('targetLanguages').addEventListener('change', async () => {
    const langs = lines($('targetLanguages').value).map((l) => l.slice(0, 40)).slice(0, 12);
    await saveSettings({ targetLanguages: langs });
    $('targetLanguages').value = langs.join('\n');
    toast();
  });
  $('translateTone').value = s.translateTone;
  $('translateTone').addEventListener('change', async () => {
    await saveSettings({ translateTone: $('translateTone').value });
    toast();
  });
  $('bubbleEverywhere').checked = s.bubbleEverywhere;
  $('bubbleEverywhere').addEventListener('change', async () => {
    await saveSettings({ bubbleEverywhere: $('bubbleEverywhere').checked });
    toast();
  });

  // Behavior
  $('showBadge').checked = s.showBadge;
  $('showBadge').addEventListener('change', async () => {
    await saveSettings({ showBadge: $('showBadge').checked });
    toast();
  });

  const showDebounce = () => {
    $('debounceValue').textContent = (Number($('debounce').value) / 1000).toFixed(1) + 's';
  };
  $('debounce').value = s.debounceMs;
  showDebounce();
  $('debounce').addEventListener('input', showDebounce);
  $('debounce').addEventListener('change', async () => {
    await saveSettings({ debounceMs: Number($('debounce').value) });
    toast();
  });

  // Lists
  $('dictionary').value = s.dictionary.join('\n');
  $('dictionary').addEventListener('change', async () => {
    await saveSettings({ dictionary: lines($('dictionary').value).slice(0, 400) });
    toast();
  });

  $('disabledSites').value = s.disabledSites.join('\n');
  $('disabledSites').addEventListener('change', async () => {
    const sites = lines($('disabledSites').value).map(normalizeSite).filter(Boolean);
    await saveSettings({ disabledSites: [...new Set(sites)] });
    $('disabledSites').value = sites.join('\n');
    toast();
  });
}

function fillModels(ids) {
  const list = $('modelList');
  list.replaceChildren();
  for (const id of ids) {
    const o = document.createElement('option');
    o.value = id;
    list.append(o);
  }
}

// Keep the lists in sync if the popup or a context action changes them.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync' || !changes.settings || !changes.settings.newValue) return;
  const n = changes.settings.newValue;
  if (document.activeElement !== $('dictionary') && Array.isArray(n.dictionary)) {
    $('dictionary').value = n.dictionary.join('\n');
  }
  if (document.activeElement !== $('disabledSites') && Array.isArray(n.disabledSites)) {
    $('disabledSites').value = n.disabledSites.join('\n');
  }
});

init();
