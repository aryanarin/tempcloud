// SPDX-License-Identifier: GPL-3.0-or-later
import { getSettings, saveSettings, getApiKey, getProxyUrl, hostFromUrl, bugReportMailto } from './shared.js';

const $ = (id) => document.getElementById(id);

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function init() {
  const [settings, apiKey, proxy, tab] = await Promise.all([getSettings(), getApiKey(), getProxyUrl(), activeTab()]);
  const key = apiKey || proxy;
  const host = hostFromUrl(tab && tab.url);

  $('enabled').checked = settings.enabled;
  $('keyWarn').hidden = !!key;
  $('host').textContent = host || 'this page';

  const siteLine = $('siteOn').closest('.line');
  if (!host) {
    $('siteOn').disabled = true;
    $('siteOn').checked = false;
    siteLine.classList.add('disabled');
  } else {
    $('siteOn').checked = !settings.disabledSites.includes(host);
  }

  $('enabled').addEventListener('change', (e) => saveSettings({ enabled: e.target.checked }));

  $('siteOn').addEventListener('change', async (e) => {
    const cur = await getSettings();
    const set = new Set(cur.disabledSites);
    if (e.target.checked) set.delete(host); else set.add(host);
    await saveSettings({ disabledSites: [...set] });
  });

  // The markup carries a plain mailto; this adds the version and browser to the report.
  $('reportBug').href = bugReportMailto(chrome.runtime.getManifest().version, navigator.userAgent);
  // Let the mail client take over, then get out of the way.
  $('reportBug').addEventListener('click', () => setTimeout(() => window.close(), 120));

  $('support').addEventListener('click', async () => {
    await chrome.tabs.create({ url: chrome.runtime.getURL('options.html#support') });
    window.close();
  });

  $('settings').addEventListener('click', () => chrome.runtime.openOptionsPage());
  $('openKey').addEventListener('click', () => chrome.runtime.openOptionsPage());

  $('recheck').addEventListener('click', async () => {
    if (!tab) return;
    try {
      const r = await chrome.tabs.sendMessage(tab.id, { type: 'recheck' });
      $('status').textContent = r && r.ok ? 'Checking...' : 'Click into a text box first';
    } catch {
      $('status').textContent = 'Click into a text box first';
    }
  });

  if (tab && host) {
    try {
      const st = await chrome.tabs.sendMessage(tab.id, { type: 'getState' });
      if (st) {
        const info = $('fieldInfo');
        info.hidden = false;
        info.textContent = st.issues
          ? `${st.issues} suggestion${st.issues === 1 ? '' : 's'} in the current field.`
          : st.status === 'ok' ? 'The current field looks good.' : 'Watching the current field.';
      }
    } catch { /* no content script on this page */ }
  }
}

init();
