# Groq Writer

A Grammarly-style writing assistant for Chrome and Firefox, powered by the [Groq](https://groq.com) API. It proofreads as you type, rewrites and translates selected text, and detects languages, all without leaving the page.

- **Proofreading:** spelling, grammar, punctuation, clarity and style, underlined in place. Click an underline to accept, dismiss, or add a word to your dictionary. A badge in the text box lists everything and offers "Fix all".
- **Rewrite:** improve, fix, shorten, lengthen, paraphrase, formal, friendly, confident, or your own instruction.
- **Translate:** your pinned languages first (English and German by default), any other language by typing it, and the source language is detected automatically.
- **Detect language:** one click to name the language of any selection.
- **Works on any site:** textareas, text inputs and rich text editors. Replace text in a text box, or copy the result from read-only page text.
- **Private by design:** no server of ours, no analytics. Text goes only to Groq (or to your own proxy).

Licensed under the [GNU General Public License v3.0](LICENSE).

## Install

### Chrome, Edge, Brave (Chrome 105 or newer)

1. Download or clone this repository.
2. Open `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and choose the `chrome/` folder.

### Firefox (Firefox 140 or newer)

1. Open `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on...** and choose `firefox/manifest.json`.

Temporary add-ons are removed when Firefox restarts. For a permanent install, submit the Firefox build to [addons.mozilla.org](https://addons.mozilla.org) for signing (see [docs/STORE_NOTES.md](docs/STORE_NOTES.md)). If the extension shows no suggestions in Firefox, open `about:addons`, select Groq Writer, then **Permissions**, and allow access to all websites.

## Connect it to Groq

The settings page opens on first install. Pick one of two ways to connect.

### Option A: your own API key

1. Create a key at [console.groq.com/keys](https://console.groq.com/keys).
2. Paste it under **API key (direct mode)**, click **Save key**, then **Test connection**.

The key is stored only in `chrome.storage.local` on your machine and is sent only to `api.groq.com`.

### Option B: a Cloudflare Worker proxy

Use this if you do not want a key inside the browser, if `console.groq.com` or `api.groq.com` is awkward to reach from your network, or if you share one key between several tools.

1. Deploy [`docs/cloudflare-worker.example.js`](docs/cloudflare-worker.example.js) as a Worker.
2. Set the Worker's variables: `API_KEY` (as a secret), `API_ENDPOINT` (`https://api.groq.com/openai/v1/chat/completions`) and optionally `API_MODEL`.
3. Paste the Worker URL under **Proxy URL** in the extension settings, then click **Test proxy**.

With a proxy set, the extension sends requests only to that URL and attaches no key. The Worker must answer `POST` requests with CORS headers, as the example does. Note that anyone who learns the Worker URL can spend your key, so keep it private and consider adding an access token. The proxy also receives your text, so only point the extension at a Worker you control.

### Models

Defaults are `openai/gpt-oss-20b` for as-you-type checks and `openai/gpt-oss-120b` for rewriting and translating. Groq retires models regularly (the Llama 3.1 8B and Llama 3.3 70B models were shut down in August 2026), so if requests start failing with a "model unavailable" error, use **Load models** in settings (direct mode) or type a current model name.

## Using it

| Action | How |
| ------ | --- |
| Proofread | Type in any text box. After a short pause, problems are underlined. Click one for the fix. |
| Fix everything | Click the round badge in the text box, then **Fix all**. |
| Rewrite, translate or detect language | Select text, then click the orange star, or right-click and choose **Groq Writer**. |
| Translate to another language | Star menu: type it in **Other language...**. Right-click menu: **Translate to > More languages**. |
| Rewrite from the keyboard | `Alt+Shift+G` with text selected |
| Turn on or off | `Alt+Shift+K`, or the toolbar popup (also has a per-site switch) |

The orange star appears in text boxes by default. Turn on **Show the star on any selected text** in settings to get it everywhere, or use the right-click menu on read-only text.

Colors: red is spelling, grammar and punctuation; blue is clarity; purple is style.

Change shortcuts at `chrome://extensions/shortcuts` (Chrome) or `about:addons` > gear menu > **Manage Extension Shortcuts** (Firefox).

## Settings

Language variant (US, UK, Canada, Australia, India, or auto-detect), which categories to check, the pause before checking, the status badge, pinned translation languages, translation register (formal or match the original), a personal dictionary, and a list of disabled sites.

## What it skips

Google Docs (canvas editor), code editors (Monaco, CodeMirror, Ace), password and email fields, fields with `spellcheck="false"`, and small single-line inputs unless they contain a few words. Only the first 15,000 characters of a field are checked.

## Privacy

- Text in a field that Groq Writer is watching is sent to Groq (or to your proxy) so it can be checked. Nothing is sent anywhere else.
- Your API key, settings and dictionary stay in the browser. Settings sync through your browser account; the key and proxy URL do not.
- There is no analytics, tracking or account.

Details: [docs/privacy.html](docs/privacy.html).

## How it works

```
Page ──> content.js ──message──> background ──fetch──> api.groq.com   (direct)
 (field detection, underlines,                    └──> your Worker --> api.groq.com   (proxy)
  star menu, result cards)
```

- `content.js` finds editable fields, splits text into chunks, caches results per chunk, locates each suggested snippet in the text, and draws underlines. Textareas and inputs use a hidden mirror layer; rich text uses the CSS Custom Highlight API, so the page DOM is never modified.
- `background.js` is the only code that touches the network. It holds the key, queues requests, retries on rate limits, asks Groq for JSON, and validates every suggestion before returning it.
- `shared.js` holds defaults and storage helpers. The popup and settings page are plain HTML and JS with no build step.

## Project layout

```
groq-writer/
├── chrome/            Chrome / Edge / Brave build (load this folder)
├── firefox/           Firefox build: same files, different manifest.json
├── docs/              Privacy policy, store notes, cross-browser notes, example Worker
├── tools/             sync-firefox.ps1, check-wiring.js, package.ps1, make-icons.ps1
├── .github/           Issue and pull request templates
├── LICENSE            GNU GPL v3
└── CHANGELOG.md
```

## Development

There is no build step and there are no dependencies. Edit files under `chrome/`, then:

```powershell
powershell -ExecutionPolicy Bypass -File tools\sync-firefox.ps1   # copy shared files into firefox/
node tools\check-wiring.js                                         # verify manifests, assets, message handlers
powershell -ExecutionPolicy Bypass -File tools\package.ps1         # build dist\*.zip for both browsers
```

Optional: lint the Firefox build with Mozilla's tool, `npx web-ext lint --source-dir firefox --self-hosted`.

See [CONTRIBUTING.md](CONTRIBUTING.md) and [docs/CROSS_BROWSER.md](docs/CROSS_BROWSER.md).

## Troubleshooting

| Symptom | Fix |
| ------- | --- |
| Badge shows `!` | Click it. "Add your proxy URL or Groq API key" means setup is incomplete; "rejected your API key" means the key is wrong or revoked. |
| "The selected model may be unavailable" | The model was retired. Pick a current one in settings. |
| "Rate limit reached" | Free-tier quota. Raise **Wait after typing stops** in settings, or wait a minute. |
| Nothing underlined in a rich editor | Some editors fight outside changes. Use the badge list or the star menu instead. Please report the site. |
| Proxy test fails | Check the URL is `https://`, the Worker is deployed, and it returns CORS headers for `POST` and `OPTIONS`. |

## Support

Groq Writer is built and maintained in spare time.

- **Report a bug or request a feature:** use the **Report a bug** link in the popup or settings page (it prefills your version and browser), or [open an issue](https://github.com/aryanarin/groq-writer/issues).
- **Support the project:** [ko-fi.com/ysaryan](https://ko-fi.com/ysaryan), or UPI `ysaryanraj@okaxis` (QR code in the extension's Support dialog). Starring the repository also helps.

## License

Copyright (C) 2026 Aryan Raj. Groq Writer is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. It comes with no warranty. See [LICENSE](LICENSE).

Groq is a trademark of Groq, Inc. This project is independent and not affiliated with or endorsed by Groq.
