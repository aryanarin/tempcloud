---
name: Bug report
about: Something does not work as expected
labels: bug
---

**What happened**

**What you expected instead**

**Steps to reproduce**
1.
2.
3.

**Where it happened**
Website and the kind of text box (plain textarea, single-line input, or a rich editor such as Gmail or Notion):

**Environment**
- Groq Writer version:
- Browser and version:
- Connection: Worker proxy / direct API key
- Models (if changed from the defaults):

Please do not paste your API key or Worker URL.
