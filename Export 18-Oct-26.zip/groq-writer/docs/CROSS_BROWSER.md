# Cross-browser notes (Chrome vs Firefox)

`chrome/` and `firefox/` share every `.js`, `.html`, `.css` and image file. Only `manifest.json` differs. `tools/sync-firefox.ps1` copies the shared files and `tools/check-wiring.js` fails if they drift.

The code uses the `chrome.*` namespace with Promises. Chrome MV3 and Firefox both support that, so one codebase runs on both.

## What differs in `firefox/manifest.json`

| Key | Chrome | Firefox | Why |
| --- | ------ | ------- | --- |
| `background` | `service_worker` + `type: module` | `scripts` + `type: module` | Firefox runs MV3 background code as an event page, not a service worker. The code keeps no state between events, so behavior is the same. |
| `minimum_chrome_version` | `105` | not present | Needed for the CSS Custom Highlight API. |
| `browser_specific_settings` | not present | `gecko.id`, `strict_min_version` 140, `data_collection_permissions`, `gecko_android` | Required by addons.mozilla.org. Version 140 is where `data_collection_permissions` and the Custom Highlight API both exist. |

`data_collection_permissions.required` is `["websiteContent"]`, because text typed into pages is sent to Groq (or the user's own proxy) for checking.

## Behavior notes

- **Underlines in rich text** use the CSS Custom Highlight API (Chrome 105+, Firefox 140+). Where it is unavailable the badge list and tooltips still work; only the in-place underline is missing.
- **Content-script styles:** the UI first tries a constructable stylesheet (not blocked by page CSP), and falls back to a `<style>` element if the browser refuses a sheet created in the content-script world.
- **Host permissions:** Firefox treats MV3 host permissions as user-controlled. If the extension is silent on a site, allow access to all websites under `about:addons` > Groq Writer > Permissions.
- **Context menus, commands, storage, tabs, runtime** behave the same in both browsers for the calls used here.
- **mailto: links** (Report a bug) open the system's default mail handler in both browsers.

## Testing a Firefox build locally

1. `about:debugging#/runtime/this-firefox`
2. **Load Temporary Add-on...**, then choose `firefox/manifest.json`.

Lint with Mozilla's tool (needs npm access):

```
npx web-ext lint --source-dir firefox --self-hosted
```

Build a package with `tools/package.ps1` (output goes to `dist/`).
