# Store submission notes

Reusable text for the Chrome Web Store and addons.mozilla.org (AMO).

## Listing

**Name:** Groq Writer

**Short description (132 characters max):**
Fix spelling and grammar as you type, rewrite and translate selected text. Powered by your own Groq key or proxy.

**Category:** Productivity

**Long description:**
Groq Writer is a writing assistant that works on any website. It underlines spelling, grammar, punctuation and clarity problems as you type, and lets you accept each fix with a click or fix everything at once. Select text to rewrite it (improve, shorten, formal, friendly and more), translate it to your pinned languages or any language you type, or detect its language. It is open source (GPL v3), has no tracking, and sends text only to Groq or to a proxy you control. You supply your own Groq API key or a Cloudflare Worker URL.

**Links:**
- Homepage and source: https://github.com/aryanarin/groq-writer
- Privacy policy: https://github.com/aryanarin/groq-writer/blob/main/docs/privacy.html (or the GitHub Pages URL if you enable Pages on `/docs`)
- Support: contact@davagni.eu.org, https://ko-fi.com/ysaryan

## Permission justifications

| Permission | Why |
| ---------- | --- |
| `storage` | Saves settings, the personal dictionary and the API key or proxy URL locally. |
| `contextMenus` | Adds the Groq Writer entries (Rewrite, Translate to, Detect language) to the right-click menu. |
| `activeTab` | Lets the toolbar popup read the current tab's address to offer the per-site on/off switch. |
| `https://api.groq.com/*` | Sends text to the Groq API for checking, rewriting and translating. |
| Content script on `http://*/*` and `https://*/*` | Detects editable fields on any page to show suggestions. The script never reads or sends text from fields it skips (password, email, code editors, `spellcheck="false"`). |

No remote code is loaded. The extension has no analytics and no servers of its own. If the user sets a Proxy URL, the extension also sends requests to that URL.

## Data disclosure

- **Collected:** website content (the text of the field being checked or the selection being rewritten or translated).
- **Purpose:** only to provide the proofreading, rewriting, translation and language-detection features.
- **Recipient:** Groq, Inc. (api.groq.com), or the user's own proxy.
- **Not collected:** browsing history, identifiers, location, analytics, or anything else.
- **Retention:** the extension stores nothing on a server. Groq's own policy applies to text it receives.

AMO: `data_collection_permissions.required = ["websiteContent"]`.

## Reviewer notes

- A Groq API key (or Worker URL) is required to see suggestions. Reviewers can create a free key at https://console.groq.com/keys, or a test key can be provided in the reviewer notes field.
- Test steps: open any page with a textarea, type `Teh quick brwon fox jump over teh lazy dog`, wait about a second, and click an underline. Select text and click the orange star for rewrite and translate.

## Assets still to prepare

- At least one 1280x800 (or 640x400) screenshot, ideally three: underlines with the tooltip, the badge list, and the star menu with translate.
- A 440x280 small promo tile (Chrome Web Store).
- Icons are already in `chrome/icons` (16, 48, 128).
