# Changelog

All notable changes are listed here. The format follows [Keep a Changelog](https://keepachangelog.com/) and the project uses [Semantic Versioning](https://semver.org/).

## [1.0.0] - 2026-10-08

First release.

### Added
- Proofreading as you type in textareas, text inputs and rich text editors: spelling, grammar, punctuation, clarity and style, with inline underlines, an accept/dismiss tooltip, and a "Fix all" badge panel.
- Rewrite menu for selected text: improve, fix, shorten, longer, paraphrase, formal, friendly, confident, and custom instructions.
- Translation to pinned languages, any typed language, and a "More languages" right-click submenu, with automatic source-language detection and a Detect language action.
- Right-click menu that works on any selection, including read-only page text.
- Cloudflare Worker (or any compatible proxy) support, so no API key needs to live in the browser.
- Personal dictionary, per-site disable, language variants, configurable models and pause.
- Report a bug (prefilled email) and Support dialog.
- Chrome (Manifest V3) and Firefox builds from one codebase.
- Two keyboard shortcuts for quick actions:
  - **Alt+Shift+F**: Make selected text more formal (direct replacement, no result card).
  - **Alt+Shift+G**: Translate selected text to German (direct replacement, no result card).
  - For read-only text, results are copied to the clipboard instead of replacing.
  - Toast notifications confirm completion or show errors.
